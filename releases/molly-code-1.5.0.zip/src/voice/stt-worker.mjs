// Speech-to-text worker (sherpa-onnx-node 1.13.8). Runs in an Electron utility process (or a Node
// child process in tests) so decoding never blocks the app.
//   • Silero VAD finds where speech starts and stops.
//   • Parakeet (or the older Moonshine) turns speech into text, with live partial text while you
//     are still talking.
//   • When Molly is idle, only short utterances are decoded, to spot "Hey Molly": once early (from
//     the first second of speech, so she wakes while you're still talking) and once in full.
// Messages in:  {type:'init', modelsDir, assistantName?} | {type:'audio', samples} | {type:'mode', mode}
//               | {type:'flush', id} | {type:'reset'} | {type:'file', file} (tests)
// Messages out: {type:'ready', asr} | {type:'error'} | {type:'speech'} | {type:'silence'}
//               | {type:'partial', text} | {type:'segment', text, ms, seconds} | {type:'kws', rest}
// Modes: 'wake'      idle: only listening for "Hey Molly"
//        'listen'    a conversation turn: partial text while you speak, final text per utterance
//        'speaking'  Molly is talking: partial text too, so the app can tell if you interrupt her
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { matchWake } from './wake.mjs';
// The voice engine (a native module) lives in the app bundle; updated code runs from elsewhere.
const requireHere = createRequire(import.meta.url);
const requireShell = process.env.MOLLY_SHELL_DIR ? createRequire(path.join(process.env.MOLLY_SHELL_DIR, 'package.json')) : null;
function loadSherpa() {
  if (requireShell) { try { return requireShell('sherpa-onnx-node'); } catch {} }
  return requireHere('sherpa-onnx-node');
}

const port = process.parentPort || { postMessage: m => process.send(m), on: (ev, fn) => process.on('message', m => fn({ data: m })) };
const send = m => port.postMessage(m);

const SR = 16000;
const PARAKEET = 'sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8';
const MOONSHINE = 'sherpa-onnx-moonshine-base-en-int8';

let s = null, vad = null, rec = null, asr = null, wakeName = 'Molly';
let mode = 'wake', speaking = false, buf = new Float32Array(0), early = false;
let utt = [], uttLen = 0, sinceDecode = 0, pre = [];  // live audio of the current utterance, for partial text
const PRE_ROLL = SR * 0.35, PARTIAL_MAX = SR * 12, PARTIAL_TAIL = SR * 6, EARLY_AT = SR * 1.3;
let partialEvery = SR * 0.6; // grows on a slower Mac so live text never falls behind

const exists = (d, files) => files.every(f => fs.existsSync(path.join(d, f)));

function init(modelsDir, name) {
  s = loadSherpa();
  wakeName = name || 'Molly';
  const p = path.join(modelsDir, PARAKEET), m = path.join(modelsDir, MOONSHINE);
  if (exists(p, ['encoder.int8.onnx', 'decoder.int8.onnx', 'joiner.int8.onnx', 'tokens.txt'])) {
    asr = 'parakeet';
    rec = new s.OfflineRecognizer({
      featConfig: { sampleRate: SR, featureDim: 80 },
      modelConfig: { transducer: { encoder: path.join(p, 'encoder.int8.onnx'), decoder: path.join(p, 'decoder.int8.onnx'), joiner: path.join(p, 'joiner.int8.onnx') }, tokens: path.join(p, 'tokens.txt'), modelType: 'nemo_transducer', numThreads: 2, provider: 'cpu', debug: 0 },
    });
  } else {
    asr = 'moonshine';
    rec = new s.OfflineRecognizer({
      featConfig: { sampleRate: SR, featureDim: 80 },
      modelConfig: { moonshine: { preprocessor: path.join(m, 'preprocess.onnx'), encoder: path.join(m, 'encode.int8.onnx'), uncachedDecoder: path.join(m, 'uncached_decode.int8.onnx'), cachedDecoder: path.join(m, 'cached_decode.int8.onnx') }, tokens: path.join(m, 'tokens.txt'), numThreads: 2, provider: 'cpu', debug: 0 },
    });
  }
  // a short pause (0.45 s) ends an utterance; the app decides when a whole turn is over
  vad = new s.Vad({ sileroVad: { model: path.join(modelsDir, 'silero_vad.onnx'), threshold: 0.5, minSpeechDuration: 0.2, minSilenceDuration: 0.45, maxSpeechDuration: 25, windowSize: 512 }, sampleRate: SR, numThreads: 1, debug: 0 }, 60);
  buf = new Float32Array(0);
}

function decode(samples) {
  const st = rec.createStream();
  st.acceptWaveform({ sampleRate: SR, samples });
  rec.decode(st);
  return String(rec.getResult(st).text || '').trim();
}
const join = parts => { const n = parts.reduce((a, x) => a + x.length, 0), o = new Float32Array(n); let i = 0; for (const x of parts) { o.set(x, i); i += x.length; } return o; };

function drain() {
  while (!vad.isEmpty()) {
    const seg = vad.front(false); vad.pop(); // false: copy the samples (Electron forbids external buffers)
    if (!seg.samples || seg.samples.length < 1600) continue; // under 0.1 s: nothing to decode
    // idle: long chatter can't be "Hey Molly, …" — don't spend effort on it
    if (mode === 'wake' && seg.samples.length > SR * 12) continue;
    const t0 = Date.now();
    const text = decode(seg.samples);
    send({ type: 'segment', text, ms: Date.now() - t0, seconds: seg.samples.length / SR });
  }
}

function audio(samples) {
  // feed the VAD in 512-sample windows
  const all = new Float32Array(buf.length + samples.length); all.set(buf); all.set(samples, buf.length);
  let i = 0;
  for (; i + 512 <= all.length; i += 512) vad.acceptWaveform(all.subarray(i, i + 512));
  buf = all.slice(i);
  const now = vad.isDetected();
  if (now && !speaking) {
    speaking = true; send({ type: 'speech' });
    utt = pre.slice(); uttLen = utt.reduce((a, x) => a + x.length, 0); sinceDecode = 0; early = false;
  } else if (!now && speaking) { speaking = false; send({ type: 'silence' }); }
  if (speaking) {
    utt.push(samples); uttLen += samples.length; sinceDecode += samples.length;
    while (uttLen > PARTIAL_MAX && utt.length > 1) uttLen -= utt.shift().length;
    if (mode === 'wake') {
      // a quick look at the first moment of speech, so "Hey Molly, …" wakes her while you're still talking
      if (!early && uttLen >= EARLY_AT) {
        early = true;
        const w = matchWake(decode(join(utt)), wakeName);
        if (w) send({ type: 'kws', rest: w.rest });
      }
    } else if (sinceDecode >= partialEvery) {
      sinceDecode = 0;
      const all = join(utt), t0 = Date.now();
      // live text needs only the last few seconds; the full utterance is decoded once at the end
      const text = decode(all.length > PARTIAL_TAIL ? all.subarray(all.length - PARTIAL_TAIL) : all);
      const ms = Date.now() - t0;
      partialEvery = Math.min(SR * 2, Math.max(SR * 0.6, (ms / 1000) * 2.5 * SR));
      if (text) send({ type: 'partial', text, tail: all.length > PARTIAL_TAIL });
    }
  }
  // keep a little audio from before speech starts, so the first word isn't clipped
  pre.push(samples); let pl = pre.reduce((a, x) => a + x.length, 0);
  while (pl > PRE_ROLL && pre.length > 1) pl -= pre.shift().length;
  drain();
}

function clear() { vad.reset?.(); speaking = false; buf = new Float32Array(0); utt = []; uttLen = 0; sinceDecode = 0; }

port.on('message', ({ data: m }) => {
  try {
    if (m.type === 'init') { init(m.modelsDir, m.assistantName); send({ type: 'ready', asr }); }
    else if (m.type === 'audio') { if (vad) audio(m.samples instanceof Float32Array ? m.samples : Float32Array.from(m.samples)); }
    else if (m.type === 'mode') mode = m.mode || 'wake';
    else if (m.type === 'flush') { if (vad) { vad.flush(); drain(); clear(); } send({ type: 'flushed', id: m.id }); }
    else if (m.type === 'reset') { if (vad) clear(); }
    else if (m.type === 'file') { // test helper: run a wav file through the same path
      let w; try { w = s.readWave(m.file, false); } catch { w = s.readWave(m.file); }
      for (let i = 0; i < w.samples.length; i += 1600) audio(w.samples.subarray(i, i + 1600));
      audio(new Float32Array(SR)); // a second of silence afterwards
      vad.flush(); drain(); clear(); send({ type: 'file-done' });
    }
  } catch (e) { send({ type: 'error', message: String(e && e.message || e) }); }
});

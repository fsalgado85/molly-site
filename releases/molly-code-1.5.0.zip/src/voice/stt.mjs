// Voice in the main process: owns the speech worker and routes what it hears.
//   • Idle ("wake" mode): only listens for "Hey Molly" (short utterances are checked on this Mac).
//     Nothing else is passed on.
//   • In a conversation ("listen" mode): live partial text and final text go to the page.
//   • While Molly speaks ("speaking" mode): partial text goes to the page so it can tell if you
//     interrupt her.
import { EventEmitter } from 'node:events';
import { matchWake } from './wake.mjs';

export class SpeechService extends EventEmitter {
  /** spawnWorker(): returns {postMessage(m), on('message', fn(m)), kill()} */
  constructor({ spawnWorker, modelsReady, modelsDir, assistantName = () => 'Molly', wakeEnabled = () => true, log = () => {} }) {
    super();
    Object.assign(this, { spawnWorker, modelsReady, modelsDir, assistantName, wakeEnabled, log });
    this.worker = null; this.ready = false; this.session = null; this.flushWaiters = new Map(); this.seq = 0;
    this.mode = 'wake'; this.info = {}; this.lastWake = 0; this.paused = false;
  }
  start() {
    if (this.worker || this.paused || !this.modelsReady()) return false;
    this.worker = this.spawnWorker();
    this.worker.on('message', m => this.onWorker(m));
    this.worker.on('exit', () => { this.worker = null; this.ready = false; });
    this.worker.postMessage({ type: 'init', modelsDir: this.modelsDir, assistantName: this.assistantName() || 'Molly' });
    return true;
  }
  stop() { try { this.worker?.kill(); } catch {} this.worker = null; this.ready = false; }
  restart() { this.stop(); return this.start(); }
  /** Mac locked or asleep: end any conversation and stop listening until resume(). */
  pause() { this.paused = true; this.session = null; this.mode = 'wake'; for (const w of this.flushWaiters.values()) w(); this.flushWaiters.clear(); this.stop(); }
  resume() { this.paused = false; }
  status() { return { models: this.modelsReady(), running: !!this.worker, ready: this.ready, mode: this.mode, ...this.info }; }

  setMode(mode) {
    this.mode = mode;
    this.worker?.postMessage({ type: 'mode', mode });
  }

  onWorker(m) {
    if (m.type === 'ready') { this.ready = true; this.info = { asr: m.asr }; this.log(`voice ready (${m.asr})`); this.worker?.postMessage({ type: 'mode', mode: this.mode }); this.emit('ready'); }
    else if (m.type === 'error') { this.log('voice error: ' + m.message); }
    else if (m.type === 'speech') { if (this.session) this.emit('event', { type: 'speech' }); }
    else if (m.type === 'silence') { if (this.session) this.emit('event', { type: 'silence' }); }
    else if (m.type === 'partial') { if (this.session) this.emit('event', { type: 'partial', text: m.text }); }
    else if (m.type === 'flushed') { const w = this.flushWaiters.get(m.id); if (w) { this.flushWaiters.delete(m.id); w(); } }
    else if (m.type === 'kws') this.onEarlyWake(m.rest);
    else if (m.type === 'segment') this.onSegment(m.text);
  }
  wake(rest) {
    if (Date.now() - this.lastWake < 2500) return; // the early and the full check can both fire
    this.lastWake = Date.now();
    this.log('wake word heard');
    this.emit('wake', { rest: rest || '' });
  }
  // heard "Hey Molly" in the first moment of speech: wake now; the rest of the sentence follows as text
  onEarlyWake() {
    if (this.session || !this.wakeEnabled()) return;
    this.wake('');
  }
  onSegment(text) {
    if (!text) return;
    if (this.session) {
      // the first thing said after an early wake still starts with "Hey Molly": drop it
      const w = Date.now() - this.lastWake < 6000 ? matchWake(text, this.assistantName()) : null;
      const t = w ? w.rest : text;
      if (t) this.emit('event', { type: 'final', text: t });
      return;
    }
    if (!this.wakeEnabled()) return;
    const w = matchWake(text, this.assistantName());
    if (w) {
      // already woken early: what came after the name is the request
      if (Date.now() - this.lastWake < 6000) { if (w.rest) this.emit('wake-rest', { rest: w.rest }); return; }
      this.wake(w.rest);
    }
  }

  audio(samples) { if (this.worker && this.ready) this.worker.postMessage({ type: 'audio', samples }); }
  /** opts.mode: 'listen' (default) or 'speaking'. */
  sessionStart(opts = {}) {
    if (this.paused) return { ready: false, paused: true, message: 'Listening is paused while the Mac is locked.' };
    if (!this.modelsReady()) return { ready: false, message: 'Molly\'s voice files are not installed yet. Open the menu-bar icon → Set up again… to download them.' };
    if (!this.worker) this.start();
    const mode = opts.mode === 'speaking' ? 'speaking' : 'listen';
    const fresh = !this.session || opts.reset;
    this.session = { at: this.session?.at || Date.now(), continuous: !!opts.continuous, mode };
    if (fresh && !opts.keep) this.worker?.postMessage({ type: 'reset' });
    this.setMode(mode);
    return { ready: true, asr: this.info.asr || null };
  }
  async sessionStop({ flush = false } = {}) {
    if (!this.session) { this.setMode('wake'); return true; }
    if (flush && this.worker && this.ready) {
      const id = ++this.seq;
      await new Promise(res => { this.flushWaiters.set(id, res); this.worker.postMessage({ type: 'flush', id }); setTimeout(res, 4000); });
    }
    this.session = null;
    this.setMode('wake');
    return true;
  }
}

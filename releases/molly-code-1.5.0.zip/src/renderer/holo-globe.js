/* Molly.app — the glass globe on the Holo desk, alive: a slowly turning holographic globe (dotted
   continents) with glowing pins on the places you've been. The places are kept in Molly's own
   database (meta/places) and edited in the "Places I've been" window. City names and positions come
   from a bundled list of world cities (holo-cities.json: GeoNames, cities over 15,000 people). */
(function () {
  'use strict';
  if (window.__mollyGlobe) return;
  // land on a 2° grid (90 rows from 89°N, 180 columns from 179°W), one bit per cell
  const LAND = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHwAfvAAAAAAAAAAAAAAAAAAAAAAAAx37///+AAAAAGoABAAAAAAAAAAAAAIe8P///wAA8AAAAAA0AAAAAAAAAAAwADw////4AAIAAAAAAHAAAAAAAAAAALivwAf//wAAAAADAAP/wAHIAAAAAADsj38AH/+gAAAAAEAH///OAAAAgBgAAfw3/gB/+gAAAgAMHe///+/9gBAP/7/nbdrwD/+AAAH/Ag7H////////8H//////g8H/gAAAf/6//f////////Mf/////9H4D4A+AA+ev///////////AP/////4A0B4AAAD5/////////////Af1////gHgA4AAAP5///////////LwAHgD///gH0AAAAAG4/////////+AMAABAC///4D+AAAAGCx/////////4A4AAAAB////n/gAAAOCR/////////4A4AAAAAf///3/wAAAbH//////////9AgAAAAAP/////gAAADf//////////9AAAAAAAF////0YAAAB///////////8AAAAAAAD////8EAAAB///v///////5AAAAAAAD////+AAAAB/f5f///////wAAAAAAAD////gAAAAfxnwP///////jgAAAAAAD///+AAAAAPCb3///////+AAAAAAAAD///8AAAAAfCJf//////+ECAAAAAAAB///8AAAAAGDRf///////mMAAAAAAAA///8AAAAAH+Ai///////E8AAAAAAAAf//wAAAAAP/AA///////BgAAAAAAAAP//gAAAAAf/73///////gAAAAAAAAAD/AQAAAAAf//9/f/////gAAAAAAAAAF+AQAAAAB///+/n/////AAAAAAAAAAC+AAAAAAB///+fwH///+AAAAAAAAAAAeAwAAAAD////f/D///8gAAAAAAAAAAeGEAAAAD////v+B/j/AAAAAAAAAAAAPMAwAAAD////n+AfB+gAAAAAAAAAAAD8AAAAAD////34AeBfAgAAAAAAAAAAAPAAAAAH////3gAcAfAgAAAAAAAAAAADAAAAAD////6AAcAfgwAAAAAAAAAAABBwAAAD////8wAMATAIAAAAAAAAAAAAr/AAAB/////gAIASAAAAAAAAAAAAAAH/gAAA/////gACAAAIAAAAAAAAAAAAH/8AAAYH///AAAAsGAAAAAAAAAAAAAH/+AAAAB//+AAAAUOAAAAAAAAAAAAAP/+AAAAB//8AAAAc+gAAAAAAAAAAAAP//gAAAD//4AAAAMeBgAAAAAAAAAAAP//8AAAB//wAAAAGdCuAAAAAAAAAAAf///AAAA//wAAAACAAHgAAAAAAAAAAP///gAAA//wAAAAB4AHggAAAAAAAAAH///AAAAf/wAAAAACIDQIAAAAAAAAAH//+AAAAf/wAAAAAAAAAAAAAAAAAAAD//+AAAA//wgAAAAABxAAAAAAAAAAAD//8AAAA//wgAAAAAHxgBAAAAAAAAAA//8AAAA//zgAAAAAf/gAAAAAAAAAAAf/8AAAA//DgAAAAAf/gAAAAAAAAAAAf/8AAAAf/DAAAAAD//4CAAAAAAAAAAf/wAAAAf/DAAAAAH//4AAAAAAAAAAAf/AAAAAf+DAAAAAH//8AAAAAAAAAAAf/AAAAAP8AAAAAAH//+AAAAAAAAAAA/+AAAAAP8AAAAAAH//+AAAAAAAAAAA/8AAAAAH4AAAAAAD//+AAAAAAAAAAA/8AAAAAHwAAAAAADwf8AAAAAAAAAAA/gAAAAAAAAAAAAACAP4AAAAAAAAAAB/wAAAAAAAAAAAAAAAD4AEAAAAAAAAB+AAAAAAAAAAAAAAAAAAAGAAAAAAAAB6AAAAAAAAAAAAAAAAAwAMAAAAAAAAA8AAAAAAAAAAAAAAAAAQAYAAAAAAAAB4AAAAAAAAAAAAAAAAAAAwAAAAAAAAB4AAAAAAAAAAAAAAAAAAAAAAAAAAAABwAAAAAAAAAACAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAAA8AAf/8d/AAAAAAAAAAAAkAAAAAAACP/+H//////AAAAAAAAAAA+AAAAIf////+////////AAAAAAAOMKPAAAB///////////////gAAAH/8D//8AAAH//////////////4AAAF/////8AAAP///////////////4AAIf/////gwBwf///////////////4AAAH//////AAD////////////////wAAA///////+f//////////////////A/wH///////////////////////////////////////////////////////////////////////////////////////';
  const pts = [];
  (function () {
    const bin = atob(LAND);
    for (let r = 0; r < 90; r++) for (let c = 0; c < 180; c++) {
      const i = r * 180 + c;
      if ((bin.charCodeAt(i >> 3) >> (7 - (i & 7))) & 1) {
        const lat = (89 - r * 2) * Math.PI / 180, lon = (-179 + c * 2) * Math.PI / 180;
        pts.push([Math.cos(lat), Math.sin(lat), lon]);
      }
    }
  })();

  let el = null, cv = null, g = null, visible = false, raf = 0, rot = -0.3, last = 0, hover = false;
  let places = [], dbRef = null, cities = null, countries = {};
  const TILT = 0.32;
  const reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); let drawn = false;
  const use = k => (window.claude && window.claude.use) ? window.claude.use(k) : Promise.resolve(null);

  let loaded; const ready = new Promise(r => { loaded = r; setTimeout(r, 4000); });
  async function loadPlaces() {
    const db = await use('db'); if (!db) return loaded();
    dbRef = db;
    try { db.doc('meta/places').onSnapshot(sn => { places = (sn.exists && Array.isArray(sn.data().list)) ? sn.data().list : []; drawn = false; loaded(); }, () => loaded()); } catch { loaded(); }
  }
  async function save() { if (dbRef) await dbRef.doc('meta/places').set({ list: places, at: new Date().toISOString() }); }

  function size() {
    if (!el || !cv) return;
    const r = el.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.max(2, Math.round(r.width * dpr)); cv.height = Math.max(2, Math.round(r.height * dpr));
  }
  function project(cl, sl, lon) {
    const l = lon + rot, x = cl * Math.sin(l), y0 = sl, z0 = cl * Math.cos(l);
    return [x, y0 * Math.cos(TILT) - z0 * Math.sin(TILT), y0 * Math.sin(TILT) + z0 * Math.cos(TILT)];
  }
  function draw(t) {
    const W = cv.width, H = cv.height, R = Math.min(W, H) * 0.47, cx = W / 2, cy = H / 2;
    g.clearRect(0, 0, W, H);
    // the glass sphere
    const sg = g.createRadialGradient(cx - R * .35, cy - R * .4, R * .1, cx, cy, R);
    sg.addColorStop(0, 'rgba(60,150,255,.35)'); sg.addColorStop(.7, 'rgba(10,40,90,.82)'); sg.addColorStop(1, 'rgba(4,16,40,.92)');
    g.fillStyle = sg; g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
    // graticule
    g.lineWidth = Math.max(.5, R / 140); g.strokeStyle = 'rgba(90,190,255,.16)';
    for (let la = -60; la <= 60; la += 30) { const yy = Math.sin(la * Math.PI / 180), rr = Math.cos(la * Math.PI / 180); g.beginPath(); g.ellipse(cx, cy - (yy * Math.cos(TILT)) * R, rr * R, rr * R * Math.sin(TILT), 0, 0, Math.PI * 2); g.stroke(); }
    // continents
    const ds = Math.max(.8, R / 70);
    for (const [cl, sl, lon] of pts) {
      const [x, y, z] = project(cl, sl, lon);
      if (z <= 0) continue;
      g.fillStyle = 'rgba(110,210,255,' + (0.25 + 0.75 * z).toFixed(2) + ')';
      g.fillRect(cx + x * R - ds / 2, cy - y * R - ds / 2, ds, ds);
    }
    // pins
    for (let i = 0; i < places.length; i++) {
      const p = places[i]; const la = p.lat * Math.PI / 180;
      const [x, y, z] = project(Math.cos(la), Math.sin(la), p.lon * Math.PI / 180);
      if (z <= 0.05) continue;
      const px = cx + x * R, py = cy - y * R, ph = ((t / 1600) + i * 0.37) % 1;
      g.strokeStyle = 'rgba(255,190,90,' + ((1 - ph) * 0.8 * z).toFixed(2) + ')'; g.lineWidth = Math.max(1, R / 60);
      g.beginPath(); g.arc(px, py, (2 + ph * 7) * R / 60, 0, Math.PI * 2); g.stroke();
      g.fillStyle = 'rgba(255,214,140,' + (0.6 + 0.4 * z).toFixed(2) + ')'; g.shadowColor = '#ffb547'; g.shadowBlur = R / 10;
      g.beginPath(); g.arc(px, py, Math.max(1.6, R / 34), 0, Math.PI * 2); g.fill(); g.shadowBlur = 0;
    }
    // rim light
    const rg = g.createRadialGradient(cx, cy, R * .82, cx, cy, R * 1.04);
    rg.addColorStop(0, 'rgba(63,216,255,0)'); rg.addColorStop(.85, 'rgba(63,216,255,.55)'); rg.addColorStop(1, 'rgba(63,216,255,0)');
    g.fillStyle = rg; g.beginPath(); g.arc(cx, cy, R * 1.04, 0, Math.PI * 2); g.fill();
  }
  function frame(now) {
    raf = 0; if (!visible) return;
    raf = requestAnimationFrame(frame);
    if (now - (frame.t || 0) < 33) return;
    const dt = last ? Math.min(.1, (now - last) / 1000) : 0; last = now; frame.t = now;
    if (reduce) { if (drawn) return; drawn = true; }   // about 30 frames a second is plenty
    rot += dt * (hover ? 0.05 : 0.16);
    draw(now);
  }

  const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
  async function loadCities() {
    if (cities) return cities;
    try { const r = await fetch('/molly/holo-cities.json'); const j = await r.json(); countries = j.countries || {}; cities = j.cities || []; }
    catch { cities = []; }
    return cities;
  }

  window.__mollyGlobe = {
    mount(target) {
      el = target; cv = document.createElement('canvas'); el.appendChild(cv); g = cv.getContext('2d');
      new ResizeObserver(size).observe(el); size();
      el.addEventListener('pointerenter', () => { hover = true; }); el.addEventListener('pointerleave', () => { hover = false; });
      loadPlaces();
      if (visible && !raf) raf = requestAnimationFrame(frame);
    },
    show(on) { visible = !!on; if (visible && cv && !raf) { last = 0; size(); raf = requestAnimationFrame(frame); } },
    places: () => places.slice(),
    async search(q, n = 6) {
      const [name, ctry] = String(q || '').split(',').map(norm);
      if (!name) return [];
      const L = await loadCities(), out = [];
      for (const c of L) {
        const nm = norm(c[0]);
        if (nm !== name && !(name.length >= 3 && nm.startsWith(name))) continue;
        const country = countries[c[1]] || c[1];
        if (ctry && !norm(country).startsWith(ctry) && norm(c[1]) !== ctry) continue;
        out.push({ name: c[0], cc: c[1], country, lat: c[2], lon: c[3], exact: nm === name });
        if (out.length >= 400) break;
      }
      out.sort((a, b) => (b.exact - a.exact));
      return out.slice(0, n).map(({ exact, ...x }) => x);
    },
    async add(list) {
      await ready;
      for (const c of list || []) if (!places.some(p => p.name === c.name && p.cc === c.cc)) places.push({ name: c.name, cc: c.cc, country: c.country, lat: c.lat, lon: c.lon });
      await save();
    },
    async remove(name, cc) { await ready; const i = places.findIndex(p => p.name === name && (p.cc || '') === (cc || '')); if (i >= 0) { places.splice(i, 1); await save(); } },
  };
})();

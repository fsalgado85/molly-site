/* Molly.app: talking to Molly.
   • A SpeechRecognition stand-in backed by on-device recognition (the page's own code still uses it).
   • A conversation mode for "Hey Molly" and the 🎙 button, like a phone assistant:
       idle      only "Hey Molly" is listened for (on this Mac; nothing is sent anywhere)
       listening your words appear as you speak; a short pause sends them (no "end", no countdown)
       answering Molly thinks and speaks; talk over her and she stops and listens
       follow-up for a few seconds after she answers you can just carry on, then she goes back to idle
   Nothing is sent to Molly's chat except what you said in a turn. */
(function () {
  'use strict';
  const N = window.mollyNative && window.mollyNative.stt;
  if (!N) return; // not inside Molly.app: leave the page's normal fallbacks alone

  /* ---------- microphone capture (shared by recognition, conversation and wake mode) ---------- */
  const cap = { ctx: null, stream: null, node: null, users: new Set(), starting: null, denied: false };
  async function acquire(who) {
    cap.users.add(who);
    if (cap.ctx) return;
    if (cap.starting) return cap.starting;
    cap.starting = (async () => {
      try {
        // echo cancellation lets Molly hear you over her own voice, so you can interrupt her
        cap.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      } catch (e) { cap.users.delete(who); cap.denied = true; throw e; }
      cap.ctx = new AudioContext({ latencyHint: 'interactive' });
      await cap.ctx.audioWorklet.addModule('/molly/audio-worklet.js');
      const src = cap.ctx.createMediaStreamSource(cap.stream);
      cap.node = new AudioWorkletNode(cap.ctx, 'molly-capture');
      cap.node.port.onmessage = ev => N.audio(ev.data);
      src.connect(cap.node);
      // keep the graph running without playing the mic back
      const mute = cap.ctx.createGain(); mute.gain.value = 0; cap.node.connect(mute).connect(cap.ctx.destination);
    })();
    try { await cap.starting; } finally { cap.starting = null; }
  }
  function release(who) {
    cap.users.delete(who);
    if (cap.users.size || !cap.ctx) return;
    try { cap.stream.getTracks().forEach(t => t.stop()); } catch {}
    try { cap.ctx.close(); } catch {}
    cap.ctx = cap.stream = cap.node = null;
  }

  /* ---------- SpeechRecognition stand-in (kept for the page's own code) ---------- */
  let current = null;
  function mkResult(transcript, isFinal) { const alt = { transcript, confidence: isFinal ? 0.9 : 0.1 }; const r = [alt]; r.isFinal = isFinal; r.item = i => r[i]; return r; }
  function mkList(arr) { const l = arr.slice(); l.item = i => l[i]; return l; }
  class MollySpeechRecognition extends EventTarget {
    constructor() {
      super();
      this.continuous = false; this.interimResults = false; this.lang = 'en-GB'; this.maxAlternatives = 1; this.grammars = null;
      this.onresult = this.onend = this.onerror = this.onstart = this.onspeechstart = this.onspeechend = this.onaudiostart = this.onaudioend = this.onsoundstart = this.onsoundend = this.onnomatch = null;
      this._active = false; this._results = []; this._interim = false; this._timer = null;
    }
    _fire(type, props) {
      const ev = new Event(type); if (props) Object.assign(ev, props);
      try { this.dispatchEvent(ev); } catch {}
      const h = this['on' + type]; if (typeof h === 'function') { try { h.call(this, ev); } catch (e) { console.error(e); } }
    }
    async start() {
      if (this._active) { const e = new Error('recognition has already started'); e.name = 'InvalidStateError'; throw e; }
      convoEnd(true);
      this._active = true; this._results = []; this._interim = false;
      if (current && current !== this) current.abort();
      current = this;
      try { await acquire(this); }
      catch (e) { this._active = false; current = null; this._fire('error', { error: 'not-allowed', message: 'Microphone access was not allowed.' }); this._fire('end'); return; }
      if (!this._active) return;
      const ok = await N.sessionStart({ continuous: this.continuous, reset: true });
      if (!ok || !ok.ready) {
        this._active = false; current = null; release(this);
        this._fire('error', { error: 'service-not-allowed', message: (ok && ok.message) || 'Molly\'s voice files are not installed yet.' });
        this._fire('end'); return;
      }
      this._fire('start'); this._fire('audiostart');
      this._armNoSpeech();
    }
    _armNoSpeech() {
      clearTimeout(this._timer);
      if (this.continuous) return;
      this._timer = setTimeout(() => { if (this._active && !this._results.length) { this._fire('error', { error: 'no-speech' }); this._end(); } }, 8000);
    }
    _speech() {
      if (!this._active) return;
      clearTimeout(this._timer);
      this._fire('soundstart'); this._fire('speechstart');
    }
    _partial(text) {
      if (!this._active || !this.interimResults) return;
      if (this._interim) this._results.pop();
      this._results.push(mkResult((this._results.length ? ' ' : '') + text, false)); this._interim = true;
      this._fire('result', { resultIndex: this._results.length - 1, results: mkList(this._results) });
    }
    _final(text) {
      if (!this._active) return;
      text = String(text || '').trim();
      if (this._interim) { this._results.pop(); this._interim = false; }
      if (!text) return;
      this._results.push(mkResult((this._results.length ? ' ' : '') + text, true));
      this._fire('speechend'); this._fire('soundend');
      this._fire('result', { resultIndex: this._results.length - 1, results: mkList(this._results) });
      if (!this.continuous) this._end(); else this._armNoSpeech();
    }
    stop() { if (!this._active) return; N.sessionStop({ flush: true }).then(() => this._end()); }
    abort() { if (!this._active) return; N.sessionStop({ flush: false }); this._end(); }
    _end() {
      if (!this._active) return;
      this._active = false; clearTimeout(this._timer);
      if (current === this) current = null;
      N.sessionStop({ flush: false });
      release(this);
      this._fire('audioend'); this._fire('end');
    }
  }
  window.SpeechRecognition = MollySpeechRecognition;
  window.webkitSpeechRecognition = MollySpeechRecognition;

  /* ---------- conversation ---------- */
  const V = () => (window.__mollyHolo && window.__mollyHolo.voice) || null;
  const END_PAUSE = 700;       // after your last words, how long a pause sends them
  const NO_SPEECH = 7000;      // nothing said after waking: go back to idle
  const FOLLOW_UP = 6000;      // after Molly answers, how long she keeps listening without "Hey Molly"
  const MAX_AUTO = 2;          // follow-ups in a row without "Hey Molly" or a tap (stops a TV keeping her talking)
  const C = { state: 'idle', text: '', partial: '', endT: 0, noT: 0, watch: 0, sentAt: 0, active: 0, quietSince: 0, stopped: false, engine: null, woke: 0, lastSpk: 0, firstSpeech: 0, auto: 0, token: 0, pendingRest: '' };
  const norm = s => String(s || '').toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
  const dropWake = s => String(s || '').replace(/^\s*(hey|hi|ok|okay|hello)?[\s,]*(molly|mollie|holly|polly)\b[\s,.!?]*/i, '');

  function chime(up = true) {
    try {
      const c = new AudioContext(); const t = c.currentTime;
      (up ? [[880, 0], [1320, 0.1]] : [[990, 0], [660, 0.09]]).forEach(([f, d]) => {
        const o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(up ? 0.22 : 0.08, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.22);
        o.connect(g).connect(c.destination); o.start(t + d); o.stop(t + d + 0.3);
      });
      setTimeout(() => c.close(), 700);
    } catch {}
  }
  const ttsSpeaking = () => { try { return !!(window.speechSynthesis && speechSynthesis.speaking) || !!(V() && V().speaking()); } catch { return false; } };
  const ttsRecent = () => { try { return norm(window.__mollyTTSRecent ? window.__mollyTTSRecent() : ''); } catch { return ''; } };
  setInterval(() => { if (ttsSpeaking()) C.lastSpk = Date.now(); }, 150);
  const recentlySpoke = (ms = 3000) => ttsSpeaking() || Date.now() - C.lastSpk < ms;
  const words = t => norm(t).split(' ').filter(Boolean);
  // is this what Molly herself just said (her voice coming back through the microphone)? whole words only
  function isEcho(text) {
    const said = new Set(words(ttsRecent())); if (!said.size) return false;
    const w = words(text).filter(x => x.length > 1);
    if (!w.length) return true;
    return w.filter(x => said.has(x)).length / w.length >= 0.6;
  }
  function show(text, live) {
    const v = V(); if (!v) return;
    const t = dropWake(text).trim();
    C.live = t;
    v.you(t);
    try { window.dispatchEvent(new Event('molly-voice')); } catch {}
    if (C.state === 'listening') v.state('waiting', t ? (live ? 'Listening…' : 'Got it…') : C.follow ? 'Still listening…' : 'Listening…');
  }
  function clearTimers() { clearTimeout(C.endT); clearTimeout(C.noT); C.endT = C.noT = 0; }

  async function startTurn({ wake = false, rest = '', follow = false, keep = false } = {}) {
    if (current || C.state === 'starting') return; // the page's own recognition is in use, or a turn is already starting
    clearTimers(); clearInterval(C.watch);
    const token = ++C.token; C.state = 'starting'; C.pendingRest = '';
    if (!follow) C.auto = 0; // you asked: the follow-up allowance starts again
    try { await acquire('convo'); } catch { C.state = 'idle'; return micFallback(); }
    const r = await N.sessionStart({ mode: 'listen', keep, reset: !keep });
    if (token !== C.token || C.state !== 'starting') { return; } // overtaken (paused, stopped, or another turn)
    if (!r || !r.ready) { release('convo'); C.state = 'idle'; if (r && r.paused) return; C.engine = false; return micFallback(); }
    C.engine = true;
    if (wake) { chime(true); C.woke = Date.now(); }
    if (ttsSpeaking() && V()) V().hush();
    C.state = 'listening'; C.follow = follow; C.text = String(rest || C.pendingRest || '').trim(); C.pendingRest = ''; C.partial = ''; C.live = ''; C.stopped = false; C.firstSpeech = 0;
    document.documentElement.dataset.mollyVoice = follow ? 'follow-up' : 'listening';
    show(C.text, false);
    if (C.text) armEnd(); else C.noT = setTimeout(() => convoEnd(false), follow ? FOLLOW_UP : NO_SPEECH);
  }
  function armEnd(ms = END_PAUSE) { clearTimeout(C.endT); C.endT = setTimeout(sendTurn, ms); }

  function sendTurn() {
    clearTimers();
    const text = dropWake(C.text).trim();
    if (!text) return convoEnd(false);
    // a single "stop", "cancel" or "never mind" just stops
    if (/^(stop|cancel|never ?mind|nothing|thats all|that s all|no thanks|thank you|thanks)\W*$/i.test(text)) { if (V()) V().hush(); return convoEnd(false); }
    // Molly is waiting for a yes/no (e.g. before sending an email): only accept an answer that is clearly
    // yours — begun after she finished speaking, and not an echo of her own words
    const v0 = V();
    if (v0 && v0.pending() && (isEcho(text) || (C.firstSpeech && C.firstSpeech - C.lastSpk < 1000))) {
      C.text = ''; C.live = ''; C.firstSpeech = 0; v0.you(''); v0.state('waiting', 'Sorry, say that again?');
      C.noT = setTimeout(() => convoEnd(false), FOLLOW_UP);
      return;
    }
    if (C.follow) C.auto++;
    C.state = 'answering'; C.sentAt = Date.now(); C.active = 0; C.quietSince = 0; C.text = ''; C.live = '';
    document.documentElement.dataset.mollyVoice = 'answering';
    N.sessionStart({ mode: 'speaking', keep: true }); // keep the mic open, only to notice if you talk over her
    const v = V(); if (v) { v.you(text); v.ask(text); }
    clearInterval(C.watch);
    C.watch = setInterval(watchAnswer, 250);
  }
  function watchAnswer() {
    if (C.state !== 'answering') { clearInterval(C.watch); return; }
    const v = V(), busy = v ? v.busy() : false, spk = ttsSpeaking();
    if (spk) C.lastSpk = Date.now();
    if (busy || spk) { C.active = Date.now(); C.quietSince = 0; return; }
    if (!C.quietSince) C.quietSince = Date.now();
    // done when she's been quiet a moment (and either answered, or nothing happened for 2 s)
    if (Date.now() - C.quietSince > 500 && (C.active || Date.now() - C.sentAt > 2000)) {
      clearInterval(C.watch);
      if (C.stopped || C.auto >= MAX_AUTO) return convoEnd(true);
      startTurn({ follow: true, keep: true });
    }
  }
  function convoEnd(quiet) {
    const was = C.state;
    clearTimers(); clearInterval(C.watch);
    if (was === 'idle') return;
    C.token++;
    C.state = 'idle'; C.text = ''; C.follow = false; C.live = '';
    document.documentElement.dataset.mollyVoice = 'idle';
    N.sessionStop({ flush: false });
    release('convo');
    const v = V();
    if (v && !v.busy() && !ttsSpeaking()) { v.state('idle', wakeOn ? 'Say “Hey Molly” any time' : 'Ready when you are'); if (was === 'listening' && !quiet) v.you(''); }
    if (!quiet && was === 'listening') chime(false);
    try { window.dispatchEvent(new Event('molly-voice')); } catch {}
  }
  function interrupt(text) {
    if (V()) V().hush();
    C.stopped = false; clearInterval(C.watch);
    C.state = 'listening'; C.follow = false; C.text = ''; C.partial = text || ''; C.firstSpeech = Date.now(); C.auto = 0;
    document.documentElement.dataset.mollyVoice = 'listening';
    N.sessionStart({ mode: 'listen', keep: true });
    show(C.partial, true);
  }

  // the page's 🎙 buttons start a conversation turn instead of the old "say end" dictation
  let passThrough = false;
  function micFallback() {
    C.state = 'idle';
    const b = ['hMic', 'micBtn', 'vmTalk'].map(id => document.getElementById(id)).find(x => x && x.offsetParent !== null) || document.getElementById('micBtn');
    if (b) { passThrough = true; try { b.click(); } finally { passThrough = false; } }
  }
  document.addEventListener('click', e => {
    if (passThrough || C.engine === false) return;
    const t = e.target && e.target.closest && e.target.closest('#hMic,#micBtn,#vmTalk');
    if (t) {
      e.preventDefault(); e.stopImmediatePropagation();
      if (C.state === 'listening') { if (dropWake(C.text + ' ' + C.partial).trim()) { C.text = (C.text + ' ' + C.partial).trim(); sendTurn(); } else convoEnd(false); }
      else startTurn({});
      return;
    }
    if (e.target && e.target.closest && e.target.closest('#hStop,#stopBtn')) { C.stopped = true; if (C.state === 'listening') convoEnd(true); }
  }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && C.state === 'listening') convoEnd(false); }, true);

  /* ---------- what the voice engine hears ---------- */
  N.onEvent(ev => {
    if (current) { // the page's own recognition
      if (ev.type === 'speech') current._speech();
      else if (ev.type === 'partial') current._partial(ev.text);
      else if (ev.type === 'final') current._final(ev.text);
      return;
    }
    if (ev.type === 'wake') { if (C.state === 'idle') startTurn({ wake: true, rest: ev.rest || '', keep: true }); return; }
    if (ev.type === 'wake-rest') {
      if (C.state === 'starting') C.pendingRest = ev.rest;
      else if (C.state === 'listening' && !C.text) { C.text = ev.rest; show(C.text, false); armEnd(); }
      return;
    }
    if (ev.type === 'wake-mode') { window.__mollyWakeWhy = ev.why || ''; setWake(!!ev.on); return; }
    if (ev.type === 'voice-pause') { if (current) current.abort(); convoEnd(true); return; }
    if (C.state === 'listening') {
      // while Molly is (or was just) speaking, her own words coming back through the mic are ignored
      const echo = t => recentlySpoke() && isEcho(t);
      if (ev.type === 'speech') { clearTimeout(C.noT); clearTimeout(C.endT); if (!C.firstSpeech) C.firstSpeech = Date.now(); }
      else if (ev.type === 'partial') { if (echo(ev.text)) return; C.partial = ev.text; show((C.text + ' ' + ev.text).trim(), true); clearTimeout(C.noT); clearTimeout(C.endT); }
      else if (ev.type === 'final') {
        if (echo(ev.text)) { if (!dropWake(C.text).trim()) { clearTimeout(C.noT); C.noT = setTimeout(() => convoEnd(false), C.follow ? FOLLOW_UP : NO_SPEECH); } else armEnd(); return; }
        C.text = (C.text + ' ' + ev.text).trim(); C.partial = ''; show(C.text, false); armEnd();
      }
      else if (ev.type === 'silence' && dropWake(C.text).trim()) armEnd();
    } else if (C.state === 'answering') {
      // talking over Molly: if it isn't her own voice, she stops and listens
      if ((ev.type === 'partial' || ev.type === 'final') && ttsSpeaking()) {
        const w = words(ev.text);
        const shortStop = /^(stop|wait|hang on|molly|hey molly|cancel|pause)$/.test(norm(ev.text));
        // a few clear words (or "stop") — not one stray word, and not her own voice
        if ((w.length >= (ev.type === 'final' ? 2 : 3) || shortStop) && !isEcho(ev.text)) {
          if (ev.type === 'final' && /^(stop|cancel|pause|wait|hang on)$/.test(norm(ev.text))) { if (V()) V().hush(); C.stopped = true; return; }
          interrupt(ev.type === 'final' ? '' : ev.text);
          if (ev.type === 'final') { C.text = ev.text; show(C.text, false); armEnd(); }
        }
      }
    }
  });

  /* ---------- "Hey Molly" ---------- */
  let wakeOn = false;
  async function setWake(on) {
    if (on === wakeOn) return;
    wakeOn = on;
    if (on) { try { await acquire('wake'); } catch { wakeOn = false; } }
    else release('wake');
  }
  function onWake(rest) { if (C.state === 'idle') startTurn({ wake: true, rest: rest || '' }); }
  window.__mollySpeech = { setWake, onWake, startTurn, stop: () => convoEnd(false), get state() { return C.state; }, get live() { return C.live || ''; }, get capturing() { return !!cap.ctx; } };
})();

/* Molly.app — Holo screen. The backdrop is the owner's own picture of the futuristic desk (holo-room.jpg:
   skyscraper window, desk, plant, lighting, glass panels), cleaned of its sample text. Molly's live
   content is laid into the picture's glass panels (each mapped onto the picture's slightly curved panel
   with a perspective transform), and Molly's own 3D robot stands inside the ring.

   Whatever is opened (email, calendar, open points, weather, the paper, bills, the briefing, markets)
   grows out of its panel into a large holo window inside the same screen, and Molly moves to a column
   beside it so she stays in view. The windows host the page's own views (the page runs without its 3D
   room in Holo mode), restyled in Holo colours, so everything that works in Molly keeps working here.
   Nothing new is invented: data comes from the page (window.__mollyHolo, a read-only hook added at
   build time) and every button presses one of the page's own buttons or opens one of its own views. */
(function () {
  'use strict';
  if (window.__mollyHoloUI) return;
  window.__mollyHoloUI = true;

  const LS = 'molly.look';
  const pref = () => 'holo';   // the old 3D desk room has been retired: Holo is Molly's only look
  const setPref = v => { try { localStorage.setItem(LS, v); } catch {} };
  const BOOT = window.__MOLLY_BOOT || {};
  const PROFILE = BOOT.profile || {};
  const FIRST = PROFILE.firstName && PROFILE.firstName !== 'there' ? PROFILE.firstName : '';
  const TZ = PROFILE.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/London';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const BIG = { matches: true, addEventListener() {} };   // Holo fits any window size (the app window is at least 960 × 600)
  const REDUCED = matchMedia('(prefers-reduced-motion: reduce)');

  /* ---------- the picture's geometry (in picture pixels, 1230 × 673) ---------- */
  const IW = 1230, IH = 673;
  const MAIN = { x0: 100, x1: 1130, y0: 0, y1: IH };      // the main holo (frame, dock, talk box): never cropped
  const QUADS = {
    hxMail: [[135, 98], [438, 108], [438, 214], [135, 210]],
    hxCal: [[134, 216], [439, 220.5], [439, 321.4], [134, 322.4]],
    hxPts: [[134, 329], [439, 332], [439, 429.4], [134, 436.5]],
    hxWx: [[792.3, 113.4], [1098.5, 99.1], [1100.7, 208.2], [794.4, 215.3]],
    hxMkt: [[796, 223.9], [1099.4, 218.1], [1101.8, 321.4], [796, 322.3]],
    hxBills: [[795, 331.2], [1101, 327.8], [1101, 436.4], [795, 429.7]],
  };
  const RING = { cx: 615, cy: 200, size: 236 };
  const QUICK = [[474, 363, 537, 420], [548, 363, 613, 420], [623, 363, 688, 420], [698, 363, 763, 420]];
  const DOCK = { y0: 460, y1: 510, xs: [325, 400, 474, 548, 621, 693, 764, 834, 902], w: 68 };
  const TALK = { x0: 405, x1: 825, y0: 611, y1: 641 };
  const WIN = { x0: 132, y0: 106, x1: 902, y1: 444 };      // the large holo window
  const RFX = { cx: 614, cy: 220, r: 156 };                // the picture's ring, brought to life
  const GLOBE = { cx: 78, cy: 441, r: 62 };                // the picture's glass globe

  /* ---------- small line icons ---------- */
  const I = p => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
  const ICON = {
    mail: I('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6.5 8.5-6.5"/>'),
    mailFill: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="5" width="19" height="14" rx="2.2" fill="#6fb4ff"/><path d="m3.5 6.5 8.5 6.6 8.5-6.6" fill="none" stroke="#0d2747" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    cal: I('<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>'),
    points: I('<circle cx="12" cy="12" r="8.5"/><path d="m8.2 12.3 2.6 2.6 5-5.4"/>'),
    wx: I('<path d="M7.5 18.5h9.2a3.8 3.8 0 0 0 .4-7.6 5.3 5.3 0 0 0-10.2 1.4 3.1 3.1 0 0 0 .6 6.2Z"/><path d="M16.5 5.2a3.4 3.4 0 0 1 4 3.6"/>'),
    mkt: I('<path d="m3.5 17 5.5-5.5 4 3.5 7-7.5"/><path d="M15.5 7.5h4.5V12"/>'),
    bills: I('<rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M8.5 8h7M8.5 11.5h7M8.5 15h4.5"/>'),
    mic: I('<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5"/>'),
    sun: I('<circle cx="12" cy="12" r="4"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/>'),
    chase: I('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><path d="m12 12 7-7M15.5 5H19v3.5"/>'),
    moon: I('<path d="M19.5 14.5A7.8 7.8 0 1 1 9.5 4.5a6.3 6.3 0 0 0 10 10Z"/>'),
    paper: I('<path d="M4 5.5h13v13a1.5 1.5 0 0 0 3 0V8.5h-3"/><path d="M7 9h7M7 12.5h7M7 16h4"/>'),
    watch: I('<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/><path d="M8 11.5l2 2 4-4"/>'),
    desk: I('<path d="M3 10.5h18M5 10.5v9M19 10.5v9"/><rect x="8" y="4.5" width="8" height="6" rx="1"/>'),
    soundOn: I('<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4Z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a7.8 7.8 0 0 1 0 11"/>'),
    soundOff: I('<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4Z"/><path d="m16 9.5 5 5M21 9.5l-5 5"/>'),
    close: I('<path d="M6 6l12 12M18 6 6 18"/>'),
    note: I('<path d="M5 4.5h10l4 4V19.5H5Z"/><path d="M15 4.5v4h4M8 12h8M8 15.5h5"/>'),
    folder: I('<path d="M3.5 7.5a2 2 0 0 1 2-2h4l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2Z"/>'),
    globe: I('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.4 3.8 5.2 3.8 8.5s-1.2 6.1-3.8 8.5c-2.6-2.4-3.8-5.2-3.8-8.5S9.4 5.9 12 3.5Z"/>'),
    left: I('<path d="m14.5 6-6 6 6 6"/>'),
    right: I('<path d="m9.5 6 6 6-6 6"/>'),
    refresh: I('<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v4h-4"/>'),
  };

  // Subjects that open in the large holo window: the page's own view (tab) for each.
  const SUBJECT = {
    inbox: { title: 'Email', icon: 'mail', panel: 'hxMail', dock: 'inbox' },
    calendar: { title: 'Calendar', icon: 'cal', panel: 'hxCal', dock: 'calendar', cal: true },
    points: { title: 'Open Points', icon: 'points', panel: 'hxPts', dock: 'points' },
    weather: { title: 'Weather', icon: 'wx', panel: 'hxWx', dock: 'weather' },
    news: { title: 'The Molly Times', icon: 'paper', dock: 'news' },
    bills: { title: 'Bills & Renewals', icon: 'bills', panel: 'hxBills', dock: 'bills' },
    briefing: { title: 'Briefing', icon: 'sun', dock: 'notes' },
    notes: { title: 'Notepad', icon: 'note', dock: 'notes', own: true },
    files: { title: 'OneDrive', icon: 'folder', dock: 'files', own: true },
    places: { title: 'Places I’ve been', icon: 'globe', own: true },
    markets: { title: 'Markets', icon: 'mkt', panel: 'hxMkt', dock: 'markets', own: true },
    matters: { title: 'Matters', icon: 'points', dock: 'points', wrap: true },   // the page's full matters view (case files, history, evidence packs, research)
  };

  /* ---------- formatting ---------- */
  const tfmt = (d, o) => { try { return new Date(d).toLocaleString('en-GB', { timeZone: TZ, ...o }); } catch { return ''; } };
  const hm = d => tfmt(d, { hour: '2-digit', minute: '2-digit' });
  const dayKey = d => tfmt(d, { year: 'numeric', month: '2-digit', day: '2-digit' });
  const todayKey = () => dayKey(Date.now());
  const shortFrom = f => { const s = String(f || '').replace(/<[^>]*>/g, '').replace(/"/g, '').trim(); return s || String(f || '').replace(/[<>]/g, '') || 'Someone'; };
  const mailWhen = d => { if (!d) return ''; return dayKey(d) === todayKey() ? hm(d) : tfmt(d, { day: 'numeric', month: 'short' }); };
  const money = n => { const v = Number(n); return isFinite(v) && v > 0 ? '£' + v.toLocaleString('en-GB', { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }) : ''; };
  const dateShort = k => { try { return new Date(k + 'T12:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }); } catch { return k; } };

  /* ---------- the six glance panels (content only: the glass is the picture's own) ---------- */
  const head = (key, icon, title, right = '') =>
    `<button class="hx-ph" type="button" data-hx-open="${key}"><span class="hx-pi">${ICON[icon]}</span><h2>${esc(title)}</h2><span class="hx-sp"></span>${right}<span class="hx-chev">›</span></button>`;
  const empty = t => `<div class="hx-empty">${esc(t)}</div>`;

  function pMail(d) {
    const u = d.unread, top = (d.unreadTop || []).slice(0, 4);
    const n = u ? (u.recent ?? u.primary ?? u.all) : null;
    const rows = top.map(t => `<button class="hx-r" type="button" data-hx-mail="${esc(t.id)}"><span class="hx-env">${ICON.mailFill}</span><span class="hx-t"><b>${esc(t.subject)}</b><small>${esc(shortFrom(t.from))}</small></span><span class="hx-m">${esc(mailWhen(t.date))}</span></button>`).join('');
    return head('inbox', 'mail', 'Email', n ? `<span class="hx-badge">${esc(n)} unread</span>` : '') +
      `<div class="hx-pb">${rows || empty(!d.mcp ? 'Connect Google in Molly’s menu to see your email.' : u ? 'No unread email.' : 'Checking your inbox…')}</div>`;
  }

  function pCal(d) {
    const now = Date.now(), t = todayKey();
    const live = (d.events || []).filter(e => !e.free && !e.holiday);
    const isToday = e => e.allDay ? dayKey(String(e.start).slice(0, 10) + 'T12:00:00') === t : dayKey(e.start) === t;
    let list = live.filter(e => isToday(e) && (e.allDay || new Date(e.end || e.start).getTime() > now)), label = 'Today';
    if (!list.length) { list = live.filter(e => new Date(e.allDay ? e.start + 'T23:59:00' : (e.end || e.start)).getTime() > now); label = 'Coming up'; }
    list = list.sort((a, b) => String(a.start).localeCompare(String(b.start))).slice(0, 5);
    const when = e => e.allDay ? (label === 'Today' ? 'All day' : dateShort(String(e.start).slice(0, 10))) : (dayKey(e.start) === t ? hm(e.start) : tfmt(e.start, { weekday: 'short' }) + ' ' + hm(e.start));
    const rows = list.map((e, i) => `<button class="hx-r hx-cal" type="button" data-hx-meeting="${esc(e.id)}"><span class="hx-bar" style="--c:${esc(e.calHex || (i % 3 === 2 ? '#f5b23d' : '#3fd8ff'))}"></span><span class="hx-time">${esc(when(e))}</span><span class="hx-t"><b>${esc(e.title)}</b></span></button>`).join('');
    return head('calendar', 'cal', 'Calendar', `<span class="hx-lab">${label}</span>`) +
      `<div class="hx-pb">${rows || empty(!d.mcp ? 'Connect Google in Molly’s menu to see your calendar.' : d.eventsLoaded ? 'Nothing else in your calendar.' : 'Loading your calendar…')}</div>`;
  }

  const KIND = { you: 'On you', over: 'Overdue', fresh: 'New', them: 'Waiting' };
  function pPoints(d) {
    const L = d.points || [];
    const rows = L.slice(0, 6).map(p => `<button class="hx-r" type="button" data-hx-point="${esc(p.id)}"><span class="hx-bar k-${esc(p.kind)}"></span><span class="hx-t"><b>${esc(p.title)}</b></span><span class="hx-pill k-${esc(p.kind)}">${KIND[p.kind] || ''}</span></button>`).join('');
    return head('points', 'points', 'Open Points', L.length ? `<span class="hx-count">${L.length}</span>` : '') +
      `<div class="hx-pb">${rows || empty(d.db ? 'Nothing open. Nice work.' : 'Your matters aren’t loaded yet.')}</div>`;
  }

  const wxImg = (t, cls = '') => { let u = ''; try { u = H.wxIcon(t); } catch {} return u ? `<img class="${cls}" alt="" src="${esc(u)}">` : ''; };
  function pWx(d) {
    const w = d.weather;
    if (!w) return head('weather', 'wx', 'Weather') + `<div class="hx-pb">${empty('The forecast arrives with the next update.')}</div>`;
    const now = w.now || {}, d0 = (w.days || [])[0] || {};
    const days = (w.days || []).slice(1, 4).map(x => `<span class="hx-wd"><small>${esc(tfmt(x.date + 'T12:00:00', { weekday: 'short' }))}</small>${wxImg(x.type)}<b>${esc(x.max)}°/${esc(x.min)}°</b></span>`).join('');
    return head('weather', 'wx', w.place ? `Weather – ${w.place}` : 'Weather') +
      `<div class="hx-pb"><div class="hx-wx"><div class="hx-wxnow">${wxImg(now.type || d0.type)}<div><b>${esc(now.temp ?? d0.max ?? '–')}°C</b><small>${esc(now.type || d0.type || '')}</small><small>H: ${esc(d0.max ?? '–')}°C&nbsp;&nbsp;L: ${esc(d0.min ?? '–')}°C</small></div></div>${days}</div></div>`;
  }

  // Same five-day series as the markets screen on the desk.
  function series(q) {
    const today = new Date().toISOString().slice(0, 10);
    const D = (q.days || []).filter(x => x && x.d && isFinite(+x.c)).sort((a, b) => a.d.localeCompare(b.d));
    const prev = D.filter(x => x.d < today).slice(-5).map(x => ({ t: new Date(x.d + 'T21:00:00Z').getTime(), p: +x.c }));
    const cut = Date.now() - 5 * 864e5;
    const hist = (q.history || []).filter(p => p && p.t && isFinite(+p.p) && new Date(p.t).getTime() > cut).map(p => ({ t: new Date(p.t).getTime(), p: +p.p }));
    const S = [...prev, ...hist.filter(p => !prev.length || p.t > prev[prev.length - 1].t)];
    if (q.price != null && (!S.length || Math.abs(S[S.length - 1].p - q.price) > 1e-9)) S.push({ t: Date.now(), p: +q.price });
    return S;
  }
  let sparkN = 0;
  function spark(S, up, W = 60, Hh = 16) {
    if (S.length < 2) return `<svg viewBox="0 0 ${W} ${Hh}"></svg>`;
    const ps = S.map(s => s.p), mn = Math.min(...ps), mx = Math.max(...ps), rg = (mx - mn) || 1;
    const P = S.map((s, i) => [i / (S.length - 1) * W, Hh - 2 - (s.p - mn) / rg * (Hh - 4)]);
    const pts = P.map(p => p.map(v => v.toFixed(1)).join(',')).join(' ');
    const col = up ? '#36e39a' : '#ff6b81', id = 'hxSp' + (++sparkN);
    return `<svg viewBox="0 0 ${W} ${Hh}" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs><polygon points="0,${Hh} ${pts} ${W},${Hh}" fill="url(#${id})"/><polyline points="${pts}" fill="none" stroke="${col}" stroke-width="1.3" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>`;
  }
  const fmtP = q => q.price == null ? '–' : ((/^GBP|^EUR|^USD/.test(q.sym || '') || Math.abs(q.price) < 20) ? Number(q.price).toFixed(4) : Number(q.price).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  const pct = v => v == null || !isFinite(v) ? '' : (v >= 0 ? '+ ' : '− ') + Math.abs(Number(v)).toFixed(2) + '%';
  function pMkt(d) {
    const m = d.markets, Q = ((m && m.quotes) || []).slice(0, 5);
    const rows = Q.map(q => {
      const up = (q.changePct ?? q.change ?? 0) >= 0;
      return `<button class="hx-mk" type="button" data-hx-open="markets"><b>${esc(q.name || q.sym)}</b>${spark(series(q), up)}<span class="hx-pp">${esc(fmtP(q))}</span><span class="hx-c ${up ? 'hx-up' : 'hx-down'}">${esc(pct(q.changePct))}</span></button>`;
    }).join('');
    return head('markets', 'mkt', 'Markets') + `<div class="hx-pb">${rows || empty('Prices arrive with the next update.')}</div>`;
  }

  function pBills(d) {
    const L = d.renewals || [];
    const due = r => r.days == null ? '' : r.days < 0 ? 'Overdue' : r.days === 0 ? 'Due today' : 'Due ' + dateShort(r.date);
    const amt = r => r.monthly ? money(r.monthly) + '/mo' : r.annualCost ? money(r.annualCost) : '';
    const rows = L.slice(0, 5).map(r => `<button class="hx-r hx-bill" type="button" data-hx-open="bills"><span class="hx-sq ${r.days != null && r.days <= 7 ? 'soon' : ''}"></span><span class="hx-t"><b>${esc(String(r.title).replace(/\s*\(.*?\)/g, ''))}</b></span><span class="hx-due">${esc(due(r))}</span><span class="hx-amt">${esc(amt(r))}</span></button>`).join('');
    return head('bills', 'bills', 'Bills & Renewals', L.length ? `<span class="hx-badge red">${L.length} due</span>` : '') +
      `<div class="hx-pb">${rows || empty('Nothing due in the next month.')}</div>`;
  }

  // Markets has no 2D view in the page (it lived on the desk's monitor), so the window draws it from the same data.
  function marketsView(d) {
    const m = d.markets, Q = (m && m.quotes) || [];
    if (!Q.length) return `<div class="hx-mv"><p class="hx-empty">Prices arrive with the next markets update.</p></div>`;
    const rows = Q.map(q => {
      const S = series(q), first = S.length ? S[0].p : q.prevClose;
      const ch5 = first ? (q.price - first) / first * 100 : null;
      const up = (q.changePct ?? 0) >= 0, up5 = (ch5 ?? 0) >= 0;
      const st = q.stale ? '<span class="hx-mst stale">Stale</span>' : q.open ? '<span class="hx-mst open">● Open</span>' : '<span class="hx-mst">Closed</span>';
      return `<div class="hx-mvr"><div class="hx-mvn"><b>${esc(q.name || q.sym)}</b><small>${esc(q.sym || '')}${q.source ? ' · ' + esc(q.source) : ''}</small></div>
        <div class="hx-mvs">${spark(S, up5, 300, 46)}</div>
        <div class="hx-mvp"><b>${esc((q.ccy === 'USD' ? '$' : q.ccy === 'GBP' ? '£' : '') + fmtP(q))}</b>${st}</div>
        <div class="hx-mvc"><span class="${up ? 'hx-up' : 'hx-down'}">${esc(pct(q.changePct))}<small>today</small></span><span class="${up5 ? 'hx-up' : 'hx-down'}">${esc(pct(ch5))}<small>5 days</small></span></div></div>`;
    }).join('');
    const upd = m && m.at ? (m.status === 'working' ? 'Updating…' : 'Updated ' + tfmt(m.at, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })) : '';
    return `<div class="hx-mv">${rows}<div class="hx-mvf"><span>${esc(upd)}</span><button class="btn small" type="button" data-hx-say="markets">🔊 Read them to me</button></div></div>`;
  }

  /* ---------- perspective: map a w × h box onto one of the picture's panels ---------- */
  function matrix3d(w, h, q) {
    const [[x0, y0], [x1, y1], [x2, y2], [x3, y3]] = q;
    const dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
    const den = dx1 * dy2 - dx2 * dy1;
    const g = (dx3 * dy2 - dx2 * dy3) / den, k = (dx1 * dy3 - dx3 * dy1) / den;
    const a = x1 - x0 + g * x1, b = x3 - x0 + k * x3, c = x0, d = y1 - y0 + g * y1, e = y3 - y0 + k * y3, f = y0;
    return `matrix3d(${[a / w, d / w, 0, g / w, b / h, e / h, 0, k / h, 0, 0, 1, 0, c, f, 0, 1].map(v => +v.toFixed(8)).join(',')})`;
  }
  const qsize = q => [Math.round((Math.hypot(q[1][0] - q[0][0], q[1][1] - q[0][1]) + Math.hypot(q[2][0] - q[3][0], q[2][1] - q[3][1])) / 2), Math.round((Math.hypot(q[3][0] - q[0][0], q[3][1] - q[0][1]) + Math.hypot(q[2][0] - q[1][0], q[2][1] - q[1][1])) / 2)];

  /* ---------- building the screen ---------- */
  let H = null, root = null, stage = null, core = null, win = null, sig = {}, shown = null, scale = 1, offX = 0, offY = 0;
  let view = null, fromRect = null, sideHome = null, attached = false, ownView = null;
  const box = (x0, y0, x1, y1) => `left:${x0}px;top:${y0}px;width:${x1 - x0}px;height:${y1 - y0}px`;

  function build() {
    root = document.createElement('div');
    root.id = 'holo'; root.className = 'off'; root.setAttribute('aria-label', 'Molly');
    const panels = Object.entries(QUADS).map(([id, q]) => { const [w, h] = qsize(q); return `<section class="hx-p" id="${id}" style="width:${w}px;height:${h}px;transform:${matrix3d(w, h, q)}"></section>`; }).join('');
    const quick = [['hxTalk', 'mic', 'Talk', ''], ['', 'sun', 'Briefing', 'data-hx-press="hGo"'], ['', 'chase', 'Chase', `data-hx-chip='[data-q="What should I chase this week?"]'`], ['', 'moon', 'Wrap up', `data-hx-chip='[data-hq="wrap"]'`]]
      .map(([id, ic, label, attr], i) => `<button class="hx-q hx-q${i}" type="button" ${id ? `id="${id}" aria-pressed="false"` : ''} ${attr} style="${box(...QUICK[i])}">${ICON[ic]}<span>${label}</span></button>`).join('');
    const dockItems = [['inbox', 'mail', 'Email'], ['calendar', 'cal', 'Calendar'], ['points', 'points', 'Points'], ['notes', 'note', 'Notepad'], ['files', 'folder', 'Files'], ['news', 'paper', 'Paper'], ['markets', 'mkt', 'Markets'], ['weather', 'wx', 'Weather'], ['bills', 'bills', 'Bills']];
    const dock = dockItems.map(([k, ic, label], i) => `<button class="hx-d" type="button" data-hx-dock="${k}" style="${box(DOCK.xs[i] - DOCK.w / 2, DOCK.y0, DOCK.xs[i] + DOCK.w / 2, DOCK.y1)}">${ICON[ic]}<span>${label}</span></button>`).join('');
    root.innerHTML = `<div class="hx-fill"></div><div class="hx-stage" id="hxStage">
      <img class="hx-bg" src="/molly/holo-room.jpg" alt="" draggable="false">
      <div class="hx-brand" style="${box(212, 50, 302, 92)}"><b id="hxBrand">MOLLY</b><small>Personal assistant</small></div>
      <div class="hx-greet" style="${box(306, 56, 560, 102)}"><h1 id="hxHi"></h1><p>Here’s your update at a glance.</p></div>
      <div class="hx-now" style="${box(860, 52, 978, 104)}"><small id="hxDate"></small><b id="hxTime"></b></div>
      <button class="hx-ib" type="button" id="hxSound" aria-label="Sound" style="${box(1002, 52, 1034, 84)}">${ICON.soundOff}</button>
      <button class="hx-ib ghost" type="button" id="hxSet" aria-label="Settings" title="Settings" style="${box(1056, 50, 1092, 86)}"></button>
      ${panels}
      <div class="hx-colbg" style="${box(912, 106, 1104, 444)}"></div>
      <div class="hx-ringfx" id="hxRingFx" data-state="idle" style="${box(RFX.cx - RFX.r, RFX.cy - RFX.r, RFX.cx + RFX.r, RFX.cy + RFX.r)}">${ringFx()}</div>
      <button class="hx-globe" type="button" id="hxGlobe" aria-label="Places I’ve been" title="Places I’ve been" style="${box(GLOBE.cx - GLOBE.r, GLOBE.cy - GLOBE.r, GLOBE.cx + GLOBE.r, GLOBE.cy + GLOBE.r)}"></button>
      <div class="hx-ring" id="hxCore" data-state="idle" style="${box(RING.cx - RING.size / 2, RING.cy - RING.size / 2, RING.cx + RING.size / 2, RING.cy + RING.size / 2)}"><div class="hx-bot3d" id="hxBot3d"></div><button class="hx-bothit" type="button" id="hxBot" aria-label="Talk to Molly"></button></div>
      <div class="hx-statebox" style="${box(520, 288, 710, 306)}"><span class="hx-state" id="hxState">Ready</span></div>
      <div class="hx-say" style="${box(470, 308, 760, 356)}"><div class="hx-cap ask" id="hxCap" aria-live="polite"></div></div>
      ${quick}
      ${dock}
    </div>
    <div class="hx-win" id="hxWin" hidden role="dialog" aria-labelledby="hxWT">
      <i class="hx-k tl"></i><i class="hx-k tr"></i><i class="hx-k bl"></i><i class="hx-k br"></i>
      <header class="hx-wh"><span class="hx-wi" id="hxWI"></span><h2 id="hxWT"></h2><span class="hx-wsp"></span><div class="hx-wctl" id="hxWCtl"></div><button class="hx-wlink" type="button" id="hxWMat" hidden>Case files ›</button><button class="hx-wclose" type="button" id="hxWClose" aria-label="Close" title="Close (Esc)">${ICON.close}</button></header>
      <div class="hx-wscan"></div>
      <div class="hx-wb" id="hxWB"><div id="hxSlot"></div><div id="hxOwn" hidden></div><div id="hxWrap" hidden></div></div>
    </div>`;
    document.body.appendChild(root);
    stage = $('hxStage'); core = $('hxCore'); win = $('hxWin');

    root.addEventListener('click', onClick);
    window.addEventListener('resize', () => { layout(); update(true); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && view && shown && !overlayOpen() && !/^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); closeView(); } });
    BIG.addEventListener?.('change', () => update(true));
    if (window.__mollyHoloBot) window.__mollyHoloBot.mount($('hxBot3d'));
    if (window.__mollyGlobe) window.__mollyGlobe.mount($('hxGlobe'));
  }
  const overlayOpen = () => ['settings', 'pack', 'mpop', 'vm', 'hConfirm'].some(id => { const e = $(id); return e && !e.hidden; });

  /* ---------- fit: the main holo always fully in view; wider windows show more of the room ---------- */
  function layout() {
    if (!stage) return;
    const vw = innerWidth, vh = innerHeight;
    scale = Math.min(vh / (MAIN.y1 - MAIN.y0), vw / (MAIN.x1 - MAIN.x0));
    offX = (vw - IW * scale) / 2;
    offY = (vh - IH * scale) / 2;
    stage.style.transform = `translate(${offX}px, ${offY}px) scale(${scale})`;
    root.style.setProperty('--hx-s', String(scale));
    placeTalk(); placeWin(); fit();
  }
  const scr = (x, y) => [offX + x * scale, offY + y * scale];
  function placeTalk() {
    const bar = document.querySelector('#home .hbar'); if (!bar) return;
    if (!shown) { for (const p of ['left', 'top', 'width', '--hx-s']) bar.style.removeProperty(p); return; }
    const [x, y] = scr(TALK.x0, TALK.y0);
    bar.style.left = Math.round(x) + 'px'; bar.style.top = Math.round(y) + 'px';
    bar.style.width = Math.round((TALK.x1 - TALK.x0) * scale) + 'px';
    bar.style.setProperty('--hx-s', String(scale));
  }
  function placeWin() {
    if (!win) return;
    const [x, y] = scr(WIN.x0, WIN.y0);
    Object.assign(win.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round((WIN.x1 - WIN.x0) * scale) + 'px', height: Math.round((WIN.y1 - WIN.y0) * scale) + 'px' });
    win.style.setProperty('--hx-z', String(Math.max(.9, Math.min(1.7, scale / 1.25)).toFixed(3)));
  }

  /* ---------- the page's views, hosted in the holo window ---------- */
  function attach(on) {
    const side = $('hSide'); if (!side) return;
    if (on && !attached) { sideHome = { parent: side.parentNode, next: side.nextSibling }; $('hxSlot').appendChild(side); attached = true; }
    else if (!on && attached && sideHome) { sideHome.parent.insertBefore(side, sideHome.next); attached = false; }
  }
  let wrapHome = null, wrapIn = false;
  function attachWrap(on) {
    const w = document.querySelector('body > .wrap'); const cur = wrapIn ? $('hxWrap').firstElementChild : w;
    if (on && !wrapIn && w) { wrapHome = { parent: w.parentNode, next: w.nextSibling }; $('hxWrap').appendChild(w); wrapIn = true; }
    else if (!on && wrapIn && wrapHome && cur) { wrapHome.parent.insertBefore(cur, wrapHome.next); wrapIn = false; }
  }
  const onHome = () => document.body.classList.contains('home-on');
  const tabNow = () => { const s = $('hSide'); return (s && s.dataset.tab) || 'overview'; };

  function openView(k, src) {
    if (!SUBJECT[k]) return;
    if (k === 'calendar' && ownView !== 'calendar') { calAnchor = new Date(); calKey = ''; }
    fromRect = src || fromRect;
    if (k === 'calendar' && calMode !== 'agenda') { ownView = 'calendar'; if (tabNow() !== 'overview') H.tab('overview'); showWin('calendar'); return; }
    if (k === 'notes' && deckHasNotes()) { ownView = null; if (tabNow() !== 'briefing') H.tab('briefing'); else showWin('briefing'); return; }
    if (SUBJECT[k].own) { ownView = k; if (tabNow() !== 'overview') H.tab('overview'); showWin(k); return; }
    ownView = null;
    if (tabNow() !== k) H.tab(k); else showWin(k);
    if (k === 'points') try { H.points(); } catch {}
  }
  function closeView() {
    if (view === 'matters' || !onHome()) { H.home(); return; }
    if (ownView) { ownView = null; hideWin(); return; }
    if (tabNow() !== 'overview') H.tab('overview'); else hideWin();
  }
  // follow the page: whatever view it opens (briefing, a case file, the inbox…) shows in the window
  function syncView() {
    if (!shown) return;
    if (!onHome()) { ownView = null; if (view !== 'matters') showWin('matters'); return; }
    if (view === 'matters') { hideWin(); }
    const t = tabNow();
    if (t !== 'overview' && SUBJECT[t]) { ownView = null; if (t === 'calendar') calMode = 'agenda'; if (view !== t) showWin(t); }
    else if (!ownView && view) hideWin();
  }

  function showWin(k) {
    const S = SUBJECT[k], was = view;
    view = k;
    root.classList.add('hx-max');
    for (const b of root.querySelectorAll('.hx-d')) b.classList.toggle('on', b.dataset.hxDock === (S.dock || ''));
    const watch = k === 'bills' && pendingWatch;
    const running = (() => { try { return H.peek().running; } catch { return false; } })();
    $('hxWI').innerHTML = ICON[watch ? 'watch' : k === 'briefing' && !running ? 'note' : S.icon];
    $('hxWT').textContent = watch ? 'Bills & Watchlist' : k === 'briefing' && !running ? 'Notepad' : S.title;
    $('hxWCtl').innerHTML = S.cal ? calControls() : k === 'files' ? '<button class="hx-wbtn" type="button" data-hx-files="reindex" title="Index OneDrive again">' + ICON.refresh + '<span>Re-index</span></button>' : '';
    $('hxWMat').hidden = k !== 'points';
    if (watch) for (const b of root.querySelectorAll('.hx-d')) b.classList.toggle('on', b.dataset.hxDock === 'watchlist');
    const own = !!S.own || (S.cal && calMode !== 'agenda');
    $('hxSlot').hidden = !!(own || S.wrap); $('hxOwn').hidden = !own; $('hxWrap').hidden = !S.wrap;
    attachWrap(!!S.wrap);
    if (own) renderOwn(true);
    placeWin();
    win.hidden = false;
    const wb = $('hxWB'); if (was !== k) wb.scrollTop = 0;
    win.classList.remove('reveal'); void win.offsetWidth; win.classList.add('reveal');
    if (!was && !REDUCED.matches) {
      const r = win.getBoundingClientRect();
      const s = fromRect || { left: r.left + r.width * .4, top: r.top + r.height * .4, width: r.width * .2, height: r.height * .2 };
      win.animate([
        { transform: `translate(${s.left - r.left}px, ${s.top - r.top}px) scale(${Math.max(.05, s.width / r.width)}, ${Math.max(.05, s.height / r.height)})`, opacity: .35, filter: 'brightness(1.8)' },
        { transform: 'none', opacity: 1, filter: 'none' },
      ], { duration: 520, easing: 'cubic-bezier(.2,.85,.2,1)' });
    }
    fromRect = null;
    if (k === 'bills' && pendingWatch) { pendingWatch = false; setTimeout(() => { const w = $('hWatch'); if (w) w.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 300); }
  }
  function hideWin() {
    if (!view) return;
    const k = view; view = null;
    attachWrap(false);
    root.classList.remove('hx-max');
    for (const b of root.querySelectorAll('.hx-d')) b.classList.remove('on');
    const S = SUBJECT[k], p = S && S.panel && $(S.panel);
    if (REDUCED.matches || !p) { win.hidden = true; return; }
    const r = win.getBoundingClientRect(), s = p.getBoundingClientRect();
    const a = win.animate([
      { transform: 'none', opacity: 1 },
      { transform: `translate(${s.left - r.left}px, ${s.top - r.top}px) scale(${Math.max(.05, s.width / r.width)}, ${Math.max(.05, s.height / r.height)})`, opacity: 0 },
    ], { duration: 360, easing: 'cubic-bezier(.4,0,.6,1)' });
    a.onfinish = () => { if (!view) win.hidden = true; };
  }
  function renderOwn(force) {
    if (ownView === 'calendar') return renderCal(force);
    if (ownView === 'files') return renderFiles(force);
    if (ownView === 'notes') { if (force) $('hxOwn').innerHTML = notesEmpty(); return; }
    if (ownView === 'places') { if (force) renderPlaces(); return; }
    if (ownView !== 'markets') return;
    let d; try { d = H.peek(); } catch { return; }
    const key = JSON.stringify([d.markets && d.markets.at, d.markets && d.markets.status, (d.markets && d.markets.quotes || []).map(q => q.price)]);
    if (force || sig.own !== key) { sig.own = key; $('hxOwn').innerHTML = marketsView(d); }
  }


  /* ---------- the ring around Molly, alive: arcs that turn, a scanner, and a pulse when she speaks ---------- */
  function ringFx() {
    const ticks = [];
    for (let i = 0; i < 120; i++) { const a = i / 120 * Math.PI * 2, r1 = 141, r2 = i % 10 ? 145 : 150; ticks.push(`M${(150 + Math.cos(a) * r1).toFixed(1)} ${(150 + Math.sin(a) * r1).toFixed(1)}L${(150 + Math.cos(a) * r2).toFixed(1)} ${(150 + Math.sin(a) * r2).toFixed(1)}`); }
    return `<svg viewBox="0 0 300 300" aria-hidden="true">
      <defs><radialGradient id="hxRfG"><stop offset=".55" stop-color="#3fd8ff" stop-opacity="0"/><stop offset=".8" stop-color="#3fd8ff" stop-opacity=".25"/><stop offset="1" stop-color="#3fd8ff" stop-opacity="0"/></radialGradient>
      <filter id="hxRfB" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2"/></filter></defs>
      <circle class="rf-halo" cx="150" cy="150" r="148" fill="url(#hxRfG)"/>
      <path class="rf-ticks" d="${ticks.join('')}"/>
      <g class="rf-a"><circle cx="150" cy="150" r="136" pathLength="100" stroke-dasharray="18 4 6 4 26 6 9 27"/></g>
      <g class="rf-b"><circle cx="150" cy="150" r="124" pathLength="100" stroke-dasharray="2 2"/></g>
      <g class="rf-c"><circle cx="150" cy="150" r="112" pathLength="100" stroke-dasharray="9 91"/><circle class="blur" cx="150" cy="150" r="112" pathLength="100" stroke-dasharray="9 91"/></g>
      <g class="rf-d"><circle cx="150" cy="150" r="142" pathLength="100" stroke-dasharray="3 22 2 30 4 39"/></g>
      <g class="rf-e"><circle cx="150" cy="150" r="98" pathLength="100" stroke-dasharray="30 70"/></g>
    </svg>`;
  }

  /* ---------- Calendar: Agenda (Molly's own list, with prep and joining), Day, Week and Month ---------- */
  let calMode = 'week', calAnchor = new Date(), calShown = [], calKey = '';
  const calCache = {}, calAt = {};
  const d0 = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
  const addD = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const parseDay = k => { const [y, m, dd] = String(k).split('-').map(Number); return new Date(y, m - 1, dd); };
  const monday = d => { const x = d0(d); return addD(x, -((x.getDay() + 6) % 7)); };
  function calRange() {
    if (calMode === 'day') { const a = d0(calAnchor); return [a, addD(a, 1)]; }
    if (calMode === 'week') { const a = monday(calAnchor); return [a, addD(a, 7)]; }
    const first = new Date(calAnchor.getFullYear(), calAnchor.getMonth(), 1), a = monday(first); return [a, addD(a, 42)];
  }
  function calTitle() {
    const [a, b] = calRange(), f = (d, o) => d.toLocaleDateString('en-GB', o);
    if (calMode === 'day') return f(a, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    if (calMode === 'week') { const e = addD(b, -1); return a.getMonth() === e.getMonth() ? `${a.getDate()}–${f(e, { day: 'numeric', month: 'long', year: 'numeric' })}` : `${f(a, { day: 'numeric', month: 'short' })} – ${f(e, { day: 'numeric', month: 'short', year: 'numeric' })}`; }
    return f(calAnchor, { month: 'long', year: 'numeric' });
  }
  function calControls() {
    const seg = ['agenda', 'day', 'week', 'month'].map(m => `<button type="button" class="hx-seg ${calMode === m ? 'on' : ''}" data-hx-cmode="${m}" aria-pressed="${calMode === m}">${m[0].toUpperCase() + m.slice(1)}</button>`).join('');
    const nav = calMode === 'agenda' ? '' : `<span class="hx-cnav"><button type="button" data-hx-cnav="prev" aria-label="Previous">${ICON.left}</button><button type="button" class="hx-today" data-hx-cnav="today">Today</button><button type="button" data-hx-cnav="next" aria-label="Next">${ICON.right}</button><b id="hxCalT" aria-live="polite">${esc(calTitle())}</b></span>`;
    return `<span class="hx-segs">${seg}</span>${nav}`;
  }
  function setCalMode(m) {
    calMode = m;
    if (m === 'agenda') { ownView = null; if (tabNow() !== 'calendar') H.tab('calendar'); showWin('calendar'); return; }
    ownView = 'calendar'; if (tabNow() !== 'overview') H.tab('overview'); showWin('calendar');
  }
  function calNav(dir) {
    if (dir === 'today') calAnchor = new Date();
    else { const n = dir === 'next' ? 1 : -1; calAnchor = calMode === 'day' ? addD(calAnchor, n) : calMode === 'week' ? addD(calAnchor, 7 * n) : new Date(calAnchor.getFullYear(), calAnchor.getMonth() + n, 1); }
    $('hxWCtl').innerHTML = calControls();
    const o = $('hxOwn'); o.classList.remove('hx-slide'); void o.offsetWidth; o.classList.add('hx-slide');
    renderCal(true);
  }
  // which days an event covers (all-day events can run for several days)
  function evDays(e) {
    if (e.allDay) { const a = parseDay(String(e.start).slice(0, 10)), b = e.end ? parseDay(String(e.end).slice(0, 10)) : addD(a, 1); const out = []; for (let d = a; d < b && out.length < 62; d = addD(d, 1)) out.push(ymd(d)); return out.length ? out : [ymd(a)]; }
    const a = new Date(e.start), b = new Date(e.end || e.start), out = [];
    for (let d = parseDay(ymd(a)); (d < b || !out.length) && out.length < 62; d = addD(d, 1)) out.push(ymd(d));
    return out;
  }
  // minutes of the event that fall on day k (0–1440)
  const span = (e, k) => { const d0 = parseDay(k).getTime(), s = new Date(e.start).getTime(), en = new Date(e.end || e.start).getTime() || s; return [Math.max(0, (s - d0) / 60e3), Math.min(1440, Math.max((en - d0) / 60e3, (s - d0) / 60e3 + 15))]; };
  const mins = iso => { const d = new Date(iso); return d.getHours() * 60 + d.getMinutes(); };
  const tm = iso => new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  function renderCal(force) {
    const [a, b] = calRange(), key = calMode + ymd(a);
    if (!force && key === calKey) return;
    calKey = key;
    if (calCache[key] === null || Date.now() - (calAt[key] || 0) > 5 * 60e3) calCache[key] = undefined;
    const list = calCache[key];
    if (list === undefined) {
      $('hxOwn').innerHTML = `<div class="hx-cal-load"><span class="hx-spin"></span> Loading your calendar…</div>`;
      Promise.resolve(H.calRange(a.toISOString(), b.toISOString())).then(L => { calCache[key] = L; calAt[key] = Date.now(); if (calKey === key && ownView === 'calendar') { calKey = ''; renderCal(true); } });
      return;
    }
    if (list === null) { $('hxOwn').innerHTML = `<p class="hx-empty">Connect Google in Molly’s menu to see your calendar.</p>`; return; }
    calShown = list.filter(e => !e.free || e.allDay);
    const idx = e => calShown.indexOf(e);
    const color = e => esc(e.calHex || '#3fd8ff');
    const today = ymd(new Date());
    if (calMode === 'month') {
      const cells = [];
      for (let i = 0; i < 42; i++) {
        const d = addD(a, i), k = ymd(d), evs = calShown.filter(e => evDays(e).includes(k));
        const out = d.getMonth() !== calAnchor.getMonth();
        cells.push(`<button type="button" class="hx-mc ${out ? 'out' : ''} ${k === today ? 'today' : ''}" data-hx-cday="${k}"><span class="n">${d.getDate()}</span>${evs.slice(0, 3).map(e => `<span class="hx-mchip" style="--c:${color(e)}">${e.allDay ? '' : `<i>${tm(e.start)}</i>`}${esc(e.title)}</span>`).join('')}${evs.length > 3 ? `<span class="hx-more">+${evs.length - 3} more</span>` : ''}</button>`);
      }
      const heads = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(x => `<span>${x}</span>`).join('');
      $('hxOwn').innerHTML = `<div class="hx-month"><div class="hx-mh">${heads}</div><div class="hx-mg">${cells.join('')}</div></div>`;
      return;
    }
    // Day and Week: a time grid
    const days = calMode === 'day' ? [a] : [0, 1, 2, 3, 4, 5, 6].map(i => addD(a, i));
    const timed = calShown.filter(e => !e.allDay);
    let h0 = 7, h1 = 21;
    for (const e of timed) for (const d of days) { const k = ymd(d); if (!evDays(e).includes(k)) continue; const [x0, x1] = span(e, k); h0 = Math.min(h0, Math.floor(x0 / 60)); h1 = Math.max(h1, Math.min(24, Math.ceil(x1 / 60))); }
    const HH = 44, hours = []; for (let h = h0; h < h1; h++) hours.push(h);
    const col = d => {
      const k = ymd(d), evs = timed.filter(e => evDays(e).includes(k)).sort((x, y) => span(x, k)[0] - span(y, k)[0]);
      // side by side when meetings overlap
      const lanes = []; const place = [];
      for (const e of evs) { const [s0, s1] = span(e, k); let l = lanes.findIndex(end => end <= s0); if (l < 0) { l = lanes.length; lanes.push(s1); } else lanes[l] = s1; place.push({ e, s0, s1, l }); }
      const n = Math.max(1, lanes.length);
      const blocks = place.map(({ e, s0, s1, l }) => `<button type="button" class="hx-blk${(s1 - s0) < 45 ? ' short' : ''}" data-hx-ev="${idx(e)}" style="--c:${color(e)};top:${(s0 - h0 * 60) / 60 * HH}px;height:${Math.max(20, (s1 - s0) / 60 * HH - 2)}px;left:calc(${l / n * 100}% + 2px);width:calc(${100 / n}% - 4px)"><b>${esc(e.title)}</b><small>${tm(e.start)}${e.end ? '–' + tm(e.end) : ''}${e.location ? ' · ' + esc(e.location) : e.join ? ' · Online' : ''}</small></button>`).join('');
      const now = new Date(), nowLine = k === today && now.getHours() >= h0 && now.getHours() < h1 ? `<i class="hx-now-line" style="top:${(now.getHours() * 60 + now.getMinutes() - h0 * 60) / 60 * HH}px"></i>` : '';
      return `<div class="hx-dcol ${k === today ? 'today' : ''}" style="height:${hours.length * HH}px">${hours.map((h, i) => `<i class="hx-hl" style="top:${i * HH}px"></i>`).join('')}${blocks}${nowLine}</div>`;
    };
    const allDay = d => calShown.filter(e => e.allDay && evDays(e).includes(ymd(d))).map(e => `<button type="button" class="hx-ad" data-hx-ev="${idx(e)}" style="--c:${color(e)}">${esc(e.title)}</button>`).join('');
    const heads = days.map(d => `<div class="hx-dh ${ymd(d) === today ? 'today' : ''}"><small>${d.toLocaleDateString('en-GB', { weekday: 'short' })}</small><b>${d.getDate()}</b><div class="hx-ads">${allDay(d)}</div></div>`).join('');
    $('hxOwn').innerHTML = `<div class="hx-tg ${calMode}" style="--n:${days.length}"><div class="hx-tgh"><span></span>${heads}</div>
      <div class="hx-tgb"><div class="hx-hrs">${hours.map(h => `<span style="height:${HH}px">${String(h).padStart(2, '0')}:00</span>`).join('')}</div>${days.map(col).join('')}</div>
      ${!calShown.length ? `<p class="hx-empty">Nothing in your calendar ${calMode === 'day' ? 'this day' : 'this week'}.</p>` : ''}</div>`;
    const sc = $('hxWB'); const first = $('hxOwn').querySelector('.hx-blk'); if (first && force) sc.scrollTop = Math.max(0, first.offsetTop - 60);
  }

  /* ---------- Notepad: the notes Molly keeps while you go through the briefing ---------- */
  function deckHasNotes() { const d = $('hDeck'); return !!(d && d.textContent.trim() && !d.querySelector('[data-ph]')); }
  const notesEmpty = () => `<div class="hx-note-empty">${ICON.note}<h3>No notes yet</h3><p>When you go through your briefing, Molly keeps the notes here: open points, emails and what you decided.</p><button type="button" class="btn small" data-hx-press="hGo">☀️ Start my briefing</button></div>`;

  /* ---------- Files: your OneDrive, from the index Molly keeps on this Mac ---------- */
  const OPEN_TASK = 'trig_01LSdML9n6iEUbwQG2okXiRF', INDEX_TASK = 'trig_01CcWEpXww8uas3Gb1JyRXZ7';
  const FL = { idx: null, docs: {}, sec: null, path: '', loaded: false, opening: {} };
  const use = k => (window.claude && window.claude.use) ? window.claude.use(k) : Promise.resolve(null);
  async function filesLoad() {
    const db = await use('db'); if (!db) { FL.loaded = true; return; }
    try { const sn = await db.doc('meta/filesIndex').get(); FL.idx = sn.exists ? sn.data() : null; } catch {}
    try { const qs = await db.collection('files').get(); FL.docs = {}; (qs.docs || []).forEach(d => { FL.docs[d.id] = d.data(); }); } catch {}
    FL.loaded = true;
  }
  const fsz = b => !b ? '' : b < 1024 ? b + ' B' : b < 1048576 ? Math.round(b / 1024) + ' KB' : (b / 1048576).toFixed(1) + ' MB';
  const fic = n => { const e = String(n).split('.').pop().toLowerCase(); return /^pdf$/.test(e) ? '📕' : /^(jpe?g|png|heic|gif|webp)$/.test(e) ? '🖼️' : /^(xlsx?|csv|numbers)$/.test(e) ? '📊' : /^(docx?|pages|txt|rtf)$/.test(e) ? '📄' : /^(pptx?|key)$/.test(e) ? '📽️' : '📎'; };
  function sections() {
    const ix = FL.idx;
    if (ix && Array.isArray(ix.sections) && ix.sections.length) return ix.sections.map(x => ({ id: x.id, name: x.name, total: x.total }));
    const fl = (window.__folderList ? window.__folderList() : []) || [];
    return [...new Set(fl.map(p => String(p).split('/')[0]).filter(Boolean))].sort().map(n => ({ id: null, name: n, total: null }));
  }
  function dirsOf(sec) {
    const d = sec.id && FL.docs[sec.id]; if (d && d.dirs) return d.dirs;
    const o = {}; ((window.__folderList ? window.__folderList() : []) || []).filter(p => p === sec.name || p.startsWith(sec.name + '/')).forEach(p => { o[p] = { files: [] }; }); return o;
  }
  async function renderFiles(force) {
    if (!FL.loaded) { $('hxOwn').innerHTML = `<div class="hx-cal-load"><span class="hx-spin"></span> Opening your OneDrive…</div>`; await filesLoad(); if (ownView !== 'files') return; }
    const secs = sections();
    if (!FL.sec && secs.length) { FL.sec = secs[0]; FL.path = secs[0].name; }
    const ix = FL.idx, st = ix && ix.status === 'working' ? 'Indexing your OneDrive…' : ix && ix.at ? `Indexed ${new Date(ix.at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}${ix.files ? ' · ' + Number(ix.files).toLocaleString('en-GB') + ' files' : ''}` : 'Not indexed yet: press Re-index';
    const tabs = secs.map(x => `<button type="button" class="hx-ftab ${FL.sec && FL.sec.name === x.name ? 'on' : ''}" data-hx-files="sec" data-n="${esc(x.name)}">${ICON.folder}<span>${esc(x.name)}</span>${x.total != null ? `<small>${Number(x.total) || 0}</small>` : ''}</button>`).join('');
    let body = '';
    if (FL.sec) {
      const dirs = dirsOf(FL.sec), path = FL.path || FL.sec.name;
      const kids = Object.keys(dirs).filter(k => k.startsWith(path + '/') && k.slice(path.length + 1).split('/').length === 1).sort((x, y) => x.localeCompare(y));
      const here = dirs[path] || { files: [] }, files = (here.files || []).slice().sort((x, y) => String(y.m || '').localeCompare(String(x.m || '')));
      const crumbs = path.split('/');
      const bc = crumbs.map((c, j) => j === crumbs.length - 1 ? `<b>${esc(c)}</b>` : `<button type="button" data-hx-files="path" data-p="${esc(crumbs.slice(0, j + 1).join('/'))}">${esc(c)}</button>`).join('<i>›</i>');
      const rows = [...kids.map(k => `<button type="button" class="hx-frow dir" data-hx-files="path" data-p="${esc(k)}"><span>📁</span><b>${esc(k.split('/').pop())}</b><small>${dirs[k] && dirs[k].total != null ? (Number(dirs[k].total) || 0) + ' files' : ''}</small><em>›</em></button>`),
        ...files.map(x => { const fp = path + '/' + x.n, o = FL.opening[fp]; return `<button type="button" class="hx-frow" data-hx-files="open" data-p="${esc(fp)}"><span>${fic(x.n)}</span><b>${esc(x.n)}</b><small>${x.m ? esc(new Date(x.m).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })) : ''} ${esc(fsz(x.s))}</small><em>${o ? (o === 'done' ? '✓ Opened' : o === 'failed' ? 'Couldn’t open' : 'Opening…') : 'Open'}</em></button>`; })];
      body = `<div class="hx-fbc">${bc}</div><div class="hx-flist">${rows.join('') || `<p class="hx-empty">${FL.sec.id && FL.docs[FL.sec.id] ? 'This folder is empty.' : 'File lists appear after the next index.'}</p>`}</div>`;
    }
    if (!secs.length) { $('hxOwn').innerHTML = `<div class="hx-note-empty">${ICON.folder}<h3>${ix && ix.status === 'working' ? 'Indexing your OneDrive…' : 'Your OneDrive files will show here'}</h3><p>Press <b>Re-index</b> and Molly lists your OneDrive folders on this Mac (it also does this every morning). If no OneDrive folder is chosen yet, open the Molly menu → <b>Set up again…</b> and pick it.</p><button type="button" class="hx-wbtn" data-hx-files="reindex">${ICON.refresh} Re-index now</button></div>`; return; }
    $('hxOwn').innerHTML = `<div class="hx-files"><div class="hx-fside"><div class="hx-fst">${esc(st)}</div>${tabs || '<p class="hx-empty">No OneDrive folder is set up in Molly yet.</p>'}</div><div class="hx-fmain">${body}</div></div>`;
  }
  async function filesAct(t) {
    const a = t.dataset.hxFiles;
    if (a === 'sec') { FL.sec = sections().find(x => x.name === t.dataset.n) || null; FL.path = FL.sec ? FL.sec.name : ''; return renderFiles(true); }
    if (a === 'path') { FL.path = t.dataset.p; $('hxWB').scrollTop = 0; return renderFiles(true); }
    if (a === 'reindex') {
      const mcp = await use('mcp'); if (!mcp) return;
      t.disabled = true;
      try { await mcp.callTool('Claude Code Remote', 'fire_trigger', { trigger_id: INDEX_TASK, text: 'Re-index requested from the Holo screen.' }); FL.idx = { ...(FL.idx || {}), status: 'working' }; renderFiles(true); setTimeout(() => { FL.loaded = false; if (ownView === 'files') renderFiles(true); }, 90000); }
      catch { t.disabled = false; }
      return;
    }
    if (a === 'open') {
      // ask this Mac to open the file in its normal app (the same request the old filing cabinet made)
      const fp = t.dataset.p, db = await use('db'), mcp = await use('mcp'); if (!db || !mcp) return;
      const id = 'f' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      FL.opening[fp] = 'new'; renderFiles(true);
      try {
        await db.doc('fileopen/' + id).set({ path: fp, status: 'new', at: new Date().toISOString() });
        const un = db.doc('fileopen/' + id).onSnapshot(sn => { if (!sn.exists) return; const d = sn.data(); if (d.status === 'done' || d.status === 'failed') { FL.opening[fp] = d.status; try { un(); } catch {} if (ownView === 'files') renderFiles(true); } }, () => {});
        await mcp.callTool('Claude Code Remote', 'fire_trigger', { trigger_id: OPEN_TASK, text: JSON.stringify({ requestId: id, path: fp }) });
      } catch { FL.opening[fp] = 'failed'; renderFiles(true); }
    }
  }

  /* ---------- Places I've been: the pins on the globe ---------- */
  function renderPlaces() {
    const G = window.__mollyGlobe; const L = G ? G.places() : [];
    const rows = L.map((p, i) => `<div class="hx-plc"><span class="pin"></span><b>${esc(p.name)}</b><small>${esc(p.country || '')}</small><button type="button" data-hx-place="remove" data-n="${esc(p.name)}" data-c="${esc(p.cc || '')}" aria-label="Remove ${esc(p.name)}">✕</button></div>`).join('');
    $('hxOwn').innerHTML = `<div class="hx-places">
      <div class="hx-padd"><input id="hxPlaceQ" aria-label="Add a place" placeholder="Add a city, e.g. Paris" autocomplete="off"><button type="button" class="btn small primary" data-hx-place="add">Add</button></div>
      <div class="hx-psug" id="hxPlaceSug"></div>
      <details class="hx-ppaste"><summary>Paste a list</summary><textarea id="hxPlaceList" aria-label="Places, one per line" rows="3" placeholder="Paris, Rome, New York"></textarea><button type="button" class="btn small" data-hx-place="paste">Add these</button><span id="hxPlaceMsg"></span></details>
      <div class="hx-plist">${rows || '<p class="hx-empty">No places yet. Add the cities you’ve been to and they light up on the globe.</p>'}</div></div>`;
    const q = $('hxPlaceQ');
    let seq = 0; q.addEventListener('input', async () => { const my = ++seq; const m = G ? await G.search(q.value, 6) : []; if (my !== seq) return; $('hxPlaceSug').innerHTML = m.map((c, i) => `<button type="button" class="hx-sugg" data-hx-place="pick" data-i="${i}">${esc(c.name)} <small>${esc(c.country)}</small></button>`).join(''); FL.sugg = m; });
    q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); const b = root.querySelector('[data-hx-place="add"]'); if (b) b.click(); } });
  }
  // "Hallstatt 47.56 13.65" (name plus map position) for places too small for the built-in list
  async function placeOf(v) {
    const c = String(v || '').trim().match(/^(.+?)[\s,]+(-?\d{1,2}(?:\.\d+)?)[\s,]+(-?\d{1,3}(?:\.\d+)?)$/);
    if (c && Math.abs(+c[2]) <= 90 && Math.abs(+c[3]) <= 180) return { name: c[1].trim(), cc: '', country: '', lat: +c[2], lon: +c[3] };
    const m = await window.__mollyGlobe.search(v, 1); return m[0] || null;
  }
  async function placesAct(t) {
    const G = window.__mollyGlobe; if (!G) return;
    const a = t.dataset.hxPlace;
    if (a === 'remove') { await G.remove(t.dataset.n, t.dataset.c); return renderPlaces(); }
    if (a === 'pick') { const c = (FL.sugg || [])[+t.dataset.i]; if (c) await G.add([c]); return renderPlaces(); }
    if (a === 'add') {
      const v = $('hxPlaceQ').value, m = await placeOf(v); if (m) { await G.add([m]); return renderPlaces(); }
      if (v.trim()) $('hxPlaceSug').innerHTML = `<span class="hx-pmiss">“${esc(v.trim())}” isn’t in Molly’s list, which only has towns of 15,000+ people. Try the nearest town, or add its map position, e.g. <b>Hallstatt 47.56 13.65</b>.</span>`;
      return;
    }
    if (a === 'paste') {
      const parts = $('hxPlaceList').value.split(/[;\n]+/).map(x => x.trim()).filter(Boolean), found = [], missing = [];
      for (const p of parts) { const m = await placeOf(p); if (m) found.push(m); else missing.push(p); }
      await G.add(found); renderPlaces();
      if (missing.length) { const msg = $('hxPlaceMsg'); if (msg) msg.textContent = 'Couldn’t find: ' + missing.join(', '); }
    }
  }

  /* ---------- clicks ---------- */
  let pendingWatch = false;
  function press(id) { const b = $(id); if (b && !b.disabled) b.click(); }
  const srcOf = t => { const p = t.closest('.hx-p') || t; return p.getBoundingClientRect(); };
  function onClick(e) {
    const t = e.target.closest('button'); if (!t || !root.contains(t)) return;
    if (t.dataset.hxMeeting) return H.meeting(t.dataset.hxMeeting);
    if (t.dataset.hxPoint) { fromRect = srcOf(t); return H.point(t.dataset.hxPoint); }
    if (t.dataset.hxMail) { fromRect = srcOf(t); return H.openMail(t.dataset.hxMail); }
    if (t.dataset.hxOpen) return openView(t.dataset.hxOpen, srcOf(t));
    if (t.dataset.hxSay === 'markets') return H.markets();
    if (t.dataset.hxCmode) return setCalMode(t.dataset.hxCmode);
    if (t.dataset.hxCnav) return calNav(t.dataset.hxCnav);
    if (t.dataset.hxCday) { calAnchor = parseDay(t.dataset.hxCday); return setCalMode('day'); }
    if (t.dataset.hxEv) { const ev = calShown[+t.dataset.hxEv]; if (ev) H.showEvent(ev); return; }
    if (t.dataset.hxFiles) return filesAct(t);
    if (t.dataset.hxPlace) return placesAct(t);
    if (t.dataset.hxDock) {
      const k = t.dataset.hxDock;
      if (k === 'watchlist') { pendingWatch = true; return openView('bills', t.getBoundingClientRect()); }
      return openView(k, t.getBoundingClientRect());
    }
    if (t.dataset.hxPress) return press(t.dataset.hxPress);
    if (t.dataset.hxChip) { const c = document.querySelector('#hChips ' + t.dataset.hxChip); if (c) c.click(); return; }
    switch (t.id) {
      case 'hxBot': try { window.__mollyHoloBot && window.__mollyHoloBot.wave(); } catch {} return press('bot');
      case 'hxTalk': return press('hMic');
      case 'hxSound': press('hmSound'); return setTimeout(mirror, 50);
      case 'hxSet': return press('hmSettings');
      case 'hxWClose': return closeView();
      case 'hxWMat': return H.matters();
      case 'hxGlobe': return openView('places', t.getBoundingClientRect());
    }
  }

  /* ---------- keeping it in step with the page ---------- */
  const STATE = { idle: 'Ready', waiting: 'Your turn', thinking: 'Thinking…', speaking: 'Speaking' };
  function mirror() {
    if (!root) return;
    const st = $('hStage'), mic = $('hMic'), snd = $('hmSound');
    const s = (st && st.dataset.state) || 'idle';
    // the conversation mode (speech.js) says when Molly is listening, and what she has heard so far
    const vs = document.documentElement.dataset.mollyVoice || '', sp = window.__mollySpeech;
    const convo = vs === 'listening' || vs === 'follow-up';
    const listening = convo || (!!mic && mic.getAttribute('aria-pressed') === 'true');
    core.dataset.state = s; core.classList.toggle('listening', listening);
    const fx = $('hxRingFx'); if (fx) fx.dataset.state = listening ? 'listening' : s;
    $('hxState').textContent = listening ? (vs === 'follow-up' ? 'Still listening…' : 'Listening…') : (STATE[s] || 'Ready');
    $('hxState').dataset.state = listening ? 'listening' : s;
    $('hxTalk').setAttribute('aria-pressed', String(listening));
    const heard = convo && sp && sp.live ? sp.live : '';
    const cap = heard ? '“' + heard + '”' : convo ? '' : (($('hCap') && $('hCap').textContent.trim()) || '');
    const c = $('hxCap');
    c.classList.toggle('you', !!heard);
    if (cap) { if (c.textContent !== cap) c.textContent = cap; c.classList.remove('ask'); } else { c.textContent = convo ? 'I’m listening…' : 'How can I help you today?'; c.classList.add('ask'); }
    if (snd) { const on = snd.getAttribute('aria-pressed') === 'true'; const b = $('hxSound'); if (b.dataset.on !== String(on)) { b.dataset.on = String(on); b.title = on ? 'Sound on' : 'Sound off'; b.setAttribute('aria-label', b.title); b.innerHTML = on ? ICON.soundOn : ICON.soundOff; } }
    let stop = $('hxStop');
    if (s === 'speaking' && !stop) {
      stop = document.createElement('button'); stop.id = 'hxStop'; stop.type = 'button'; stop.className = 'hx-stop'; stop.textContent = '■ Stop';
      stop.addEventListener('click', () => press('hStop'));
      $('hxState').after(stop);
    } else if (s !== 'speaking' && stop) stop.remove();
  }

  function greet() {
    const h = +tfmt(Date.now(), { hour: '2-digit', hour12: false });
    const hi = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
    return FIRST ? `${hi}, ${FIRST}.` : `${hi}.`;
  }

  function paint(force) {
    let d; try { d = H.peek(); } catch { return; }
    $('hxTime').textContent = hm(Date.now());
    $('hxDate').textContent = tfmt(Date.now(), { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    $('hxHi').textContent = greet();
    const brand = String(d.name || 'Molly').toUpperCase(); if ($('hxBrand').textContent !== brand) $('hxBrand').textContent = brand;
    const put = (id, key, html) => { if (force || sig[id] !== key) { sig[id] = key; $(id).innerHTML = html(); } };
    const minute = Math.floor(Date.now() / 6e4);
    put('hxMail', JSON.stringify([d.unread, (d.unreadTop || []).map(t => t.id + t.date), d.mcp, minute >> 4]), () => pMail(d));
    put('hxCal', JSON.stringify([(d.events || []).map(e => e.id + e.start + e.title), d.eventsLoaded, d.mcp, minute]), () => pCal(d));
    put('hxPts', JSON.stringify([d.points, d.db]), () => pPoints(d));
    put('hxWx', JSON.stringify([d.weather && d.weather.at, d.weather && d.weather.now]), () => pWx(d));
    put('hxMkt', JSON.stringify([d.markets && d.markets.at, d.markets && d.markets.status, (d.markets && d.markets.quotes || []).map(q => q.price)]), () => pMkt(d));
    put('hxBills', JSON.stringify(d.renewals), () => pBills(d));
    renderOwn(false);
    fit();
    return d;
  }

  // Show only the rows that fit in each panel (no half-cut rows).
  function fit() {
    if (!root) return;
    for (const pb of root.querySelectorAll('.hx-p .hx-pb')) {
      const rows = [...pb.children]; rows.forEach(r => r.classList.remove('hx-cut'));
      const max = pb.clientHeight; if (!max) continue;
      let cut = false;
      for (const r of rows) if (cut || r.offsetTop - pb.offsetTop + r.offsetHeight > max - 3) { cut = true; r.classList.add('hx-cut'); }
    }
  }

  function update(force) {
    if (!root) return;
    let d = null; try { d = H.peek(); } catch {}
    // Holo needs the page without its 3D room (it is held back at start-up in Holo mode)
    const want = pref() === 'holo' && BIG.matches && !(d && d.room);
    if (want === shown && !force) return;
    shown = want;
    root.classList.toggle('off', !want);
    document.documentElement.classList.toggle('hx-on', want);
    attach(want);
    try { window.__mollyHoloBot && window.__mollyHoloBot.show(want); } catch {}
    try { window.__mollyGlobe && window.__mollyGlobe.show(want); } catch {}
    layout();
    if (want) { paint(true); mirror(); syncView(); } else { attachWrap(false); view = null; ownView = null; win.hidden = true; root.classList.remove('hx-max'); }
  }

  function start() {
    H = window.__mollyHolo;
    if (!H || !$('home')) return false;
    build();
    const mo = new MutationObserver(() => { mirror(); update(); syncView(); });
    const watch = (el, opts) => { if (el) mo.observe(el, opts); };
    watch($('hStage'), { attributes: true, attributeFilter: ['data-state'] });
    watch($('hSide'), { attributes: true, attributeFilter: ['data-tab'] });
    watch(document.body, { attributes: true, attributeFilter: ['class'] });
    watch($('hCap'), { childList: true, characterData: true, subtree: true });
    watch($('hMic'), { attributes: true, attributeFilter: ['aria-pressed'] });
    watch($('hmSound'), { attributes: true, attributeFilter: ['aria-pressed'] });
    watch(document.documentElement, { attributes: true, attributeFilter: ['data-molly-voice'] });
    watch($('hYou'), { childList: true, characterData: true, subtree: true });
    window.addEventListener('molly-voice', () => mirror());
    setInterval(() => { if (shown) paint(false); update(); }, 1000);
    paint(true); mirror(); update(true);
    return true;
  }

  const boot = () => { let n = 0; const t = setInterval(() => { if (start() || ++n > 120) clearInterval(t); }, 250); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

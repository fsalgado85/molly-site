/* Molly.app: ElevenLabs voice for the unchanged Molly page.
   The page speaks with the browser's speechSynthesis. When an ElevenLabs voice is set up (Molly menu →
   Molly's Voice…), this file stands in for speechSynthesis: each sentence is turned into audio by
   ElevenLabs (through Molly's local server, which holds the key) and played, firing the same events
   (start, boundary, end) the page listens to. If ElevenLabs isn't set up, the month's credits run out,
   or anything fails, sentences go to the Mac's own voice instead, so Molly never goes quiet. */
(function () {
  'use strict';
  const native = window.speechSynthesis;
  if (!native) return;
  const BOOT = window.__MOLLY_BOOT || {};
  const TOKEN = BOOT.token || new URLSearchParams(location.search).get('t') || '';

  let state = { active: false };
  async function refresh(force) {
    try {
      const r = await fetch('/api/tts/status' + (force ? '?refresh=1' : ''), { headers: { 'x-molly-token': TOKEN } });
      state = await r.json();
    } catch { state = { active: false }; }
    return state;
  }
  refresh();
  setInterval(refresh, 10 * 60 * 1000);
  window.addEventListener('focus', () => refresh());

  const fire = (u, type, extra) => {
    const ev = Object.assign({ type, utterance: u, charIndex: 0, elapsedTime: 0, name: '' }, extra || {});
    try { const h = u['on' + type]; if (typeof h === 'function') h.call(u, ev); } catch (e) { console.error(e); }
  };

  const queue = [];       // { u, audio: Promise<Blob|Error> }
  let current = null;     // { u, el, url, timer }
  let gen = 0;
  let paused = false;

  function fetchAudio(u) {
    const ctl = new AbortController();
    const p = fetch('/api/tts', {
      method: 'POST', signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-molly-token': TOKEN },
      body: JSON.stringify({ text: u.text, rate: u.rate || 1 }),
    }).then(async r => {
      const type = r.headers.get('content-type') || '';
      if (type.startsWith('audio/')) return r.blob();
      let j = {}; try { j = await r.json(); } catch {}
      const e = new Error(j.message || 'voice failed'); e.code = j.code || 'failed'; throw e;
    });
    p.catch(() => {});
    return { p, ctl };
  }

  // Ask ElevenLabs for the next two sentences while the current one plays, so there are no gaps.
  function ahead() {
    for (const q of queue.slice(0, 2)) if (!q.req && state.active) q.req = fetchAudio(q.u);
  }

  function toNative(item) {
    // Hand this and every following queued sentence to the Mac's voice, in order.
    native.speak(item.u);
  }

  async function pump() {
    if (current || paused || !queue.length) return;
    const g = gen;
    const item = queue.shift();
    ahead();
    current = { u: item.u };
    let blob;
    try {
      if (!item.req) item.req = fetchAudio(item.u);
      blob = await item.req.p;
    } catch (e) {
      if (g !== gen) return;
      current = null;
      if (e.code === 'quota' || e.code === 'bad_key' || e.code === 'disabled' || e.code === 'not_configured' || e.code === 'no_voice') state.active = false;
      try { window.mollyNative?.log?.('warn', 'ElevenLabs voice: ' + (e.code || e.message) + ' — using the Mac voice'); } catch {}
      toNative(item);
      while (queue.length) toNative(queue.shift());
      return;
    }
    if (g !== gen) return;
    const url = URL.createObjectURL(blob);
    const el = new Audio(url);
    el.volume = item.u.volume == null ? 1 : item.u.volume;
    current = { u: item.u, el, url, timer: null };
    let started = false;
    const finish = (type, extra) => {
      if (!current || current.el !== el) return;
      clearInterval(current.timer); URL.revokeObjectURL(url);
      current = null;
      fire(item.u, type, extra);
      pump();
    };
    el.onplaying = () => {
      if (started) return; started = true;
      fire(item.u, 'start');
      current.timer = setInterval(() => { if (!el.paused) fire(item.u, 'boundary', { name: 'word', elapsedTime: el.currentTime * 1000 }); }, 220);
    };
    el.onended = () => finish('end', { elapsedTime: el.currentTime * 1000 });
    el.onerror = () => finish('error', { error: 'audio-hardware' });
    try { await el.play(); }
    catch (e) {
      if (current && current.el === el) { clearInterval(current.timer); URL.revokeObjectURL(url); current = null; }
      toNative(item); while (queue.length) toNative(queue.shift());
    }
  }

  // what Molly said in the last 20 seconds, so her own voice isn't mistaken for you interrupting her
  const recent = [];
  window.__mollyTTSRecent = () => { const t = Date.now(); while (recent.length && t - recent[0].at > 20000) recent.shift(); return recent.map(r => r.text).join(' '); };
  const stand = {
    speak(u) {
      if (!u) return;
      const text = String(u.text || '').trim();
      if (text && u.volume !== 0) { recent.push({ at: Date.now(), text }); if (recent.length > 40) recent.shift(); }
      // silent "unlock" utterances and anything while ElevenLabs is off go straight to the Mac voice
      if (!state.active || !text || u.volume === 0 || native.speaking || native.pending) return native.speak(u);
      queue.push({ u, req: null });
      ahead();
      pump();
    },
    cancel() {
      gen++;
      for (const q of queue) { try { q.req?.ctl.abort(); } catch {} }
      queue.length = 0;
      if (current) {
        const c = current; current = null;
        clearInterval(c.timer);
        if (c.el) { try { c.el.pause(); } catch {} if (c.url) URL.revokeObjectURL(c.url); }
      }
      paused = false;
      native.cancel();
    },
    pause() { paused = true; if (current?.el) current.el.pause(); native.pause(); },
    resume() { if (paused) { paused = false; if (current?.el) current.el.play().catch(() => {}); else pump(); } native.resume(); },
    getVoices() { return native.getVoices(); },
    get speaking() { return !!current || native.speaking; },
    get pending() { return queue.length > 0 || native.pending; },
    get paused() { return paused || native.paused; },
    get onvoiceschanged() { return native.onvoiceschanged; },
    set onvoiceschanged(fn) { native.onvoiceschanged = fn; },
    addEventListener: (...a) => native.addEventListener(...a),
    removeEventListener: (...a) => native.removeEventListener(...a),
    mollyStatus: () => state,
    mollyRefresh: () => refresh(true),
  };
  try { Object.defineProperty(window, 'speechSynthesis', { value: stand, configurable: true, writable: false }); }
  catch (e) { console.error('ElevenLabs voice not installed', e); }
})();

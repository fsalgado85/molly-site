// First-run setup wizard: the work behind each screen. Long jobs report progress that the
// wizard page polls. Never handles Claude credentials: sign-in happens in Anthropic's own flow.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { findClaude, claudeEnv, authStatus, authStatusAsync, claudeVersionAsync } from './claude.mjs';
import { oneDriveDirs } from './paths.mjs';

const GH = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/';
// Voice files. New installs get Parakeet (accurate, punctuated English speech recognition). Older installs
// have Moonshine, which still works until the upgrade arrives.
export const PARAKEET = { url: GH + 'asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2', file: 'sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2', dir: 'sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8', size: 482468385, check: ['encoder.int8.onnx', 'decoder.int8.onnx', 'joiner.int8.onnx', 'tokens.txt'] };
export const VAD = { url: GH + 'asr-models/silero_vad.onnx', file: 'silero_vad.onnx', size: 644000 };
export const ASR_FILES = ['preprocess.onnx', 'encode.int8.onnx', 'uncached_decode.int8.onnx', 'cached_decode.int8.onnx', 'tokens.txt'];
export const MOONSHINE = { url: GH + 'asr-models/sherpa-onnx-moonshine-base-en-int8.tar.bz2', file: 'sherpa-onnx-moonshine-base-en-int8.tar.bz2', dir: 'sherpa-onnx-moonshine-base-en-int8', size: 251000000, check: ASR_FILES };
export const MODEL_FILES = { vad: VAD, asr: PARAKEET };

const hasAll = (modelsDir, f) => !!f.dir && (f.check || []).every(x => fs.existsSync(path.join(modelsDir, f.dir, x)));
/** Which speech recogniser is installed: 'parakeet', 'moonshine' or null. */
export function asrKind(modelsDir) { return hasAll(modelsDir, PARAKEET) ? 'parakeet' : hasAll(modelsDir, MOONSHINE) ? 'moonshine' : null; }
export function modelsReady(modelsDir) {
  return fs.existsSync(path.join(modelsDir, VAD.file)) && !!asrKind(modelsDir);
}
/** The voice files an older install still needs for the better hearing (empty when up to date). */
export function upgradeFiles(modelsDir) {
  return hasAll(modelsDir, PARAKEET) ? {} : { asr: PARAKEET };
}

// ---------- jobs with progress ----------
export class Jobs {
  constructor() { this.map = new Map(); }
  create(kind) {
    const id = crypto.randomBytes(6).toString('hex');
    const job = { id, kind, state: 'running', progress: 0, step: '', lines: [], url: null, error: null, startedAt: Date.now() };
    this.map.set(id, job);
    return job;
  }
  get(id) { return this.map.get(id) || null; }
  line(job, s) { job.lines.push(String(s).replace(/\x1b\[[0-9;?]*[a-zA-Z]/g, '').slice(0, 300)); if (job.lines.length > 60) job.lines.shift(); }
  finish(job, error) { job.state = error ? 'failed' : 'done'; job.error = error ? String(error.message || error) : null; if (!error) job.progress = 1; job.finishedAt = Date.now(); }
}

// ---------- 1. Install Claude Code with the official installer ----------
export const INSTALL_CMD = 'curl -fsSL https://claude.ai/install.sh | bash';
const INSTALL_STEPS = [
  [/download|fetch/i, 0.25, 'Downloading Claude Code…'],
  [/verif|checksum/i, 0.5, 'Checking the download…'],
  [/install|setting up|launcher|shell integration/i, 0.75, 'Installing…'],
  [/success|installed|complete|done/i, 0.95, 'Finishing…'],
];
export function installProgress(line, cur) {
  for (const [re, p, label] of INSTALL_STEPS) if (re.test(line) && p > cur.progress) return { progress: p, step: label };
  return null;
}
export function installClaude(jobs, { command = INSTALL_CMD, shell = '/bin/bash' } = {}) {
  const job = jobs.create('install');
  job.step = 'Starting the official installer…'; job.progress = 0.05;
  const child = spawn(shell, ['-c', command], { env: claudeEnv(), stdio: ['ignore', 'pipe', 'pipe'] });
  const onData = d => {
    for (const l of String(d).split(/\r?\n|\r/)) {
      if (!l.trim()) continue;
      jobs.line(job, l);
      const p = installProgress(l, job);
      if (p) Object.assign(job, p);
    }
  };
  child.stdout.on('data', onData); child.stderr.on('data', onData);
  child.on('error', e => jobs.finish(job, e));
  child.on('close', code => {
    if (job.state !== 'running') return;
    const ok = code === 0 && !!findClaude();
    job.step = ok ? 'Claude Code is installed.' : 'The installer did not finish.';
    jobs.finish(job, ok ? null : new Error(`The installer stopped (code ${code}). Check your internet connection and try again.`));
  });
  return job;
}

// ---------- 2. Sign in with `claude auth login --claudeai` ----------
const URL_RE = /https:\/\/[^\s"'<>]+/g;
export function pickLoginUrl(text) {
  const urls = String(text).match(URL_RE) || [];
  return urls.find(u => /claude\.(ai|com)|anthropic\.com/.test(u) && /oauth|authorize|login|code/i.test(u)) || urls.find(u => /claude\.(ai|com)|anthropic\.com/.test(u)) || null;
}
export function startLogin(jobs, { openExternal = () => {}, claudePath } = {}) {
  const bin = claudePath || findClaude();
  const job = jobs.create('login');
  if (!bin) { jobs.finish(job, new Error('Claude Code is not installed yet.')); return job; }
  job.step = 'Opening the Claude sign-in page…'; job.progress = 0.2;
  // --claudeai: sign in with a Claude subscription (Pro/Max), never with an API key / Console.
  const child = spawn(bin, ['auth', 'login', '--claudeai'], { env: claudeEnv(), stdio: ['pipe', 'pipe', 'pipe'] });
  job.child = child;
  let all = '';
  const onData = d => {
    all += d;
    for (const l of String(d).split(/\r?\n/)) if (l.trim()) jobs.line(job, l);
    if (!job.url) {
      const u = pickLoginUrl(all);
      if (u) {
        job.url = u; job.progress = 0.5;
        job.step = 'Sign in on the Claude page in your browser and press Authorize. If it shows a code, copy it and paste it below.';
        // the CLI usually opens the browser itself ("Opening browser…"); only open it if it didn't say so
        if (!/opening browser|opened/i.test(all)) { try { openExternal(u); } catch {} }
      }
    }
    if (/paste|enter.*code|authorization code/i.test(String(d))) job.needsCode = true;
  };
  child.stdout.on('data', onData); child.stderr.on('data', onData);
  child.on('error', e => jobs.finish(job, e));
  child.on('close', code => {
    job.child = null;
    if (job.state !== 'running') return;
    const st = authStatus();
    if (st.loggedIn) { job.step = 'Signed in.'; jobs.finish(job); }
    else jobs.finish(job, new Error(code === 0 ? 'Sign-in did not complete. Please try again.' : `Sign-in stopped (code ${code}). Please try again.`));
  });
  return job;
}
export function sendLoginCode(job, code) {
  if (!job?.child?.stdin?.writable) return false;
  job.child.stdin.write(String(code).trim() + '\n');
  job.step = 'Checking the code…';
  return true;
}

export async function claudeState() {
  const bin = findClaude();
  if (!bin) return { installed: false, loggedIn: false };
  const [st, version] = await Promise.all([authStatusAsync(), claudeVersionAsync()]);
  const viaApiKey = /api[_ -]?key|console/i.test(st.method || '');
  return { installed: true, path: bin, version, loggedIn: !!st.loggedIn && !viaApiKey, viaApiKey, email: st.email || null, subscription: st.subscription || null };
}

// ---------- 3. Voice model download with progress ----------
export async function downloadModels(jobs, modelsDir, { fetchImpl = globalThis.fetch, files = MODEL_FILES, tar = '/usr/bin/tar' } = {}) {
  const job = jobs.create('models');
  (async () => {
    fs.mkdirSync(modelsDir, { recursive: true });
    const list = Object.values(files);
    const total = list.reduce((a, f) => a + f.size, 0);
    let doneBytes = 0;
    for (const f of list) {
      const dest = path.join(modelsDir, f.file);
      if (f.dir && (f.check ? hasAll(modelsDir, f) : ASR_FILES.every(x => fs.existsSync(path.join(modelsDir, f.dir, x))))) { doneBytes += f.size; continue; }
      if (!f.dir && fs.existsSync(dest) && fs.statSync(dest).size > 0) { doneBytes += f.size; continue; }
      job.step = `Downloading ${f.dir ? 'the speech model' : 'the voice detector'}…`;
      const r = await fetchImpl(f.url);
      if (!r.ok) throw new Error(`Download failed (${r.status}) for ${f.file}`);
      const len = +r.headers.get('content-length') || f.size;
      const tmp = dest + '.part';
      const out = fs.createWriteStream(tmp);
      let got = 0;
      for await (const chunk of r.body) {
        got += chunk.length;
        if (!out.write(chunk)) await new Promise(res => out.once('drain', res));
        job.progress = Math.min(0.97, (doneBytes + got * (f.size / len)) / total);
        job.bytes = doneBytes + got; job.total = total;
      }
      await new Promise((res, rej) => out.end(e => (e ? rej(e) : res())));
      fs.renameSync(tmp, dest);
      doneBytes += f.size;
      if (f.dir) {
        job.step = 'Unpacking the speech model…';
        await new Promise((res, rej) => {
          const c = spawn(tar, ['xjf', dest, '-C', modelsDir], { stdio: 'ignore' });
          c.on('error', rej); c.on('close', code => (code === 0 ? res() : rej(new Error('Could not unpack the speech model (tar ' + code + ')'))));
        });
        // the archive is Molly's own download (not a personal file) and is not needed once unpacked
        try { fs.unlinkSync(dest); } catch {}
      }
    }
    if (!modelsReady(modelsDir)) throw new Error('The voice files look incomplete. Please try again.');
    job.step = 'Voice ready.';
  })().then(() => jobs.finish(job), e => jobs.finish(job, e));
  return job;
}

// ---------- 4. Places: postcode → town, lat/lon, Met Office forecast URL ----------
const B32 = '0123456789bcdefghjkmnpqrstuvwxyz';
export function geohash(lat, lon, precision = 9) {
  let latR = [-90, 90], lonR = [-180, 180], hash = '', bit = 0, ch = 0, even = true;
  while (hash.length < precision) {
    const r = even ? lonR : latR, v = even ? lon : lat, mid = (r[0] + r[1]) / 2;
    if (v >= mid) { ch = (ch << 1) | 1; r[0] = mid; } else { ch <<= 1; r[1] = mid; }
    even = !even;
    if (++bit === 5) { hash += B32[ch]; bit = 0; ch = 0; }
  }
  return hash;
}
export function metOfficeUrl(lat, lon) { return `https://weather.metoffice.gov.uk/forecast/${geohash(lat, lon, 9)}`; }

export async function lookupPostcode(postcode, { fetchImpl = globalThis.fetch } = {}) {
  const pc = String(postcode || '').trim().toUpperCase().replace(/\s+/g, ' ');
  if (!pc) throw new Error('Enter a postcode');
  const full = /^[A-Z]{1,2}\d[A-Z\d]? ?\d[A-Z]{2}$/.test(pc);
  const url = full ? `https://api.postcodes.io/postcodes/${encodeURIComponent(pc)}` : `https://api.postcodes.io/outcodes/${encodeURIComponent(pc.replace(/\s/g, ''))}`;
  const r = await fetchImpl(url);
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.result) throw new Error('Postcode not found');
  const x = j.result;
  const lat = x.latitude, lon = x.longitude;
  const town = (Array.isArray(x.admin_ward) ? x.admin_ward[0] : x.admin_ward) || (Array.isArray(x.admin_district) ? x.admin_district[0] : x.admin_district) || '';
  const district = Array.isArray(x.admin_district) ? x.admin_district[0] : x.admin_district || '';
  return { postcode: full ? x.postcode : x.outcode, outcode: x.outcode || pc.split(' ')[0], lat, lon, town, district, weatherUrl: metOfficeUrl(lat, lon) };
}

// ---------- 5. OneDrive ----------
export function oneDriveInfo(root) {
  const dirs = oneDriveDirs();
  const chosen = root && fs.existsSync(root) ? root : dirs[0] || '';
  let folders = [];
  if (chosen) {
    try {
      folders = fs.readdirSync(chosen, { withFileTypes: true })
        .filter(d => d.isDirectory() && !d.name.startsWith('.') && d.name !== 'Personal Vault' && !/^\.?[0-9A-F]{8}-/.test(d.name))
        .map(d => d.name).sort((a, b) => a.localeCompare(b, 'en', { numeric: true }));
    } catch {}
  }
  return { found: dirs, root: chosen, folders };
}

// ---------- 6. Profile validation ----------
const TZ_OK = tz => { try { new Intl.DateTimeFormat('en-GB', { timeZone: tz }); return true; } catch { return false; } };
export function validateProfile(p = {}) {
  const errors = {};
  const s = v => String(v ?? '').trim();
  const out = {
    firstName: s(p.firstName).slice(0, 40), fullName: s(p.fullName).slice(0, 80), phone: s(p.phone).slice(0, 30),
    email: s(p.email).slice(0, 120), town: s(p.town).slice(0, 60), area: s(p.area).slice(0, 80), postcode: s(p.postcode).toUpperCase().slice(0, 10),
    address: s(p.address).slice(0, 160), pronouns: s(p.pronouns).slice(0, 20), household: s(p.household).slice(0, 120), about: s(p.about).slice(0, 160),
    assistantName: s(p.assistantName || 'Molly').slice(0, 24) || 'Molly', voiceName: s(p.voiceName).slice(0, 80),
    timeZone: s(p.timeZone || 'Europe/London'), weatherUrl: s(p.weatherUrl), weatherPlace: s(p.weatherPlace).slice(0, 60),
    lat: Number.isFinite(+p.lat) && p.lat !== '' && p.lat !== null ? +p.lat : null, lon: Number.isFinite(+p.lon) && p.lon !== '' && p.lon !== null ? +p.lon : null,
    oneDriveRoot: s(p.oneDriveRoot), folders: Array.isArray(p.folders) ? p.folders.map(s).filter(Boolean).slice(0, 40) : [],
    familyCalendar: s(p.familyCalendar), wakeWord: p.wakeWord !== false,
  };
  if (!out.firstName) errors.firstName = 'Please enter your first name';
  if (!out.fullName) out.fullName = out.firstName;
  if (out.phone && !/^[+()\d\s-]{6,}$/.test(out.phone)) errors.phone = 'That phone number looks wrong';
  if (out.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(out.email)) errors.email = 'That email address looks wrong';
  if (!TZ_OK(out.timeZone)) errors.timeZone = 'Unknown time zone';
  if (out.weatherUrl && !/^https:\/\/weather\.metoffice\.gov\.uk\/forecast\/[0-9a-z]+$/.test(out.weatherUrl)) errors.weatherUrl = 'Not a Met Office forecast link';
  const clocks = (Array.isArray(p.clocks) ? p.clocks : []).map(c => s(c?.tz ?? c)).filter(Boolean).slice(0, 3);
  for (const c of clocks) if (!TZ_OK(c)) errors.clocks = 'Unknown clock time zone: ' + c;
  out.clocks = (clocks.length ? clocks : ['America/New_York', 'Europe/London', 'Asia/Singapore']).map(tz => ({ tz }));
  while (out.clocks.length < 3) out.clocks.push({ tz: 'Europe/London' });
  const markets = (Array.isArray(p.markets) ? p.markets : []).map(m => ({ name: s(m?.name).slice(0, 30), sym: s(m?.sym).toUpperCase().slice(0, 16), query: s(m?.query || m?.name).slice(0, 80) })).filter(m => m.name && m.sym);
  if (markets.length > 8) errors.markets = 'Up to 8 markets';
  out.markets = markets.slice(0, 8);
  const topics = (Array.isArray(p.newsTopics) ? p.newsTopics : String(p.newsTopics || '').split(/[,\n]/)).map(s).filter(Boolean);
  if (topics.length > 8) errors.newsTopics = 'Up to 8 topics';
  out.newsTopics = [...new Set(topics)].slice(0, 8);
  return { ok: !Object.keys(errors).length, errors, profile: out };
}

export const MARKET_PRESETS = [
  { name: 'S&P 500', sym: 'SPX', query: 'S&P 500 index' },
  { name: 'FTSE 100', sym: 'UKX', query: 'FTSE 100 index' },
  { name: 'Nasdaq 100', sym: 'NDX', query: 'Nasdaq 100 index' },
  { name: 'GBP–EUR', sym: 'GBPEUR', query: 'GBP to EUR' },
  { name: 'GBP–USD', sym: 'GBPUSD', query: 'GBP to USD' },
  { name: 'Gold', sym: 'XAUUSD', query: 'Gold price USD' },
  { name: 'Bitcoin', sym: 'BTCUSD', query: 'Bitcoin price USD' },
  { name: 'Brent crude', sym: 'BRENT', query: 'Brent crude oil price' },
];

export const CLOCK_PRESETS = [
  ['Europe/London', 'London'], ['America/New_York', 'New York'], ['America/Chicago', 'Chicago'], ['America/Los_Angeles', 'Los Angeles'],
  ['America/Toronto', 'Toronto'], ['America/Sao_Paulo', 'São Paulo'], ['Europe/Paris', 'Paris'], ['Europe/Madrid', 'Madrid'], ['Europe/Lisbon', 'Lisbon'],
  ['Europe/Berlin', 'Berlin'], ['Europe/Athens', 'Athens'], ['Asia/Dubai', 'Dubai'], ['Asia/Kolkata', 'India'], ['Asia/Singapore', 'Singapore'],
  ['Asia/Hong_Kong', 'Hong Kong'], ['Asia/Tokyo', 'Tokyo'], ['Australia/Sydney', 'Sydney'], ['Pacific/Auckland', 'Auckland'], ['Africa/Johannesburg', 'Johannesburg'],
];

// Stage 1 (the earlier test version) ran as a LaunchAgent; switch it off so it doesn't run twice.
// The plist is renamed (kept), never deleted.
export function retireStage1({ home = os.homedir(), run = (cmd, args) => spawn(cmd, args, { stdio: 'ignore' }) } = {}) {
  const plist = path.join(home, 'Library', 'LaunchAgents', 'com.molly.assistant.plist');
  if (!fs.existsSync(plist)) return false;
  try { run('/bin/launchctl', ['bootout', `gui/${process.getuid?.() ?? 501}/com.molly.assistant`]); } catch {}
  try { fs.renameSync(plist, plist + '.disabled-by-Molly-app'); } catch { return false; }
  return true;
}

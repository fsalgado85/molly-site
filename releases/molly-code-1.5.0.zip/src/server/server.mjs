// Molly's local server (127.0.0.1 only). Serves the Molly page with the window.claude shim and
// backs it: database (+ live updates), Gmail/Calendar, "ask Claude", assets, downloads, background
// tasks, Google sign-in and the setup wizard. Electron-only actions come in as hooks.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Db, DbError } from './db.mjs';
import { createGoogle, McpError } from './google.mjs';
import { createTools, serverKey, WRITE_TOOLS } from './gtools.mjs';
import { SampleHub } from './sample.mjs';
import { TaskRunner } from './tasks.mjs';
import { createSettings, applyProfileToDb } from './settings.mjs';
import { personaliseArtifact, injectShim, loadArtifact, completeProfile } from './personalise.mjs';
import * as setup from './setup.mjs';
import { createTts } from './tts.mjs';

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.json': 'application/json', '.wav': 'audio/wav', '.mp3': 'audio/mpeg' };

export async function createMollyServer({ paths, port = 0, hooks = {}, nodeBin = process.execPath, nodeEnv = {}, claudePath, log = () => {}, version = '1.0.0' } = {}) {
  const pageToken = crypto.randomBytes(24).toString('hex');
  const mcpToken = crypto.randomBytes(24).toString('hex');
  const roles = new Map([[pageToken, 'page'], [mcpToken, 'mcp']]);
  const settings = createSettings(paths);
  const db = new Db(paths.db);
  db.watch();
  const google = createGoogle(paths, { fetchImpl: hooks.fetch });
  const tools = createTools(google, { allowedSaveRoots: () => [settings.profile().oneDriveRoot].filter(Boolean) });
  const jobs = new setup.Jobs();
  const tts = createTts({ dataDir: paths.dataDir, fetchImpl: hooks.fetch || globalThis.fetch, log });
  const H = {
    notify: () => {}, openExternal: () => {}, openPath: async () => '', saveFile: async () => { const e = new Error('Saving is not available'); e.code = 'unavailable'; throw e; },
    askMic: async () => true, micStatus: () => 'unknown', setupDone: () => {}, voiceStatus: () => ({}),
    updateStatus: () => ({ state: 'idle' }), checkUpdates: async () => ({ state: 'idle' }), requestRestart: async () => ({ ok: false, message: 'Not available' }),
    ...hooks,
  };

  // ---- import a database export dropped into <data>/import (PLAN.md §6) ----
  try {
    if (fs.existsSync(paths.importDir) && fs.readdirSync(paths.importDir).length) {
      const n = db.importExport(paths.importDir);
      const done = paths.importDir + '-done-' + new Date().toISOString().slice(0, 10);
      fs.renameSync(paths.importDir, fs.existsSync(done) ? done + '-' + Date.now() : done);
      log(`imported ${n} documents from the import folder`);
    }
  } catch (e) { log('import failed: ' + e.message); }

  let pageBusyAt = 0; // the page reports when Molly is speaking

  // Is Molly in the middle of something? (Never restart for an update while she is.)
  function busy() {
    if (Date.now() - pageBusyAt < 15000) return 'speaking';
    if (hub.active.size) return 'answering';
    if (tasks.running.size) return 'a background task';
    return null;
  }

  const server = http.createServer();
  await new Promise((res, rej) => { server.once('error', rej); server.listen(port, '127.0.0.1', res); });
  const realPort = server.address().port;
  const base = `http://127.0.0.1:${realPort}`;
  const hostOk = h => h === `127.0.0.1:${realPort}` || h === `localhost:${realPort}`;

  const hub = new SampleHub({ paths, db, serverUrl: base, token: mcpToken, nodeBin, nodeEnv, profile: () => settings.profile(), claudePath, log });
  const tasks = new TaskRunner({
    paths, db, profile: () => settings.profile(), settings: () => settings.get(), serverUrl: base, mcpToken, nodeBin, nodeEnv, claudePath, log,
    notify: n => notify(n), openPath: p => H.openPath(p), showInFolder: p => H.showInFolder && H.showInFolder(p),
  });

  function notify({ title, text, task }) {
    const t = String(text || '').slice(0, 1000); if (!t) return;
    try {
      const cur = db.get('meta/notices').data || {};
      const list = [{ at: new Date().toISOString(), text: t, title: title || '', task: task || '' }, ...(cur.list || [])].slice(0, 50);
      db.set('meta/notices', { at: list[0].at, list });
    } catch {}
    try { H.notify({ title: title || settings.profile().assistantName || 'Molly', text: t }); } catch {}
  }

  // ---- page HTML (personalised, with the shim) ----
  let pageCache = null;
  function pageHtml() {
    const profile = settings.profile();
    const key = JSON.stringify(profile);
    if (pageCache?.key === key) return pageCache.html;
    const raw = loadArtifact(paths);
    const { html } = personaliseArtifact(raw, profile);
    const out = '<!doctype html>\n' + injectShim(html, { token: pageToken, profile, port: realPort, version });
    pageCache = { key, html: out };
    return out;
  }

  // ---- SSE clients (database changes) ----
  const sse = new Set();
  db.on('change', ev => { const msg = `data: ${JSON.stringify(ev)}\n\n`; for (const res of sse) { try { res.write(msg); } catch {} } });
  const ping = setInterval(() => { for (const res of sse) { try { res.write(': ping\n\n'); } catch {} } }, 25000);
  ping.unref?.();

  const json = (res, code, obj) => { res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(obj)); };
  const readBody = (req, limit = 30e6) => new Promise((ok, bad) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limit) { bad(Object.assign(new Error('Too large'), { code: 'too_large' })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks))); req.on('error', bad);
  });
  const readJson = async req => { const b = await readBody(req); return b.length ? JSON.parse(b.toString('utf8')) : {}; };
  const errOut = (res, e, status = 400) => json(res, e.status || status, { error: e.code || 'error', code: e.code || 'error', message: e.message || String(e), server: !!e.server });

  function serveFile(res, file, root) {
    const f = path.resolve(file);
    if (!f.startsWith(path.resolve(root) + path.sep) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'content-type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache' });
    fs.createReadStream(f).pipe(res);
  }

  // ---- mcp.callTool ----
  async function callTool({ server: srv, tool, args = {} }, role, caller) {
    const key = serverKey(srv);
    if (key === 'Claude Code Remote') {
      if (tool !== 'fire_trigger') throw new McpError('tool_not_found', 'Unknown tool ' + tool);
      if (role !== 'page') throw new McpError('not_allowed', 'Only the page can start tasks');
      const r = tasks.fire(args.trigger_id, args.text || '');
      if (!r.ok) throw new McpError('trigger_not_found', 'Unknown task ' + args.trigger_id);
      return { ok: true, task: r.task, queued: !!r.queued, message: 'Started on this Mac.' };
    }
    const impl = tools[key];
    if (!impl) throw new McpError('server_not_found', `${srv} isn't available in Molly.`);
    const fn = impl[tool];
    if (!fn) throw new McpError('tool_not_found', `Unknown ${key} tool: ${tool}`);
    // Background tasks only read (and may save an attachment into OneDrive). The page shows its own confirmations.
    if (role === 'mcp') {
      const mode = caller === 'agent' ? 'agent' : caller === 'chat' ? 'chat' : 'task';
      if (mode === 'task' && WRITE_TOOLS.has(tool)) throw new McpError('not_allowed', `${tool} is not allowed in background tasks (read-only).`);
      // Chat reads directly; every change goes through the page's tools, which show a Confirm card.
      if (mode === 'chat' && (WRITE_TOOLS.has(tool) || tool === 'save_attachment')) throw new McpError('not_allowed', `${tool} goes through Molly's page (with a Confirm card), not directly.`);
      if (mode === 'agent' && (tool === 'send_message' || tool === 'reply' || tool === 'trash_thread')) throw new McpError('not_allowed', 'Sending or deleting email is only done from Molly\'s page after you say "send".');
    } else if (tool === 'save_attachment') throw new McpError('not_allowed', 'save_attachment is for background tasks');
    return fn(args);
  }

  // ---- routes ----
  server.on('request', async (req, res) => {
    const url = new URL(req.url, base);
    const p = url.pathname;
    try {
      if (!hostOk(req.headers.host)) { res.writeHead(421); return res.end('Wrong host'); }
      const token = req.headers['x-molly-token'] || url.searchParams.get('t');
      const role = roles.get(token) || null;
      const needRole = r => { if (!role || (r && role !== r)) { const e = new Error('forbidden'); e.code = 'forbidden'; e.status = 403; throw e; } };

      // --- static ---
      if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
        return res.end(pageHtml());
      }
      if (req.method === 'GET' && p.startsWith('/molly/')) return serveFile(res, path.join(paths.appDir, 'src', 'renderer', p.slice(7)), path.join(paths.appDir, 'src', 'renderer'));
      if (req.method === 'GET' && p.startsWith('/setup/')) return serveFile(res, path.join(paths.appDir, 'src', 'wizard', p.slice(7) || 'index.html'), path.join(paths.appDir, 'src', 'wizard'));
      if (req.method === 'GET' && p === '/setup') { res.writeHead(302, { location: '/setup/index.html?t=' + pageToken }); return res.end(); }
      if (req.method === 'GET' && (p.startsWith('/assets/') || p.startsWith('/_blob/'))) {
        const id = p.split('/')[2] || '';
        if (!/^[a-zA-Z0-9_-]{6,64}(\.[a-z0-9]{2,5})?$/.test(id)) { res.writeHead(404); return res.end(); }
        const file = fs.readdirSync(paths.assets).find(n => n === id || n.startsWith(id + '.'));
        if (!file) { res.writeHead(404); return res.end(); }
        return serveFile(res, path.join(paths.assets, file), paths.assets);
      }
      if (req.method === 'GET' && (p === '/three.min.js' || p === '/room.js')) {
        const dirs = [path.dirname(paths.artifact), path.join(paths.appDir, '..', 'reference', 'artifact')];
        const d = dirs.find(x => fs.existsSync(path.join(x, p.slice(1))));
        if (d) { res.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8', 'cache-control': 'max-age=86400' }); return fs.createReadStream(path.join(d, p.slice(1))).pipe(res); }
        res.writeHead(404); return res.end();
      }
      if (req.method === 'GET' && p === '/molly-icon.png') return serveFile(res, path.join(paths.appDir, 'build', 'icon.png'), path.join(paths.appDir, 'build'));

      // --- Google sign-in (browser redirects, no token) ---
      const redirect = `${base}/google/callback`;
      if (p === '/google/connect') { res.writeHead(302, { location: google.authUrl(redirect, { loginHint: settings.profile().email || undefined }) }); return res.end(); }
      if (p === '/google/callback') {
        let html;
        try {
          const email = await google.handleCallback(url.searchParams);
          if (email && !settings.profile().email) settings.set({ profile: { email } });
          pageCache = null;
          H.onGoogleConnected?.(email);
          html = `<h2>Google is connected${email ? ' (' + email.replace(/[<>&]/g, '') + ')' : ''}.</h2><p>You can close this tab and go back to Molly.</p>`;
        } catch (e) { html = `<h2>Google sign-in didn't work</h2><p>${String(e.message).replace(/[<>&]/g, '')}</p><p>Go back to Molly and try again.</p>`; }
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
        return res.end(`<!doctype html><meta charset="utf-8"><title>Molly</title><body style="font:16px -apple-system,system-ui;padding:40px;color:#0D2C53">${html}</body>`);
      }

      if (!p.startsWith('/api/')) { res.writeHead(404); return res.end('Not found'); }
      needRole();

      // --- database ---
      if (p === '/api/db/events' && req.method === 'GET') {
        res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' });
        res.write(': hello\n\n');
        sse.add(res); req.on('close', () => sse.delete(res));
        return;
      }
      if (p === '/api/db' && req.method === 'POST') {
        const b = await readJson(req);
        try {
          switch (b.op) {
            case 'get': return json(res, 200, db.get(b.path));
            case 'set': db.set(b.path, b.data, b.opts || {}); return json(res, 200, { ok: true });
            case 'update': db.update(b.path, b.data); return json(res, 200, { ok: true });
            case 'delete': db.delete(b.path); return json(res, 200, { ok: true });
            case 'add': return json(res, 200, { id: db.add(b.path, b.data) });
            case 'list': return json(res, 200, { docs: db.list(b.path, b.opts || {}) });
            default: return json(res, 400, { error: 'bad_op', message: 'Unknown op' });
          }
        } catch (e) { return errOut(res, e instanceof DbError ? e : Object.assign(e, { code: e.code || 'db_error' })); }
      }

      // --- Gmail / Calendar / tasks ---
      if (p === '/api/mcp/call' && req.method === 'POST') {
        const b = await readJson(req);
        try { const out = await callTool(b, role, b.caller); return json(res, 200, { structuredContent: out ?? {} }); }
        catch (e) { log(`mcp ${b.server}/${b.tool} failed: ${e.message}`); return errOut(res, e.server ? e : Object.assign(e, { code: e.code || 'tool_error', server: true }), 200); }
      }

      // --- ask Claude (streamed as NDJSON) ---
      if (p === '/api/sample' && req.method === 'POST') {
        needRole('page');
        const b = await readJson(req);
        const ctrl = new AbortController();
        res.on('close', () => { if (!res.writableFinished) ctrl.abort(); });
        res.writeHead(200, { 'content-type': 'application/x-ndjson', 'cache-control': 'no-store' });
        const emit = ev => { try { res.write(JSON.stringify({ ...ev, sampleId: undefined }) + '\n'); } catch {} };
        try {
          const out = await hub.run(b, ev => emit(ev), ctrl.signal);
          emit({ type: 'done', text: out.text });
        } catch (e) { emit({ type: 'error', code: e.code || 'claude_error', message: e.message }); }
        return res.end();
      }
      if (p === '/api/bridge/call' && req.method === 'POST') {
        needRole('mcp');
        const b = await readJson(req);
        return json(res, 200, await hub.bridgeCall(b));
      }
      if (p === '/api/bridge/result' && req.method === 'POST') {
        needRole('page');
        const b = await readJson(req);
        return json(res, 200, { ok: hub.bridgeResult(b) });
      }

      // --- assets & downloads ---
      if (p === '/api/assets' && req.method === 'POST') {
        needRole('page');
        const buf = await readBody(req, 15e6);
        const type = String(req.headers['content-type'] || 'application/octet-stream');
        const ext = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif', 'application/pdf': '.pdf' }[type.split(';')[0]] || '.bin';
        const id = crypto.randomBytes(12).toString('base64url');
        fs.writeFileSync(path.join(paths.assets, id + ext), buf);
        return json(res, 200, { id, url: `/assets/${id}` });
      }
      if (p === '/api/downloads' && req.method === 'POST') {
        needRole('page');
        const b = await readJson(req);
        const data = b.b64 != null ? Buffer.from(b.b64, 'base64') : Buffer.from(String(b.data ?? ''), 'utf8');
        try { const saved = await H.saveFile({ filename: String(b.filename || 'download').replace(/[/\\:]/g, '-'), data }); return json(res, 200, { ok: true, path: saved }); }
        catch (e) { return json(res, 200, { error: e.code || 'error', code: e.code || 'error', message: e.message }); }
      }

      // --- updates (banner in the page; see src/update/updater.mjs) ---
      if (p === '/api/update' && req.method === 'POST') {
        needRole('page'); const b = await readJson(req);
        pageBusyAt = b.busy ? Date.now() : 0;
        return json(res, 200, { ...H.updateStatus(), codeVersion: version });
      }
      if (p === '/api/update/check' && req.method === 'POST') { needRole('page'); return json(res, 200, await H.checkUpdates({ manual: true })); }
      if (p === '/api/update/restart' && req.method === 'POST') {
        needRole('page'); const b = await readJson(req);
        pageBusyAt = b.busy ? Date.now() : 0;
        return json(res, 200, await H.requestRestart());
      }

      // --- ElevenLabs voice (optional; see src/server/tts.mjs) ---
      if (p.startsWith('/api/tts')) {
        needRole('page');
        const sub = p.slice('/api/tts'.length);
        try {
          if (sub === '' && req.method === 'POST') {
            const b = await readJson(req);
            const audio = await tts.speak(b.text, { rate: b.rate, voiceId: b.voiceId });
            res.writeHead(200, { 'content-type': 'audio/mpeg', 'cache-control': 'no-store', 'content-length': audio.length });
            return res.end(audio);
          }
          if (sub === '/status' && req.method === 'GET') return json(res, 200, await tts.status({ refresh: url.searchParams.get('refresh') === '1' }));
          if (sub === '/voices' && req.method === 'GET') return json(res, 200, { voices: await tts.voices() });
          if (sub === '/config' && req.method === 'POST') return json(res, 200, await tts.configure(await readJson(req)));
        } catch (e) { return json(res, 200, { error: e.code || 'failed', code: e.code || 'failed', message: e.message }); }
        return json(res, 404, { error: 'not_found' });
      }

      // --- notifications from background tasks ---
      if (p === '/api/notify' && req.method === 'POST') { const b = await readJson(req); notify(b); return json(res, 200, { ok: true }); }

      // --- tasks ---
      if (p === '/api/tasks' && req.method === 'GET') return json(res, 200, { tasks: tasks.summary() });
      if (p === '/api/tasks/run' && req.method === 'POST') { needRole('page'); const b = await readJson(req); return json(res, 200, tasks.fire(b.id, b.text || '', { source: 'menu' })); }

      // --- status for the app / wizard ---
      if (p === '/api/status' && req.method === 'GET') {
        return json(res, 200, { profile: settings.profile(), setupDone: !!settings.get().setupDone, google: google.status(), models: setup.modelsReady(paths.models), mic: H.micStatus(), voice: H.voiceStatus(), version });
      }

      // --- setup wizard ---
      if (p.startsWith('/api/setup/')) {
        needRole('page');
        const action = p.slice('/api/setup/'.length);
        if (action === 'state' && req.method === 'GET') {
          return json(res, 200, {
            claude: await setup.claudeState(), google: google.status(), models: setup.modelsReady(paths.models), mic: H.micStatus(),
            profile: settings.get().profile || {}, onedrive: setup.oneDriveInfo(settings.get().profile?.oneDriveRoot),
            presets: { markets: setup.MARKET_PRESETS, clocks: setup.CLOCK_PRESETS }, setupDone: !!settings.get().setupDone,
            systemTimeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          });
        }
        if (action.startsWith('job/') && req.method === 'GET') {
          const j = jobs.get(action.slice(4)); if (!j) return json(res, 404, { error: 'not_found' });
          const { child, ...pub } = j; return json(res, 200, pub);
        }
        const b = req.method === 'POST' ? await readJson(req) : {};
        switch (action) {
          case 'install-claude': return json(res, 200, (await setup.claudeState()).installed ? { already: true } : { job: setup.installClaude(jobs).id });
          case 'login': { const j = setup.startLogin(jobs, { openExternal: u => H.openExternal(u), claudePath }); return json(res, 200, { job: j.id }); }
          case 'login-code': return json(res, 200, { ok: setup.sendLoginCode(jobs.get(b.job), b.code) });
          case 'open-url': { const u = String(b.url || ''); if (/^https:\/\//.test(u)) H.openExternal(u); return json(res, 200, { ok: true }); }
          case 'google-client': try { google.saveClient(b.json ?? b); return json(res, 200, google.status()); } catch (e) { return errOut(res, e); }
          case 'google-connect': { if (!google.status().clientConfigured) return json(res, 400, { error: 'no_client', message: 'Add the Google client file first.' }); H.openExternal(`${base}/google/connect`); return json(res, 200, { ok: true }); }
          case 'google-disconnect': google.disconnect(); return json(res, 200, google.status());
          case 'postcode': try { return json(res, 200, await setup.lookupPostcode(b.postcode, { fetchImpl: hooks.fetch })); } catch (e) { return errOut(res, e); }
          case 'onedrive': return json(res, 200, setup.oneDriveInfo(b.root));
          case 'choose-folder': { const r = await H.chooseFolder?.(b.defaultPath); return json(res, 200, r ? setup.oneDriveInfo(r) : { cancelled: true }); }
          case 'profile': {
            const v = setup.validateProfile(b);
            if (!v.ok) return json(res, 400, { error: 'invalid', errors: v.errors });
            settings.set({ profile: v.profile });
            applyProfileToDb(db, v.profile);
            pageCache = null;
            return json(res, 200, { ok: true, profile: completeProfile(v.profile) });
          }
          case 'mic': return json(res, 200, { granted: await H.askMic() });
          case 'models': return json(res, 200, setup.modelsReady(paths.models) ? { already: true } : { job: (await setup.downloadModels(jobs, paths.models, { fetchImpl: hooks.fetch })).id });
          case 'finish': settings.set({ setupDone: true, setupAt: new Date().toISOString() }); setup.retireStage1(); H.setupDone(); return json(res, 200, { ok: true });
        }
        return json(res, 404, { error: 'not_found' });
      }

      return json(res, 404, { error: 'not_found' });
    } catch (e) {
      log('error ' + p + ' ' + (e.stack || e));
      if (!res.headersSent) errOut(res, e, e.status || 500); else try { res.end(); } catch {}
    }
  });

  return {
    url: base, port: realPort, pageToken, mcpToken, db, google, tasks, hub, settings, jobs, notify, busy, tts,
    setPageBusy(on) { pageBusyAt = on ? Date.now() : 0; },
    reloadPage() { pageCache = null; },
    close() { clearInterval(ping); tasks.stopCron(); db.close(); for (const r of sse) { try { r.end(); } catch {} } const done = new Promise(r => server.close(() => r())); server.closeAllConnections?.(); return done; },
  };
}

// Molly.app main process: windows, menu-bar icon, open at login, single instance, hide on close,
// the local server, background tasks and on-device voice.
import { app, BrowserWindow, Tray, Menu, nativeImage, shell, dialog, Notification, session, systemPreferences, ipcMain, powerMonitor, utilityProcess } from 'electron';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fork } from 'node:child_process';
import { makePaths, appDir } from '../server/paths.mjs';
import { createMollyServer } from '../server/server.mjs';
import { modelsReady } from '../server/setup.mjs';
import { TASKS } from '../server/tasks.mjs';
import { SpeechService } from '../voice/stt.mjs';
import { Updater, FEED_URL } from '../update/updater.mjs';

// Set by the shell's bootstrap (src/shell/bootstrap.mjs); absent when this file is started directly.
const BOOT = globalThis.__mollyBoot || {};
const CODE_VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(appDir, 'package.json'), 'utf8')).version; } catch { return app.getVersion(); } })();
const SHELL_VERSION = BOOT.shellVersion || process.env.MOLLY_SHELL_VERSION || CODE_VERSION;

const SELFTEST = process.argv.includes('--molly-selftest');
const PORT = Number(process.env.MOLLY_PORT || 4787); // fixed, so the page's own saved settings (localStorage) persist
if (SELFTEST) { process.env.MOLLY_DATA = process.env.MOLLY_DATA || fs.mkdtempSync(path.join(os.tmpdir(), 'molly-selftest-')); }
if (process.platform === 'linux') app.commandLine.appendSwitch('no-sandbox');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

if (!SELFTEST && !app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }

const paths = makePaths();
const logFile = path.join(paths.logs, 'molly.log');
const log = (...a) => { const l = `[${new Date().toISOString()}] ${a.join(' ')}\n`; try { fs.appendFileSync(logFile, l); } catch {} if (!app.isPackaged || SELFTEST) process.stdout.write(l); };
process.on('uncaughtException', e => log('uncaught', e.stack || e));
process.on('unhandledRejection', e => log('unhandled', e?.stack || e));

let mainWin = null, setupWin = null, voiceWin = null, tray = null, srv = null, speech = null, quitting = false, updater = null, restartWanted = false;
const iconPath = path.join(appDir, 'build', 'icon.png');

function profile() { return srv?.settings.profile() || {}; }
function micGranted() { return process.platform !== 'darwin' || systemPreferences.getMediaAccessStatus('microphone') === 'granted'; }

// ---------------- windows ----------------
const webPrefs = { preload: path.join(appDir, 'src', 'main', 'preload.cjs'), contextIsolation: true, sandbox: true, backgroundThrottling: false, spellcheck: true };

function guardNavigation(win) {
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url) && !url.startsWith(srv.url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(srv.url)) { e.preventDefault(); if (/^https?:|^mailto:/.test(url)) shell.openExternal(url); } });
}

function createMain() {
  if (mainWin) return mainWin;
  const b = srv.settings.get().windowBounds || {};
  mainWin = new BrowserWindow({
    width: b.width || 1440, height: b.height || 900, x: b.x, y: b.y, minWidth: 960, minHeight: 600,
    title: profile().assistantName || 'Molly', backgroundColor: '#0f1720', show: false, icon: iconPath,
    webPreferences: webPrefs,
  });
  guardNavigation(mainWin);
  mainWin.once('ready-to-show', () => { if (!SELFTEST && !process.argv.includes('--hidden') && !app.getLoginItemSettings().wasOpenedAsHidden) mainWin.show(); });
  mainWin.on('close', e => {
    try { srv.settings.set({ windowBounds: mainWin.getBounds() }); } catch {}
    if (!quitting && !SELFTEST) { e.preventDefault(); mainWin.hide(); }
  });
  mainWin.on('closed', () => { mainWin = null; });
  mainWin.webContents.on('did-finish-load', () => sendWakeMode().catch(e => log('wake', e.message)));
  mainWin.webContents.on('render-process-gone', (_e, d) => { log('renderer gone', d.reason); setTimeout(() => mainWin?.reload(), 1500); });
  mainWin.loadURL(srv.url + '/');
  return mainWin;
}

function showMain() {
  if (!srv.settings.get().setupDone && !SELFTEST) return showSetup();
  const w = createMain();
  if (w.isMinimized()) w.restore();
  w.show(); w.focus();
  if (process.platform === 'darwin') app.dock?.show();
}

function showSetup() {
  if (setupWin) { setupWin.show(); setupWin.focus(); return; }
  setupWin = new BrowserWindow({ width: 980, height: 720, minWidth: 820, minHeight: 640, title: 'Set up Molly', backgroundColor: '#0D2C53', icon: iconPath, titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default', webPreferences: webPrefs, show: false });
  guardNavigation(setupWin);
  setupWin.once('ready-to-show', () => setupWin.show());
  setupWin.on('closed', () => { setupWin = null; if (!srv.settings.get().setupDone && !quitting && !mainWin) app.quit(); });
  setupWin.loadURL(`${srv.url}/setup/index.html?t=${srv.pageToken}`);
}

// Molly's voice (ElevenLabs key and voice choice); see src/server/tts.mjs and src/renderer/voice.html
function showVoice() {
  if (voiceWin) { voiceWin.show(); voiceWin.focus(); return; }
  voiceWin = new BrowserWindow({ width: 640, height: 640, minWidth: 520, minHeight: 560, title: `${profile().assistantName || 'Molly'}'s Voice`, backgroundColor: '#0D2C53', icon: iconPath, titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default', webPreferences: webPrefs, show: false });
  guardNavigation(voiceWin);
  voiceWin.once('ready-to-show', () => voiceWin.show());
  voiceWin.on('closed', () => { voiceWin = null; try { mainWin?.webContents.executeJavaScript('window.speechSynthesis.mollyRefresh && window.speechSynthesis.mollyRefresh()'); } catch {} });
  voiceWin.loadURL(`${srv.url}/molly/voice.html?t=${srv.pageToken}`);
}

// ---------------- voice ----------------
function spawnWorker() {
  const script = path.join(appDir, 'src', 'voice', 'stt-worker.mjs');
  try {
    const child = utilityProcess.fork(script, [], { serviceName: 'Molly voice', stdio: 'inherit' });
    return { postMessage: m => child.postMessage(m), on: (ev, fn) => child.on(ev, fn), kill: () => child.kill() };
  } catch (e) {
    log('utilityProcess failed, using a node child', e.message);
    const child = fork(script, [], { env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, execPath: process.execPath });
    return { postMessage: m => child.send(m), on: (ev, fn) => child.on(ev, fn), kill: () => child.kill() };
  }
}
function sendSTT(ev) { mainWin?.webContents.send('stt:event', ev); }
function wakeReason() {
  const s = srv.settings.get();
  if (profile().wakeWord === false) return 'turned off in setup';
  if (s.wakeListening === false) return 'switched off';
  if (!s.setupDone) return 'setup not finished';
  if (!modelsReady(paths.models)) return 'voice files missing – use Set up again…';
  if (!micGranted()) return process.platform === 'darwin' && systemPreferences.getMediaAccessStatus('microphone') === 'not-determined' ? 'waiting for microphone permission' : 'microphone not allowed – System Settings → Privacy & Security → Microphone';
  return '';
}
let wakeAsked = false;
async function sendWakeMode() {
  if (process.platform === 'darwin' && !wakeAsked && srv.settings.get().setupDone && modelsReady(paths.models) && systemPreferences.getMediaAccessStatus('microphone') === 'not-determined') {
    wakeAsked = true;
    try { await systemPreferences.askForMediaAccess('microphone'); } catch (e) { log('mic request failed', e.message); }
  }
  const why = wakeReason(), on = !why;
  log('wake word', on ? 'on' : 'off: ' + why);
  sendSTT({ type: 'wake-mode', on, why });
  if (on) speech.start();
  if (tray) buildTray();
}

// ---------------- menu bar ----------------
function buildTray() {
  const img = nativeImage.createFromPath(path.join(appDir, 'build', process.platform === 'darwin' ? 'trayTemplate.png' : 'icon.png'));
  if (process.platform === 'darwin') img.setTemplateImage(true);
  tray = tray || new Tray(process.platform === 'darwin' ? img : img.resize({ width: 18, height: 18 }));
  tray.setToolTip(profile().assistantName || 'Molly');
  const s = srv.settings.get();
  const name = profile().assistantName || 'Molly';
  const menu = Menu.buildFromTemplate([
    { label: `Open ${name}`, click: showMain },
    { label: `Talk to ${name}`, click: () => { showMain(); sendSTT({ type: 'wake', rest: '' }); } },
    { type: 'separator' },
    { label: `Listen for “Hey ${name}”`, type: 'checkbox', checked: s.wakeListening !== false, click: i => { srv.settings.set({ wakeListening: i.checked }); sendWakeMode().catch(e => log('wake', e.message)); } },
    ...(wakeReason() && s.wakeListening !== false ? [{ label: `“Hey ${name}” is off: ${wakeReason()}`, enabled: false }] : []),
    { label: 'Open at login', type: 'checkbox', checked: app.getLoginItemSettings().openAtLogin, click: i => setLogin(i.checked) },
    { type: 'separator' },
    { label: 'Run a background task now', submenu: TASKS.filter(t => !t.native && t.id !== 'research' && t.id !== 'filing').map(t => ({ label: t.name, click: () => { srv.tasks.fire(t.id, '', { source: 'menu' }); notify({ text: `${t.name}: started.` }); } })) },
    { label: 'Check for Updates…', click: () => checkForUpdates(true) },
    { label: `${name}’s Voice…`, click: showVoice },
    { label: 'Connect Google…', click: () => shell.openExternal(srv.url + '/google/connect') },
    { label: 'Set up again…', click: showSetup },
    { label: 'Show Molly’s files', click: () => shell.openPath(paths.dataDir) },
    { label: 'Show the task log', click: () => shell.openPath(path.join(paths.logs, 'tasks.log')) },
    { type: 'separator' },
    { label: `Quit ${name}`, click: () => { quitting = true; app.quit(); } },
  ]);
  tray.setContextMenu(menu);
}

function appMenu() {
  const name = profile().assistantName || 'Molly';
  const t = [
    ...(process.platform === 'darwin' ? [{ label: name, submenu: [{ role: 'about' }, { label: 'Check for Updates…', click: () => checkForUpdates(true) }, { type: 'separator' }, { label: `${name}’s Voice…`, click: showVoice }, { label: 'Set up again…', click: showSetup }, { type: 'separator' }, { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' }, { type: 'separator' }, { label: `Quit ${name}`, accelerator: 'Cmd+Q', click: () => { quitting = true; app.quit(); } }] }] : []),
    { role: 'editMenu' },
    { label: 'View', submenu: [{ role: 'reload' }, { role: 'togglefullscreen' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'toggleDevTools' }] },
    { role: 'windowMenu' },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(t));
}

function setLogin(on) {
  try { app.setLoginItemSettings({ openAtLogin: !!on, openAsHidden: true, args: ['--hidden'] }); } catch (e) { log('login item', e.message); }
  srv.settings.set({ openAtLogin: !!on });
}

function notify({ title, text }) {
  if (SELFTEST) return log('notify', text);
  try {
    if (!Notification.isSupported()) return;
    const n = new Notification({ title: title || profile().assistantName || 'Molly', body: text, icon: iconPath, silent: false });
    n.on('click', showMain); n.show();
  } catch (e) { log('notify failed', e.message); }
}


// ---------------- updates (see src/update/updater.mjs and src/shell/bootstrap.mjs) ----------------
function startUpdater() {
  const feedUrl = process.env.MOLLY_UPDATE_FEED || FEED_URL;
  updater = new Updater({
    currentVersion: CODE_VERSION, shellVersion: SHELL_VERSION, codeRoot: paths.code, feedUrl,
    badVersions: () => (BOOT.badVersions ? BOOT.badVersions() : []), log, stateFile: path.join(paths.run, 'update.json'),
  });
  let told = null;
  updater.on('status', st => {
    const key = st.state + ':' + st.version;
    if ((st.state === 'ready' || st.state === 'reinstall-needed') && told !== key && !st.manual) {
      told = key;
      notify({ text: st.state === 'ready' ? `Molly ${st.version} is ready. Restart Molly when it suits you (banner in Molly's window).` : `Molly ${st.version} needs a one-time reinstall. Details in Molly's window.` });
    }
  });
  const auto = process.env.MOLLY_NO_UPDATES !== '1' && (process.env.MOLLY_UPDATE_FEED ? true : app.isPackaged && !SELFTEST);
  if (auto) updater.start({ firstDelayMs: Number(process.env.MOLLY_UPDATE_FIRST_DELAY || 20000) });
  powerMonitor.on('resume', () => { if (auto && Date.now() - updater.lastCheck() > 23 * 3600e3) updater.check(); });
}

function updateStatus() {
  return { ...(updater?.status || { state: 'idle' }), codeVersion: CODE_VERSION, shellVersion: SHELL_VERSION, restartWanted, waiting: restartWanted ? srv?.busy() : null };
}

async function checkForUpdates(manual) {
  const st = await updater.check({ manual });
  if (!manual) return st;
  const name = profile().assistantName || 'Molly';
  const opts = { type: 'info', title: 'Molly updates', buttons: ['OK'] };
  if (st.state === 'ready') {
    const r = await dialog.showMessageBox(mainWin || undefined, { ...opts, message: `${name} ${st.version} is ready.`, detail: (st.notes ? st.notes + '\n\n' : '') + 'Restart now to use it? (If Molly is busy, she restarts as soon as she has finished.)', buttons: ['Restart now', 'Later'], defaultId: 0, cancelId: 1 });
    if (r.response === 0) requestRestart();
  } else if (st.state === 'up-to-date') await dialog.showMessageBox(mainWin || undefined, { ...opts, message: `You have the latest ${name} (${CODE_VERSION}).`, detail: st.note || '' });
  else if (st.state === 'reinstall-needed') {
    const r = await dialog.showMessageBox(mainWin || undefined, { ...opts, message: `A one-time reinstall is needed for ${name} ${st.version}.`, detail: 'This version needs a newer app than the one on this Mac, so it cannot update by itself.', buttons: ['How to reinstall', 'Later'], defaultId: 0, cancelId: 1 });
    if (r.response === 0) shell.openExternal(st.reinstallUrl);
  } else await dialog.showMessageBox(mainWin || undefined, { ...opts, type: 'warning', message: 'Molly could not check for updates just now.', detail: st.message || 'Please try again later.' });
  return st;
}

// Restart into the new version, but never while Molly is speaking or in the middle of something.
function requestRestart() {
  if (updater?.status.state !== 'ready') return { ok: false, message: 'No update is waiting.' };
  restartWanted = true;
  const tryNow = () => {
    const why = srv.busy();
    if (why) return why;
    log('restarting for update', updater.status.version);
    quitting = true;
    app.relaunch({ args: process.argv.slice(1).filter(a => a !== '--hidden') });
    app.quit();
    return null;
  };
  const why = tryNow();
  if (why && !requestRestart.timer) requestRestart.timer = setInterval(() => { if (!tryNow()) clearInterval(requestRestart.timer); }, 3000);
  return { ok: true, waiting: why };
}

// Refresh the page every night at 04:00 so a long-running window stays fresh.
function nightly() {
  const now = new Date(), next = new Date(now); next.setHours(4, 0, 0, 0); if (next <= now) next.setDate(next.getDate() + 1);
  setTimeout(() => { try { srv.reloadPage(); mainWin?.webContents.reloadIgnoringCache(); } catch {} nightly(); }, next - now);
}

// ---------------- start ----------------
app.on('second-instance', () => showMain());
app.on('activate', () => showMain());
app.on('before-quit', () => { quitting = true; });
app.on('window-all-closed', () => { if (SELFTEST) app.quit(); /* otherwise keep running in the menu bar */ });

app.whenReady().then(async () => {
  app.setName('Molly');
  try { app.setAboutPanelOptions({ applicationName: 'Molly', applicationVersion: CODE_VERSION, version: `app ${SHELL_VERSION}` }); } catch {}
  if (process.platform === 'darwin') { try { app.dock.setIcon(iconPath); } catch {} }
  try {
    srv = await createMollyServer({
      paths, port: SELFTEST ? 0 : PORT, log, version: CODE_VERSION,
      nodeBin: process.execPath, nodeEnv: { ELECTRON_RUN_AS_NODE: '1' },
      hooks: {
        notify, openExternal: u => shell.openExternal(u), openPath: p => shell.openPath(p), showInFolder: p => shell.showItemInFolder(p),
        saveFile: async ({ filename, data }) => {
          const r = await dialog.showSaveDialog(mainWin, { defaultPath: path.join(app.getPath('downloads'), filename) });
          if (r.canceled || !r.filePath) { const e = new Error('Download cancelled'); e.code = 'declined'; throw e; }
          fs.writeFileSync(r.filePath, data); return r.filePath;
        },
        chooseFolder: async def => { const r = await dialog.showOpenDialog(setupWin || mainWin, { properties: ['openDirectory'], defaultPath: def || path.join(os.homedir(), 'Library', 'CloudStorage') }); return r.canceled ? null : r.filePaths[0]; },
        askMic: async () => (process.platform === 'darwin' ? systemPreferences.askForMediaAccess('microphone') : true),
        micStatus: () => (process.platform === 'darwin' ? systemPreferences.getMediaAccessStatus('microphone') : 'granted'),
        voiceStatus: () => speech?.status() || {},
        setupDone: () => { setTimeout(() => { setLogin(true); buildTray(); appMenu(); showMain(); setupWin?.close(); sendWakeMode().catch(e => log('wake', e.message)); }, 300); },
        onGoogleConnected: () => { setupWin?.webContents.send('stt:event', { type: 'google-connected' }); },
        updateStatus: () => updateStatus(),
        checkUpdates: () => checkForUpdates(false),
        requestRestart: async () => requestRestart(),
      },
    });
  } catch (e) {
    log('server failed', e.stack || e);
    dialog.showErrorBox('Molly could not start', e.code === 'EADDRINUSE' ? `Another program is using Molly's port (${PORT}). Restart your Mac and try again.` : String(e.message || e));
    app.exit(1); return;
  }
  log('Molly running at', srv.url, 'data', paths.dataDir, `code ${CODE_VERSION} (${BOOT.source || 'direct'}) on shell ${SHELL_VERSION}`);
  startUpdater();
  if (BOOT.fallback) {
    log(`went back to ${CODE_VERSION}: ${BOOT.fallback.from} ${BOOT.fallback.reason}`);
    setTimeout(() => notify({ text: `Molly ${BOOT.fallback.from} didn't start properly, so Molly went back to version ${CODE_VERSION}. Nothing else changed.` }), 5000);
  }

  // microphone for our own page only
  const ours = u => String(u || '').startsWith(srv.url);
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb, details) => cb(ours(details?.requestingUrl || wc.getURL()) && ['media', 'notifications', 'clipboard-sanitized-write', 'clipboard-read', 'fullscreen'].includes(perm)));
  session.defaultSession.setPermissionCheckHandler((wc, perm, origin) => ours(origin || wc?.getURL()) && ['media', 'notifications', 'clipboard-sanitized-write', 'clipboard-read', 'fullscreen'].includes(perm));

  speech = new SpeechService({ spawnWorker, modelsReady: () => modelsReady(paths.models), modelsDir: paths.models, assistantName: () => profile().assistantName || 'Molly', log });
  speech.on('event', sendSTT);
  speech.on('wake', w => { showMain(); sendSTT({ type: 'wake', rest: w.rest }); });
  ipcMain.on('stt:audio', (_e, samples) => speech.audio(samples));
  ipcMain.handle('stt:start', (_e, o) => speech.sessionStart(o));
  ipcMain.handle('stt:stop', (_e, o) => speech.sessionStop(o));
  ipcMain.handle('setup:voices', () => []);
  ipcMain.on('renderer:log', (_e, lvl, msg) => log('page', lvl, msg));

  appMenu();
  if (!SELFTEST) {
    buildTray();
    srv.tasks.startCron();
    powerMonitor.on('resume', () => { log('woke from sleep'); try { srv.tasks.scheduler?.tick(); } catch {} });
    nightly();
  }

  if (SELFTEST) return selfTest();
  if (srv.settings.get().setupDone) { createMain(); if (srv.settings.get().openAtLogin !== false && !app.getLoginItemSettings().openAtLogin && app.isPackaged) setLogin(true); }
  else showSetup();
});

// ---------------- self-test (Linux CI / xvfb): does the page boot with the shim, without console errors? ----------------
async function selfTest() {
  const report = { url: srv.url, console: [], errors: [], checks: {} };
  srv.settings.set({ setupDone: true, profile: { firstName: 'Test', fullName: 'Test Person', email: 'test@example.com', town: 'Testtown', postcode: 'AB1', folders: ['Home', 'Money'] } });
  const w = createMain();
  w.webContents.on('console-message', function (e, l2, m2, ln2, src2) {
    const { level, message, lineNumber, sourceId } = e.message !== undefined ? e : { level: l2, message: m2, lineNumber: ln2, sourceId: src2 };
    const lvl = typeof level === 'number' ? ['verbose', 'info', 'warning', 'error'][level] : level;
    report.console.push({ level: lvl, message: String(message).slice(0, 500), line: lineNumber, source: sourceId });
  });
  w.webContents.on('preload-error', (_e, p, err) => report.errors.push('preload: ' + err.message));
  w.webContents.on('did-fail-load', (_e, code, desc) => report.errors.push('load failed: ' + desc));
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const M = process.env.MOLLY_SELFTEST_MODELS;
  if (M) { try { fs.rmSync(paths.models, { recursive: true, force: true }); fs.symlinkSync(M, paths.models); } catch (e) { report.errors.push('models: ' + e.message); } }
  await new Promise(r => w.webContents.once('did-finish-load', r));
  if (M) {
    // End-to-end voice: fake microphone (a WAV via Chromium flags) → polyfill → worklet → IPC → VAD + Moonshine → onresult
    report.voice = await w.webContents.executeJavaScript(`new Promise(res => {
      const r = new SpeechRecognition(); r.continuous = true; r.interimResults = true; const got = []; let interim = 0;
      r.onresult = e => { for (let i = e.resultIndex; i < e.results.length; i++) { if (e.results[i].isFinal) got.push(e.results[i][0].transcript); else interim++; } };
      r.onerror = e => got.push('ERROR ' + e.error);
      r.start(); setTimeout(() => { r.stop(); setTimeout(() => res({ finals: got, interim }), 2500); }, ${Number(process.env.MOLLY_SELFTEST_LISTEN || 12000)});
    })`).catch(e => ({ error: String(e) }));
  }
  await wait(Number(process.env.MOLLY_SELFTEST_WAIT || 12000));
  try {
    report.checks = await w.webContents.executeJavaScript(`(async () => {
      const c = window.claude; const out = { hasClaude: !!(c && c.use), sr: typeof window.SpeechRecognition, native: !!window.mollyNative };
      const db = await c.use('db'); await db.doc('selftest/one').set({ a: 1, gone: 2 }); await db.doc('selftest/one').update({ gone: { __delete__: true }, b: 2 });
      out.db = (await db.doc('selftest/one').get()).data();
      out.snapshot = await new Promise(res => { const un = db.collection('selftest').onSnapshot(s => { un(); res(s.size); }); });
      out.title = document.title; out.bodyText = document.body.innerText.slice(0, 200);
      out.canvas = document.querySelectorAll('canvas').length;
      out.notice = (document.getElementById('notice') || {}).textContent || '';
      out.updateBanner = (() => { const b = document.getElementById('mollyUpdate'); return b && !b.hidden ? b.innerText : null; })();
      out.update = await window.__mollyShim.post('/api/update', {});
      return out; })()`);
    if (process.env.MOLLY_SELFTEST_CHAT) {
      // Real Claude Code round-trip through the shim: streaming text + a page tool run in the renderer.
      report.chat = await w.webContents.executeJavaScript(`(async () => {
        const sample = await window.claude.use('sample'); const texts = []; let toolRan = null;
        const r = await sample([{ role: 'user', content: 'Use the lucky_number tool, then reply with one short sentence that includes the number.' }], { modelTier: 'quick',
          tools: [{ name: 'lucky_number', description: 'Returns the lucky number', inputSchema: { type: 'object', properties: {} }, execute: async a => { toolRan = a; return { number: 7319 }; } }],
          onText: ({ text }) => texts.push(text) });
        const j = await sample.json('Return {"ok": true, "n": 3} as JSON.', { modelTier: 'quick' });
        return { text: r.text, streamed: texts.length, toolRan: !!toolRan, json: j };
      })()`).catch(e => ({ error: String(e) }));
    }
    const png = await w.webContents.capturePage();
    fs.writeFileSync(path.join(paths.dataDir, 'selftest.png'), png.toPNG());
    report.screenshot = path.join(paths.dataDir, 'selftest.png');
  } catch (e) { report.errors.push('checks: ' + (e.stack || e)); }
  const out = process.env.MOLLY_SELFTEST_OUT || path.join(paths.dataDir, 'selftest.json');
  report.codeVersion = CODE_VERSION; report.bootSource = BOOT.source || 'direct';
  if (process.env.MOLLY_SELFTEST_RESTART && report.checks?.update?.state === 'ready') {
    // Test the "Restart Molly" button: the app relaunches into the new code (and runs this self-test again).
    fs.writeFileSync(out.replace(/\.json$/, `-before-restart.json`), JSON.stringify(report, null, 2));
    log('selftest restarting for the update');
    const r = requestRestart();
    if (r.ok) return;
  }
  fs.writeFileSync(out, JSON.stringify(report, null, 2));
  log('selftest report', out);
  quitting = true; await srv.close(); app.exit(0);
}

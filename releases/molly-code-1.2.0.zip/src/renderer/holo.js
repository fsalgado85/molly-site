/* Molly.app — Holo screen. The backdrop is the owner's own picture of the futuristic desk (holo-room.jpg:
   skyscraper window, desk, plant, lighting, glass panels), cleaned of its sample text. Molly's live
   content is laid exactly into the picture's glass panels (each panel is mapped onto the picture's
   slightly curved panel with a perspective transform), and Molly's own 3D robot stands inside the ring.
   Nothing new is invented: every panel shows what Molly's page already knows (window.__mollyHolo,
   a read-only hook added at build time) and every button presses one of the page's own buttons.
   The 3D desk room comes forward whenever it has something to show, then the Holo screen returns. */
(function () {
  'use strict';
  if (window.__mollyHoloUI) return;
  window.__mollyHoloUI = true;

  const LS = 'molly.look';
  const pref = () => { try { return localStorage.getItem(LS) || 'holo'; } catch { return 'holo'; } };
  const setPref = v => { try { localStorage.setItem(LS, v); } catch {} };
  const BOOT = window.__MOLLY_BOOT || {};
  const PROFILE = BOOT.profile || {};
  const TZ = PROFILE.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/London';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const BIG = matchMedia('(min-width: 900px) and (min-height: 540px)');

  /* ---------- the picture's geometry (in picture pixels, 1230 × 673) ---------- */
  const IW = 1230, IH = 673;
  const QUADS = {
    hxMail: [[135, 98], [438, 108], [438, 214], [135, 210]],
    hxCal: [[134, 216], [439, 220.5], [439, 321.4], [134, 322.4]],
    hxPts: [[134, 329], [439, 332], [439, 429.4], [134, 436.5]],
    hxWx: [[792.3, 113.4], [1098.5, 99.1], [1100.7, 208.2], [794.4, 215.3]],
    hxMkt: [[796, 223.9], [1099.4, 218.1], [1101.8, 321.4], [796, 322.3]],
    hxBills: [[795, 331.2], [1101, 327.8], [1101, 436.4], [795, 429.7]],
  };
  const RING = { cx: 615, cy: 200, size: 236 };
  const QUICK = [[474, 363, 537, 420], [548, 363, 613, 420], [623, 363, 688, 420], [698, 363, 763, 420]];
  const DOCK = { y0: 460, y1: 510, xs: [325, 400, 474, 548, 621, 693, 764, 834, 902], w: 68 };
  const TALK = { x0: 405, x1: 825, y0: 611, y1: 641 };

  /* ---------- small line icons ---------- */
  const I = p => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
  const ICON = {
    mail: I('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6.5 8.5-6.5"/>'),
    mailFill: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="5" width="19" height="14" rx="2.2" fill="#6fb4ff"/><path d="m3.5 6.5 8.5 6.6 8.5-6.6" fill="none" stroke="#0d2747" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    cal: I('<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>'),
    points: I('<circle cx="12" cy="12" r="8.5"/><path d="m8.2 12.3 2.6 2.6 5-5.4"/>'),
    wx: I('<path d="M7.5 18.5h9.2a3.8 3.8 0 0 0 .4-7.6 5.3 5.3 0 0 0-10.2 1.4 3.1 3.1 0 0 0 .6 6.2Z"/><path d="M16.5 5.2a3.4 3.4 0 0 1 4 3.6"/>'),
    mkt: I('<path d="m3.5 17 5.5-5.5 4 3.5 7-7.5"/><path d="M15.5 7.5h4.5V12"/>'),
    bills: I('<rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M8.5 8h7M8.5 11.5h7M8.5 15h4.5"/>'),
    mic: I('<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5"/>'),
    sun: I('<circle cx="12" cy="12" r="4"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/>'),
    chase: I('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><path d="m12 12 7-7M15.5 5H19v3.5"/>'),
    moon: I('<path d="M19.5 14.5A7.8 7.8 0 1 1 9.5 4.5a6.3 6.3 0 0 0 10 10Z"/>'),
    paper: I('<path d="M4 5.5h13v13a1.5 1.5 0 0 0 3 0V8.5h-3"/><path d="M7 9h7M7 12.5h7M7 16h4"/>'),
    watch: I('<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/><path d="M8 11.5l2 2 4-4"/>'),
    desk: I('<path d="M3 10.5h18M5 10.5v9M19 10.5v9"/><rect x="8" y="4.5" width="8" height="6" rx="1"/>'),
    soundOn: I('<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4Z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a7.8 7.8 0 0 1 0 11"/>'),
    soundOff: I('<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4Z"/><path d="m16 9.5 5 5M21 9.5l-5 5"/>'),
  };

  /* ---------- formatting ---------- */
  const tfmt = (d, o) => { try { return new Date(d).toLocaleString('en-GB', { timeZone: TZ, ...o }); } catch { return ''; } };
  const hm = d => tfmt(d, { hour: '2-digit', minute: '2-digit' });
  const dayKey = d => tfmt(d, { year: 'numeric', month: '2-digit', day: '2-digit' });
  const todayKey = () => dayKey(Date.now());
  const shortFrom = f => { const s = String(f || '').replace(/<[^>]*>/g, '').replace(/"/g, '').trim(); return s || String(f || '').replace(/[<>]/g, '') || 'Someone'; };
  const mailWhen = d => { if (!d) return ''; return dayKey(d) === todayKey() ? hm(d) : tfmt(d, { day: 'numeric', month: 'short' }); };
  const money = n => { const v = Number(n); return isFinite(v) && v > 0 ? '£' + v.toLocaleString('en-GB', { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }) : ''; };
  const dateShort = k => { try { return new Date(k + 'T12:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }); } catch { return k; } };

  /* ---------- panels (content only: the glass is the picture's own) ---------- */
  const head = (key, icon, title, right = '') =>
    `<button class="hx-ph" type="button" data-hx-go="${key}"><span class="hx-pi">${ICON[icon]}</span><h2>${esc(title)}</h2><span class="hx-sp"></span>${right}<span class="hx-chev">›</span></button>`;
  const empty = t => `<div class="hx-empty">${esc(t)}</div>`;

  function pMail(d) {
    const u = d.unread, top = (d.unreadTop || []).slice(0, 4);
    const n = u ? (u.recent ?? u.primary ?? u.all) : null;
    const rows = top.map(t => `<button class="hx-r" type="button" data-hx-go="inbox"><span class="hx-env">${ICON.mailFill}</span><span class="hx-t"><b>${esc(t.subject)}</b><small>${esc(shortFrom(t.from))}</small></span><span class="hx-m">${esc(mailWhen(t.date))}</span></button>`).join('');
    return head('inbox', 'mail', 'Email', n ? `<span class="hx-badge">${esc(n)} unread</span>` : '') +
      `<div class="hx-pb">${rows || empty(!d.mcp ? 'Connect Google in Molly’s menu to see your email.' : u ? 'No unread email.' : 'Checking your inbox…')}</div>`;
  }

  function pCal(d) {
    const now = Date.now(), t = todayKey();
    const live = (d.events || []).filter(e => !e.free && !e.holiday);
    const isToday = e => e.allDay ? dayKey(String(e.start).slice(0, 10) + 'T12:00:00') === t : dayKey(e.start) === t;
    let list = live.filter(e => isToday(e) && (e.allDay || new Date(e.end || e.start).getTime() > now)), label = 'Today';
    if (!list.length) { list = live.filter(e => new Date(e.allDay ? e.start + 'T23:59:00' : (e.end || e.start)).getTime() > now); label = 'Coming up'; }
    list = list.sort((a, b) => String(a.start).localeCompare(String(b.start))).slice(0, 5);
    const when = e => e.allDay ? (label === 'Today' ? 'All day' : dateShort(String(e.start).slice(0, 10))) : (dayKey(e.start) === t ? hm(e.start) : tfmt(e.start, { weekday: 'short' }) + ' ' + hm(e.start));
    const rows = list.map((e, i) => `<button class="hx-r hx-cal" type="button" data-hx-meeting="${esc(e.id)}"><span class="hx-bar" style="--c:${esc(e.calHex || (i % 3 === 2 ? '#f5b23d' : '#3fd8ff'))}"></span><span class="hx-time">${esc(when(e))}</span><span class="hx-t"><b>${esc(e.title)}</b></span></button>`).join('');
    return head('calendar', 'cal', 'Calendar', `<span class="hx-lab">${label}</span>`) +
      `<div class="hx-pb">${rows || empty(!d.mcp ? 'Connect Google in Molly’s menu to see your calendar.' : d.eventsLoaded ? 'Nothing else in your calendar.' : 'Loading your calendar…')}</div>`;
  }

  const KIND = { you: 'On you', over: 'Overdue', fresh: 'New', them: 'Waiting' };
  function pPoints(d) {
    const L = d.points || [];
    const rows = L.slice(0, 6).map(p => `<button class="hx-r" type="button" data-hx-point="${esc(p.id)}"><span class="hx-bar k-${esc(p.kind)}"></span><span class="hx-t"><b>${esc(p.title)}</b></span><span class="hx-pill k-${esc(p.kind)}">${KIND[p.kind] || ''}</span></button>`).join('');
    return head('points', 'points', 'Open Points', L.length ? `<span class="hx-count">${L.length}</span>` : '') +
      `<div class="hx-pb">${rows || empty(d.db ? 'Nothing open. Nice work.' : 'Your matters aren’t loaded yet.')}</div>`;
  }

  function pWx(d, H) {
    const w = d.weather;
    if (!w) return head('weather', 'wx', 'Weather') + `<div class="hx-pb">${empty('The forecast arrives with the next update.')}</div>`;
    const now = w.now || {}, d0 = (w.days || [])[0] || {};
    const ic = t => { const u = H.wxIcon(t); return u ? `<img alt="" src="${esc(u)}">` : ''; };
    const days = (w.days || []).slice(1, 4).map(x => `<span class="hx-wd"><small>${esc(tfmt(x.date + 'T12:00:00', { weekday: 'short' }))}</small>${ic(x.type)}<b>${esc(x.max)}°/${esc(x.min)}°</b></span>`).join('');
    return head('weather', 'wx', w.place ? `Weather – ${w.place}` : 'Weather') +
      `<div class="hx-pb"><div class="hx-wx"><div class="hx-wxnow">${ic(now.type || d0.type)}<div><b>${esc(now.temp ?? d0.max ?? '–')}°C</b><small>${esc(now.type || d0.type || '')}</small><small>H: ${esc(d0.max ?? '–')}°C&nbsp;&nbsp;L: ${esc(d0.min ?? '–')}°C</small></div></div>${days}</div></div>`;
  }

  // Same five-day series as the markets screen on the desk.
  function series(q) {
    const today = new Date().toISOString().slice(0, 10);
    const D = (q.days || []).filter(x => x && x.d && isFinite(+x.c)).sort((a, b) => a.d.localeCompare(b.d));
    const prev = D.filter(x => x.d < today).slice(-5).map(x => ({ t: new Date(x.d + 'T21:00:00Z').getTime(), p: +x.c }));
    const cut = Date.now() - 5 * 864e5;
    const hist = (q.history || []).filter(p => p && p.t && isFinite(+p.p) && new Date(p.t).getTime() > cut).map(p => ({ t: new Date(p.t).getTime(), p: +p.p }));
    const S = [...prev, ...hist.filter(p => !prev.length || p.t > prev[prev.length - 1].t)];
    if (q.price != null && (!S.length || Math.abs(S[S.length - 1].p - q.price) > 1e-9)) S.push({ t: Date.now(), p: +q.price });
    return S;
  }
  let sparkN = 0;
  function spark(S, up) {
    if (S.length < 2) return '<svg viewBox="0 0 60 16"></svg>';
    const ps = S.map(s => s.p), mn = Math.min(...ps), mx = Math.max(...ps), rg = (mx - mn) || 1;
    const P = S.map((s, i) => [i / (S.length - 1) * 60, 14 - (s.p - mn) / rg * 12]);
    const pts = P.map(p => p.map(v => v.toFixed(1)).join(',')).join(' ');
    const col = up ? '#36e39a' : '#ff6b81', id = 'hxSp' + (++sparkN);
    return `<svg viewBox="0 0 60 16" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs><polygon points="0,16 ${pts} 60,16" fill="url(#${id})"/><polyline points="${pts}" fill="none" stroke="${col}" stroke-width="1.3" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
  }
  function pMkt(d) {
    const m = d.markets, Q = ((m && m.quotes) || []).slice(0, 5);
    const fmtP = q => q.price == null ? '–' : ((/^GBP|^EUR|^USD/.test(q.sym || '') || Math.abs(q.price) < 20) ? Number(q.price).toFixed(4) : Number(q.price).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
    const rows = Q.map(q => {
      const up = (q.changePct ?? q.change ?? 0) >= 0;
      return `<div class="hx-mk"><b>${esc(q.name || q.sym)}</b>${spark(series(q), up)}<span class="hx-pp">${esc(fmtP(q))}</span><span class="hx-c ${up ? 'hx-up' : 'hx-down'}">${q.changePct != null ? (up ? '+ ' : '− ') + Math.abs(Number(q.changePct)).toFixed(2) + '%' : ''}</span></div>`;
    }).join('');
    return head('markets', 'mkt', 'Markets') + `<div class="hx-pb">${rows || empty('Prices arrive with the next update.')}</div>`;
  }

  function pBills(d) {
    const L = d.renewals || [];
    const due = r => r.days == null ? '' : r.days < 0 ? 'Overdue' : r.days === 0 ? 'Due today' : 'Due ' + dateShort(r.date);
    const amt = r => r.monthly ? money(r.monthly) + '/mo' : r.annualCost ? money(r.annualCost) : '';
    const rows = L.slice(0, 5).map(r => `<button class="hx-r hx-bill" type="button" data-hx-go="bills"><span class="hx-sq ${r.days != null && r.days <= 7 ? 'soon' : ''}"></span><span class="hx-t"><b>${esc(String(r.title).replace(/\s*\(.*?\)/g, ''))}</b></span><span class="hx-due">${esc(due(r))}</span><span class="hx-amt">${esc(amt(r))}</span></button>`).join('');
    return head('bills', 'bills', 'Bills & Renewals', L.length ? `<span class="hx-badge red">${L.length} due</span>` : '') +
      `<div class="hx-pb">${rows || empty('Nothing due in the next month.')}</div>`;
  }

  /* ---------- perspective: map a w × h box onto one of the picture's panels ---------- */
  function matrix3d(w, h, q) {
    const [[x0, y0], [x1, y1], [x2, y2], [x3, y3]] = q;
    const dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
    const den = dx1 * dy2 - dx2 * dy1;
    const g = (dx3 * dy2 - dx2 * dy3) / den, k = (dx1 * dy3 - dx3 * dy1) / den;
    const a = x1 - x0 + g * x1, b = x3 - x0 + k * x3, c = x0, d = y1 - y0 + g * y1, e = y3 - y0 + k * y3, f = y0;
    return `matrix3d(${[a / w, d / w, 0, g / w, b / h, e / h, 0, k / h, 0, 0, 1, 0, c, f, 0, 1].map(v => +v.toFixed(8)).join(',')})`;
  }
  const qsize = q => [Math.round((Math.hypot(q[1][0] - q[0][0], q[1][1] - q[0][1]) + Math.hypot(q[2][0] - q[3][0], q[2][1] - q[3][1])) / 2), Math.round((Math.hypot(q[3][0] - q[0][0], q[3][1] - q[0][1]) + Math.hypot(q[2][0] - q[1][0], q[2][1] - q[1][1])) / 2)];

  /* ---------- building the screen ---------- */
  let H = null, root = null, stage = null, core = null, sig = {}, shown = null, backT = null, override = false, scale = 1, offX = 0, offY = 0;
  const box = (x0, y0, x1, y1) => `left:${x0}px;top:${y0}px;width:${x1 - x0}px;height:${y1 - y0}px`;

  function build() {
    root = document.createElement('div');
    root.id = 'holo'; root.className = 'off'; root.setAttribute('aria-label', 'Molly');
    const panels = Object.entries(QUADS).map(([id, q]) => { const [w, h] = qsize(q); return `<section class="hx-p" id="${id}" style="width:${w}px;height:${h}px;transform:${matrix3d(w, h, q)}"></section>`; }).join('');
    const quick = [['hxTalk', 'mic', 'Talk', ''], ['', 'sun', 'Briefing', 'data-hx-press="hGo"'], ['', 'chase', 'Chase', `data-hx-chip='[data-q="What should I chase this week?"]'`], ['', 'moon', 'Wrap up', `data-hx-chip='[data-hq="wrap"]'`]]
      .map(([id, ic, label, attr], i) => `<button class="hx-q" type="button" ${id ? `id="${id}" aria-pressed="false"` : ''} ${attr} style="${box(...QUICK[i])}">${ICON[ic]}<span>${label}</span></button>`).join('');
    const dockItems = [['inbox', 'mail', 'Email'], ['calendar', 'cal', 'Calendar'], ['points', 'points', 'Points'], ['news', 'paper', 'Paper'], ['markets', 'mkt', 'Markets'], ['weather', 'wx', 'Weather'], ['bills', 'bills', 'Bills'], ['watchlist', 'watch', 'Watchlist'], ['desk', 'desk', 'Desk']];
    const dock = dockItems.map(([k, ic, label], i) => `<button class="hx-d ${i === 0 ? 'on' : ''}" type="button" data-hx-dock="${k}" style="${box(DOCK.xs[i] - DOCK.w / 2, DOCK.y0, DOCK.xs[i] + DOCK.w / 2, DOCK.y1)}">${ICON[ic]}<span>${label}</span></button>`).join('');
    root.innerHTML = `<div class="hx-stage" id="hxStage">
      <img class="hx-bg" src="/molly/holo-room.jpg" alt="" draggable="false">
      <div class="hx-brand" style="${box(212, 50, 302, 92)}"><b id="hxBrand">MOLLY</b><small>Personal assistant</small></div>
      <div class="hx-greet" style="${box(306, 56, 520, 102)}"><h1 id="hxHi"></h1><p>Here’s your update at a glance.</p></div>
      <div class="hx-now" style="${box(860, 52, 978, 104)}"><small id="hxDate"></small><b id="hxTime"></b></div>
      <button class="hx-ib" type="button" id="hxSound" aria-label="Sound" style="${box(1002, 52, 1034, 84)}">${ICON.soundOff}</button>
      <button class="hx-ib ghost" type="button" id="hxSet" aria-label="Settings" title="Settings" style="${box(1056, 50, 1092, 86)}"></button>
      ${panels}
      <div class="hx-ring" id="hxCore" data-state="idle" style="${box(RING.cx - RING.size / 2, RING.cy - RING.size / 2, RING.cx + RING.size / 2, RING.cy + RING.size / 2)}"><div class="hx-bot3d" id="hxBot3d"></div><button class="hx-bothit" type="button" id="hxBot" aria-label="Talk to Molly"></button></div>
      <div class="hx-statebox" style="${box(520, 288, 710, 306)}"><span class="hx-state" id="hxState">Ready</span></div>
      <div class="hx-say" style="${box(470, 308, 760, 356)}"><div class="hx-cap ask" id="hxCap" aria-live="polite"></div></div>
      ${quick}
      ${dock}
    </div>`;
    document.body.appendChild(root);
    stage = $('hxStage'); core = $('hxCore');

    const acts = document.querySelector('#home .hacts');
    if (acts && !$('hxToHolo')) {
      const b = document.createElement('button');
      b.className = 'btn small ghost hx-to'; b.type = 'button'; b.id = 'hxToHolo'; b.textContent = '✦ Holo view';
      b.addEventListener('click', () => { setPref('holo'); override = true; try { H.wide(); } catch {} update(true); });
      acts.prepend(b);
    }
    root.addEventListener('click', onClick);
    window.addEventListener('resize', () => { layout(); update(true); });
    BIG.addEventListener?.('change', () => update(true));
    if (window.__mollyHoloBot) window.__mollyHoloBot.mount($('hxBot3d'));
  }

  // Fit the picture to the window (cover), always keeping the panels in view.
  function layout() {
    if (!stage) return;
    const vw = innerWidth, vh = innerHeight;
    scale = Math.max(vw / IW, vh / IH);
    if (vw / scale < 990) scale = vw / 990;          // never crop the panels
    offX = (vw - IW * scale) / 2;
    offY = (vh - IH * scale) / 2;
    stage.style.transform = `translate(${offX}px, ${offY}px) scale(${scale})`;
    placeTalk(); fit();
  }
  // The page's own talk box sits on the front of the desk.
  function placeTalk() {
    const bar = document.querySelector('#home .hbar'); if (!bar) return;
    if (!shown) { for (const p of ['left', 'top', 'width', '--hx-s']) bar.style.removeProperty(p); return; }
    bar.style.left = Math.round(offX + TALK.x0 * scale) + 'px';
    bar.style.top = Math.round(offY + TALK.y0 * scale) + 'px';
    bar.style.width = Math.round((TALK.x1 - TALK.x0) * scale) + 'px';
    bar.style.setProperty('--hx-s', String(scale));
  }

  function press(id) { const b = $(id); if (b && !b.disabled) b.click(); }
  function go(g) { const b = document.querySelector(`#hToday [data-go="${g}"]`); if (b) b.click(); }
  function onClick(e) {
    const t = e.target.closest('button'); if (!t || !root.contains(t)) return;
    if (t.dataset.hxMeeting) return H.meeting(t.dataset.hxMeeting);
    if (t.dataset.hxPoint) return H.point(t.dataset.hxPoint);
    if (t.dataset.hxGo) return t.dataset.hxGo === 'markets' ? H.markets() : go(t.dataset.hxGo);
    if (t.dataset.hxDock) {
      const k = t.dataset.hxDock;
      if (k === 'desk') { setPref('room'); override = false; return update(true); }
      if (k === 'markets') return H.markets();
      if (k === 'watchlist') { const c = document.querySelector('#hChips [data-hq="watchlist"]'); if (c) c.click(); return; }
      return go(k);
    }
    if (t.dataset.hxPress) return press(t.dataset.hxPress);
    if (t.dataset.hxChip) { const c = document.querySelector('#hChips ' + t.dataset.hxChip); if (c) c.click(); return; }
    switch (t.id) {
      case 'hxBot': try { window.__mollyHoloBot && window.__mollyHoloBot.wave(); } catch {} return press('bot');
      case 'hxTalk': return press('hMic');
      case 'hxSound': press('hmSound'); return setTimeout(mirror, 50);
      case 'hxSet': return press('hmSettings');
    }
  }

  /* ---------- keeping it in step with the page ---------- */
  const STATE = { idle: 'Ready', waiting: 'Your turn', thinking: 'Thinking…', speaking: 'Speaking' };
  function mirror() {
    if (!root) return;
    const st = $('hStage'), mic = $('hMic'), snd = $('hmSound');
    const s = (st && st.dataset.state) || 'idle';
    const listening = !!mic && mic.getAttribute('aria-pressed') === 'true';
    core.dataset.state = s; core.classList.toggle('listening', listening);
    $('hxState').textContent = listening ? 'Listening…' : (STATE[s] || 'Ready');
    $('hxState').dataset.state = listening ? 'listening' : s;
    $('hxTalk').setAttribute('aria-pressed', String(listening));
    const cap = ($('hCap') && $('hCap').textContent.trim()) || '';
    const c = $('hxCap');
    if (cap) { if (c.textContent !== cap) c.textContent = cap; c.classList.remove('ask'); } else { c.textContent = 'How can I help you today?'; c.classList.add('ask'); }
    if (snd) { const on = snd.getAttribute('aria-pressed') === 'true'; const b = $('hxSound'); if (b.dataset.on !== String(on)) { b.dataset.on = String(on); b.title = on ? 'Sound on' : 'Sound off'; b.innerHTML = on ? ICON.soundOn : ICON.soundOff; } }
    let stop = $('hxStop');
    if (s === 'speaking' && !stop) {
      stop = document.createElement('button'); stop.id = 'hxStop'; stop.type = 'button'; stop.className = 'hx-stop'; stop.textContent = '■ Stop';
      stop.addEventListener('click', () => press('hStop'));
      $('hxState').after(stop);
    } else if (s !== 'speaking' && stop) stop.remove();
  }

  function greet() {
    const h = +tfmt(Date.now(), { hour: '2-digit', hour12: false });
    const hi = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
    return PROFILE.firstName ? `${hi}, ${PROFILE.firstName}.` : `${hi}.`;
  }

  function paint(force) {
    let d; try { d = H.peek(); } catch { return; }
    $('hxTime').textContent = hm(Date.now());
    $('hxDate').textContent = tfmt(Date.now(), { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    $('hxHi').textContent = greet();
    const brand = String(d.name || 'Molly').toUpperCase(); if ($('hxBrand').textContent !== brand) $('hxBrand').textContent = brand;
    const put = (id, key, html) => { if (force || sig[id] !== key) { sig[id] = key; $(id).innerHTML = html(); } };
    const minute = Math.floor(Date.now() / 6e4);
    put('hxMail', JSON.stringify([d.unread, (d.unreadTop || []).map(t => t.id + t.date), d.mcp, minute >> 4]), () => pMail(d));
    put('hxCal', JSON.stringify([(d.events || []).map(e => e.id + e.start + e.title), d.eventsLoaded, d.mcp, minute]), () => pCal(d));
    put('hxPts', JSON.stringify([d.points, d.db]), () => pPoints(d));
    put('hxWx', JSON.stringify([d.weather && d.weather.at, d.weather && d.weather.now]), () => pWx(d, H));
    put('hxMkt', JSON.stringify([d.markets && d.markets.at, d.markets && d.markets.status, (d.markets && d.markets.quotes || []).map(q => q.price)]), () => pMkt(d));
    put('hxBills', JSON.stringify(d.renewals), () => pBills(d));
    fit();
    return d;
  }

  // Show only the rows that fit in each panel (no half-cut rows).
  function fit() {
    if (!root) return;
    for (const pb of root.querySelectorAll('.hx-pb')) {
      const rows = [...pb.children]; rows.forEach(r => r.classList.remove('hx-cut'));
      const max = pb.clientHeight; if (!max) continue;
      let cut = false;
      for (const r of rows) if (cut || r.offsetTop - pb.offsetTop + r.offsetHeight > max - 3) { cut = true; r.classList.add('hx-cut'); }
    }
  }

  // The room comes forward while it has something to show.
  function roomBusy(d) {
    const st = $('hStage'), home = $('home');
    const c = st ? st.classList : null;
    return !!((c && (c.contains('close') || c.contains('pad-on') || c.contains('mailview') || c.contains('reading'))) || (home && home.classList.contains('deck-on')) || (d && d.running));
  }

  function update(force) {
    if (!root) return;
    let d = null; try { d = H.peek(); } catch {}
    const busy = roomBusy(d);
    if (!busy) override = false;
    const want = pref() === 'holo' && BIG.matches && document.body.classList.contains('home-on') && (!busy || override);
    if (want === shown && !force) return;
    clearTimeout(backT);
    const apply = () => {
      shown = want;
      root.classList.toggle('off', !want);
      document.documentElement.classList.toggle('hx-on', want);
      const to = $('hxToHolo'); if (to) to.hidden = !BIG.matches;
      try { window.__mollyHoloBot && window.__mollyHoloBot.show(want); } catch {}
      layout();
      if (want) { paint(true); mirror(); }
    };
    if (want && shown === false && !force) backT = setTimeout(apply, 700); else apply();
  }

  function start() {
    H = window.__mollyHolo;
    if (!H || !$('home')) return false;
    build();
    const mo = new MutationObserver(() => { mirror(); update(); });
    const watch = (el, opts) => { if (el) mo.observe(el, opts); };
    watch($('hStage'), { attributes: true, attributeFilter: ['class', 'data-state'] });
    watch($('home'), { attributes: true, attributeFilter: ['class'] });
    watch(document.body, { attributes: true, attributeFilter: ['class'] });
    watch($('hCap'), { childList: true, characterData: true, subtree: true });
    watch($('hMic'), { attributes: true, attributeFilter: ['aria-pressed'] });
    watch($('hmSound'), { attributes: true, attributeFilter: ['aria-pressed'] });
    setInterval(() => { if (shown) paint(false); update(); }, 1000);
    paint(true); mirror(); update(true);
    return true;
  }

  const boot = () => { let n = 0; const t = setInterval(() => { if (start() || ++n > 120) clearInterval(t); }, 250); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

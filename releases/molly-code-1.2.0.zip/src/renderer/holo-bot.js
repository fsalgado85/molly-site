/* Molly.app — Molly's own 3D robot for the Holo screen, standing inside the ring.
   Same model as on the 3D desk (shell, visor, glowing eyes and smile, ears, sturdy arms), rebuilt in
   its own small transparent scene. She follows Molly's state from the page: idle, listening ("waiting"),
   thinking and speaking (mouth and arms move). Uses the page's own copy of three.js (three.min.js). */
(function () {
  'use strict';
  if (window.__mollyHoloBot) return;
  let T = null, renderer, scene, camera, RB, rig, head, parts, host, visible = false, raf = 0, last = 0;
  const look = { x: 0, y: 0, tx: 0, ty: 0 };
  const ease = (a, b, k, dt) => a + (b - a) * (1 - Math.pow(1 - k, dt * 60));

  function needThree() {
    return new Promise(res => {
      if (window.THREE) return res(window.THREE);
      let s = document.querySelector('script[src$="three.min.js"]');
      if (!s) { s = document.createElement('script'); s.src = 'three.min.js'; s.async = true; document.head.appendChild(s); }
      const t = setInterval(() => { if (window.THREE) { clearInterval(t); res(window.THREE); } }, 100);
    });
  }

  function envMap() {
    // a small studio: dark room, a wide cool panel above, a warm strip to the side, a cyan rim behind
    const s = new T.Scene();
    s.add(new T.Mesh(new T.BoxGeometry(20, 20, 20), new T.MeshBasicMaterial({ color: 0x0b1626, side: T.BackSide })));
    const panel = (w, h, c, x, y, z, ry = 0, rx = 0) => { const m = new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshBasicMaterial({ color: c, side: T.DoubleSide })); m.position.set(x, y, z); m.rotation.set(rx, ry, 0); s.add(m); };
    panel(12, 4, new T.Color(2.2, 2.4, 2.8), 0, 9, 0, 0, Math.PI / 2);
    panel(3, 8, new T.Color(2.6, 1.6, .9), -9, 2, 2, Math.PI / 2);
    panel(4, 8, new T.Color(.5, 1.6, 3.0), 8, 1, -6, -Math.PI / 3);
    panel(10, 3, new T.Color(.9, 1.1, 1.4), 0, 2, 9, Math.PI);
    const pm = new T.PMREMGenerator(renderer);
    const tex = pm.fromScene(s, .02).texture; pm.dispose();
    return tex;
  }

  function build() {
    renderer = new T.WebGLRenderer({ antialias: true, alpha: true, premultipliedAlpha: true, powerPreference: 'high-performance' });
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = T.SRGBColorSpace;
    renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
    scene = new T.Scene();
    scene.environment = envMap();
    camera = new T.PerspectiveCamera(24, 1, .1, 50);
    camera.position.set(0, .12, 8.3); camera.lookAt(0, .05, 0);
    const key = new T.DirectionalLight(0xdbe8ff, 1.6); key.position.set(-2.5, 4, 5); scene.add(key);
    const rim = new T.DirectionalLight(0x58c8ff, 2.2); rim.position.set(3, 1.5, -4); scene.add(rim);
    const warm = new T.DirectionalLight(0xffb070, .5); warm.position.set(-4, -1, 2); scene.add(warm);
    scene.add(new T.HemisphereLight(0x9cc8ff, 0x0a1830, .5));

    RB = new T.Group(); scene.add(RB); rig = new T.Group(); rig.position.y = -.5; RB.add(rig);
    const shell = new T.MeshPhysicalMaterial({ color: 0xe9ecef, roughness: .24, metalness: .05, clearcoat: .9, clearcoatRoughness: .12, sheen: .4, sheenColor: new T.Color(0xdfe8ff), sheenRoughness: .5 });
    const glass = new T.MeshPhysicalMaterial({ color: 0x040506, roughness: .06, metalness: .4, clearcoat: 1, clearcoatRoughness: .04 });
    const graph = new T.MeshStandardMaterial({ color: 0x2b3038, metalness: .7, roughness: .32 });
    const seam = new T.MeshStandardMaterial({ color: 0x9aa3ad, roughness: .6 });
    const glowCol = new T.Color(.35, 1.25, 2.2); const glow = new T.MeshBasicMaterial({ color: glowCol.clone(), toneMapped: false });
    const prof = [[0, .44], [.22, .43], [.37, .38], [.455, .27], [.48, .1], [.465, -.08], [.415, -.26], [.335, -.42], [.215, -.55], [.09, -.62], [0, -.64]].reverse();
    rig.add(new T.Mesh(new T.LatheGeometry(new T.SplineCurve(prof.map(([x, y]) => new T.Vector2(x, y))).getPoints(60), 72), shell));
    const line = new T.Mesh(new T.TorusGeometry(.455, .0065, 8, 120), glow); line.rotation.x = Math.PI / 2; line.position.y = -.14; rig.add(line);
    const seam1 = new T.Mesh(new T.TorusGeometry(.476, .004, 6, 120), seam); seam1.rotation.x = Math.PI / 2; seam1.position.y = .12; rig.add(seam1);
    const led = new T.Mesh(new T.CircleGeometry(.022, 24), glow); led.position.set(0, .22, .452); led.rotation.x = -.15; rig.add(led);
    head = new T.Group(); head.position.y = 1.0; rig.add(head);
    const skull = new T.Mesh(new T.SphereGeometry(.52, 72, 54), shell); skull.scale.set(1, .92, .97); head.add(skull);
    const hs = new T.Mesh(new T.TorusGeometry(.47, .004, 6, 120), seam); hs.position.y = .2; hs.rotation.x = Math.PI / 2; head.add(hs);
    const visor = new T.Mesh(new T.SphereGeometry(1, 72, 48), glass); visor.scale.set(.45, .31, .375); visor.position.set(0, -.02, .17); head.add(visor);
    const ear = x => { const e = new T.Mesh(new T.CylinderGeometry(.14, .14, .11, 48), graph); e.rotation.z = Math.PI / 2; e.position.x = x; head.add(e); const r = new T.Mesh(new T.TorusGeometry(.095, .008, 8, 48), glow); r.rotation.y = Math.PI / 2; r.position.x = x + Math.sign(x) * .058; head.add(r); };
    ear(-.52); ear(.52);
    const pill = (w, h) => { const s = new T.Shape(); const r = Math.min(w, h) / 2; s.moveTo(-w / 2 + r, -h / 2); s.lineTo(w / 2 - r, -h / 2); s.absarc(w / 2 - r, -h / 2 + r, r, -Math.PI / 2, 0); s.lineTo(w / 2, h / 2 - r); s.absarc(w / 2 - r, h / 2 - r, r, 0, Math.PI / 2); s.lineTo(-w / 2 + r, h / 2); s.absarc(-w / 2 + r, h / 2 - r, r, Math.PI / 2, Math.PI); s.lineTo(-w / 2, -h / 2 + r); s.absarc(-w / 2 + r, -h / 2 + r, r, Math.PI, Math.PI * 1.5); return s; };
    const sparkM = new T.MeshBasicMaterial({ color: 0xffffff, toneMapped: false });
    const eyeGeo = new T.ShapeGeometry(pill(.12, .13), 16);
    const eyeL = new T.Mesh(eyeGeo, glow); eyeL.position.set(-.135, 0, .548); eyeL.rotation.y = -.3; head.add(eyeL);
    const eyeR = new T.Mesh(eyeGeo, glow); eyeR.position.set(.135, 0, .548); eyeR.rotation.y = .3; head.add(eyeR);
    for (const e of [eyeL, eyeR]) { const a = new T.Mesh(new T.CircleGeometry(.017, 16), sparkM); a.position.set(-.024, .03, .002); e.add(a); const b = new T.Mesh(new T.CircleGeometry(.008, 12), sparkM); b.position.set(.022, -.026, .002); e.add(b); }
    const mouthG = new T.Group(); mouthG.position.set(0, -.112, .538); mouthG.rotation.x = .3; head.add(mouthG);
    const SA = Math.PI * .72; const smile = new T.Mesh(new T.TorusGeometry(.075, .011, 8, 40, SA), glow); smile.rotation.z = -Math.PI / 2 - SA / 2; smile.position.y = .045; mouthG.add(smile);
    const mouthOpen = new T.Mesh(new T.CircleGeometry(.062, 32, Math.PI, Math.PI), glow); mouthOpen.scale.set(1, .1, 1); mouthOpen.visible = false; mouthG.add(mouthOpen);
    const cheekM = new T.MeshBasicMaterial({ color: 0xff8fa8, transparent: true, opacity: .32, depthWrite: false });
    for (const x of [-.25, .25]) { const c = new T.Mesh(new T.CircleGeometry(.04, 24), cheekM); c.position.set(x, -.085, .488); c.rotation.y = x * 1.25; c.rotation.x = .18; head.add(c); }
    const ant = new T.Mesh(new T.CylinderGeometry(.008, .012, .12, 12), graph); ant.position.set(.18, .5, -.05); ant.rotation.z = -.35; head.add(ant);
    const tip = new T.Mesh(new T.SphereGeometry(.022, 16, 12), glow); tip.position.set(.205, .565, -.05); head.add(tip);
    function arm(side) {
      const s = new T.Group(); s.position.set(.58 * side, .2, 0); rig.add(s);
      s.add(new T.Mesh(new T.SphereGeometry(.152, 36, 26), graph));
      const sr = new T.Mesh(new T.TorusGeometry(.13, .009, 8, 48), glow); sr.rotation.y = Math.PI / 2; sr.position.x = .075 * side; s.add(sr);
      const up = new T.Mesh(new T.CapsuleGeometry(.132, .09, 10, 32), shell); up.position.y = -.19; s.add(up);
      const el = new T.Group(); el.position.y = -.38; s.add(el);
      el.add(new T.Mesh(new T.SphereGeometry(.118, 30, 22), graph));
      const j = new T.Mesh(new T.TorusGeometry(.12, .009, 8, 44), glow); j.rotation.x = Math.PI / 2; el.add(j);
      const fo = new T.Mesh(new T.CapsuleGeometry(.122, .07, 10, 32), shell); fo.position.y = -.15; fo.scale.set(1, 1, .94); el.add(fo);
      const cuff = new T.Mesh(new T.CylinderGeometry(.1, .108, .065, 36), graph); cuff.position.y = -.28; el.add(cuff);
      const hand = new T.Group(); hand.position.y = -.37; el.add(hand);
      const palm = new T.Mesh(new T.SphereGeometry(.125, 30, 22), shell); palm.scale.set(1.02, .92, .84); hand.add(palm);
      const thumb = new T.Mesh(new T.CapsuleGeometry(.042, .05, 6, 16), shell); thumb.position.set(-.1 * side, .015, .04); thumb.rotation.z = .75 * side; hand.add(thumb);
      return { s, el, side };
    }
    parts = { glow, glowCol, eyeL, eyeR, smile, mouthOpen, AL: arm(-1), AR: arm(1), blinkAt: 2, blinkT: 0, energy: 0, waveUntil: 0 };
    RB.scale.setScalar(1.0);
  }

  function pose(A, x, z, ex, k, dt) { A.s.rotation.x = ease(A.s.rotation.x, x, k, dt); A.s.rotation.z = ease(A.s.rotation.z, z * A.side, k, dt); A.el.rotation.x = ease(A.el.rotation.x, ex, k, dt); }

  function state() {
    const st = (document.getElementById('hStage') || {}).dataset?.state || 'idle';
    const mic = document.getElementById('hMic');
    return { st, listening: !!mic && mic.getAttribute('aria-pressed') === 'true' };
  }

  function frame(now) {
    raf = 0; if (!visible) return;
    raf = requestAnimationFrame(frame);
    const t = now / 1000, dt = Math.min(.05, last ? (now - last) / 1000 : .016); last = now;
    const { st: s0, listening } = state();
    const st = listening ? 'waiting' : s0;
    const P = parts, talking = st === 'speaking';
    look.x = ease(look.x, look.tx, .05, dt); look.y = ease(look.y, look.ty, .05, dt);
    RB.position.y = Math.sin(t * 1.15) * .06;
    RB.rotation.y = ease(RB.rotation.y, look.x * .35, .05, dt);
    head.rotation.y = ease(head.rotation.y, look.x * .7, .06, dt);
    P.energy = ease(P.energy, talking ? .4 + .6 * Math.abs(Math.sin(t * 9.3) * Math.sin(t * 3.7 + 1)) : 0, .3, dt);
    head.rotation.x = ease(head.rotation.x, -look.y * .6 + (st === 'waiting' ? .07 : 0) + (talking ? Math.sin(t * 5.7) * .06 * (.4 + P.energy) : 0), .08, dt);
    head.rotation.z = ease(head.rotation.z, st === 'waiting' ? .09 : st === 'thinking' ? -.06 : 0, .04, dt);
    head.position.y = 1.0 + P.energy * .03 * Math.sin(t * 11);
    const open = talking ? Math.min(1, .15 + P.energy * 1.1) : 0;
    P.mouthOpen.scale.y = ease(P.mouthOpen.scale.y, Math.max(.1, open), .5, dt);
    P.mouthOpen.visible = P.mouthOpen.scale.y > .16; P.smile.visible = !P.mouthOpen.visible;
    if (t > P.blinkAt) { P.blinkT = .13; P.blinkAt = t + 2.2 + Math.random() * 4.5; } P.blinkT = Math.max(0, P.blinkT - dt);
    const ey = P.blinkT > 0 ? .08 : st === 'waiting' ? 1.06 : talking ? .88 + Math.sin(t * 2.1) * .04 : .96;
    for (const [e, x] of [[P.eyeL, -.135], [P.eyeR, .135]]) { e.scale.y = ease(e.scale.y, ey, .35, dt); e.position.x = x + look.x * .03; }
    const base = st === 'waiting' ? new T.Color(.45, 1.9, 1.35) : st === 'thinking' ? new T.Color(1.0, .85, 2.4) : P.glowCol;
    const pulse = st === 'thinking' ? .75 + .25 * Math.sin(t * 6) : st === 'waiting' ? .85 + .15 * Math.sin(t * 4) : 1 + P.energy * .6;
    P.glow.color.lerp(base.clone().multiplyScalar(pulse), 1 - Math.pow(.001, dt));
    const k = .09;
    if (performance.now() < P.waveUntil) { pose(P.AL, .08, .18, -.2, k, dt); pose(P.AR, -.25, 1.75, -.9 + Math.sin(t * 6.4) * .25, .12, dt); }
    else if (talking) { pose(P.AL, -.35 + Math.sin(t * 1.7 + 1) * .16, .24, -.65 + Math.sin(t * 2.6) * .22, .07, dt); pose(P.AR, -.8 + Math.sin(t * 2.2) * .28, .32, -1.05 + Math.sin(t * 3.1) * .32, .07, dt); }
    else if (st === 'thinking') { pose(P.AL, .05, .16, -.2, k, dt); pose(P.AR, -1.25, .42, -1.6, .06, dt); }
    else if (st === 'waiting') { pose(P.AL, -.2, .3, -.5, k, dt); pose(P.AR, -.2, .3, -.5, k, dt); }
    else { const sw = Math.sin(t * 1.35) * .04; pose(P.AL, .06 + sw, .17, -.2, k, dt); pose(P.AR, .06 - sw, .17, -.2, k, dt); }
    renderer.render(scene, camera);
  }

  function size() {
    if (!host || !renderer) return;
    const r = host.getBoundingClientRect(); if (!r.width || !r.height) return;
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setSize(r.width, r.height, false);
    camera.aspect = r.width / r.height; camera.updateProjectionMatrix();
  }

  window.__mollyHoloBot = {
    async mount(el) {
      host = el;
      try {
        T = await needThree();
        try { build(); } catch (e) { console.warn('Holo robot not available', e); return false; }
        el.appendChild(renderer.domElement);
        new ResizeObserver(size).observe(el); size();
        window.addEventListener('pointermove', e => { look.tx = Math.max(-1, Math.min(1, (e.clientX / innerWidth - .5) * 1.6)); look.ty = Math.max(-1, Math.min(1, (e.clientY / innerHeight - .45) * 1.4)); });
        if (visible && !raf) raf = requestAnimationFrame(frame);
        return true;
      } catch (e) { console.warn('Holo robot', e); return false; }
    },
    show(on) { visible = !!on; if (visible && renderer && !raf) { last = 0; size(); raf = requestAnimationFrame(frame); } },
    wave() { if (parts) parts.waveUntil = performance.now() + 2200; },
  };
})();

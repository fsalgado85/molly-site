// Minimal ZIP writer and reader (stored or deflated entries), no dependencies.
// Writer output is deterministic: entries sorted, fixed timestamps, so the same files give the same sha256.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
export function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

const DOS_TIME = 0;            // 00:00:00
const DOS_DATE = (1 << 5) | 1; // 1980-01-01

/** entries: [{ name: 'src/a.mjs', data: Buffer|string }] → Buffer */
export function createZip(entries) {
  const files = [...entries].map(e => ({ name: String(e.name).replace(/\\/g, '/'), data: Buffer.isBuffer(e.data) ? e.data : Buffer.from(String(e.data)) }))
    .sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
  const seen = new Set();
  const locals = [], centrals = [];
  let offset = 0;
  for (const f of files) {
    checkName(f.name);
    if (seen.has(f.name)) throw new Error('Duplicate zip entry ' + f.name);
    seen.add(f.name);
    const name = Buffer.from(f.name, 'utf8');
    const crc = crc32(f.data);
    const deflated = zlib.deflateRawSync(f.data, { level: 9 });
    const useDeflate = deflated.length < f.data.length;
    const body = useDeflate ? deflated : f.data;
    const method = useDeflate ? 8 : 0;
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(DOS_TIME, 10); lh.writeUInt16LE(DOS_DATE, 12); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(f.data.length, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    locals.push(lh, name, body);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(0x031e, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(DOS_TIME, 12); ch.writeUInt16LE(DOS_DATE, 14); ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(f.data.length, 24); ch.writeUInt16LE(name.length, 28);
    ch.writeUInt16LE(0, 30); ch.writeUInt16LE(0, 32); ch.writeUInt16LE(0, 34); ch.writeUInt16LE(0, 36);
    ch.writeUInt32LE((0o100644 << 16) >>> 0, 38); ch.writeUInt32LE(offset, 42);
    centrals.push(ch, name);
    offset += lh.length + name.length + body.length;
  }
  const cd = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, end]);
}

// Entry names must be plain relative paths: no absolute paths, no "..", no backslashes, no drive letters.
export function checkName(name) {
  const n = String(name);
  if (!n || n.length > 400 || n.includes('\\') || n.includes('\0') || n.startsWith('/') || /^[a-zA-Z]:/.test(n) || n.split('/').some(p => p === '..' || p === '.'))
    throw new Error('Unsafe path in zip: ' + JSON.stringify(n));
  return n;
}

/** Buffer → [{ name, data }] (directories skipped). Checks CRCs and sizes. */
export function readZip(buf, { maxTotal = 300e6, maxEntries = 5000 } = {}) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Not a zip file');
  const count = buf.readUInt16LE(eocd + 10);
  if (count > maxEntries) throw new Error('Too many files in zip');
  let p = buf.readUInt32LE(eocd + 16);
  const out = []; let total = 0;
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Damaged zip (central directory)');
    const method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), lho = buf.readUInt32LE(p + 42);
    const name = buf.subarray(p + 46, p + 46 + nlen).toString('utf8');
    p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    checkName(name);
    if (buf.readUInt32LE(lho) !== 0x04034b50) throw new Error('Damaged zip (local header)');
    const start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.subarray(start, start + csize);
    total += usize; if (total > maxTotal) throw new Error('Zip is too large');
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) data = zlib.inflateRawSync(raw, { maxOutputLength: Math.max(usize, 1) });
    else throw new Error('Unsupported zip compression in ' + name);
    if (data.length !== usize || crc32(data) !== crc) throw new Error('Damaged file in zip: ' + name);
    out.push({ name, data });
  }
  return out;
}

/** Extract into destDir (must not exist yet or be empty). Refuses anything that would land outside it. */
export function extractZip(buf, destDir, { refuse = [] } = {}) {
  const entries = readZip(buf);
  const root = path.resolve(destDir);
  fs.mkdirSync(root, { recursive: true });
  for (const e of entries) {
    if (refuse.some(r => (r instanceof RegExp ? r.test(e.name) : r === e.name))) throw new Error('Refused file in zip: ' + e.name);
    const target = path.resolve(root, e.name);
    if (!target.startsWith(root + path.sep)) throw new Error('Unsafe path in zip: ' + e.name);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, e.data);
  }
  return entries.map(e => e.name);
}

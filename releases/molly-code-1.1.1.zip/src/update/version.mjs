// Version numbers like 1.2.3 (optionally 1.2.3-beta.1). Used by the updater and the shell's bootstrap.

const RE = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/;

export function isVersion(v) { return typeof v === 'string' && RE.test(v.trim()); }

export function parseVersion(v) {
  const m = RE.exec(String(v || '').trim());
  if (!m) return null;
  return { major: +m[1], minor: +m[2], patch: +m[3], pre: m[4] ? m[4].split('.') : [] };
}

/** -1 if a < b, 0 if equal, 1 if a > b. Invalid versions sort below every valid one. */
export function compareVersions(a, b) {
  const x = parseVersion(a), y = parseVersion(b);
  if (!x && !y) return 0;
  if (!x) return -1;
  if (!y) return 1;
  for (const k of ['major', 'minor', 'patch']) if (x[k] !== y[k]) return x[k] < y[k] ? -1 : 1;
  // a release (no pre-release tag) is newer than any pre-release of the same number
  if (!x.pre.length || !y.pre.length) return x.pre.length === y.pre.length ? 0 : x.pre.length ? -1 : 1;
  for (let i = 0; i < Math.max(x.pre.length, y.pre.length); i++) {
    const p = x.pre[i], q = y.pre[i];
    if (p === undefined) return -1;
    if (q === undefined) return 1;
    const pn = /^\d+$/.test(p), qn = /^\d+$/.test(q);
    if (pn && qn) { if (+p !== +q) return +p < +q ? -1 : 1; }
    else if (pn !== qn) return pn ? -1 : 1;
    else if (p !== q) return p < q ? -1 : 1;
  }
  return 0;
}

export const isNewer = (a, b) => compareVersions(a, b) > 0;

/** Bump "patch" | "minor" | "major" (drops any pre-release tag). */
export function bumpVersion(v, part = 'patch') {
  const p = parseVersion(v);
  if (!p) throw new Error(`Not a version: ${v}`);
  if (part === 'major') return `${p.major + 1}.0.0`;
  if (part === 'minor') return `${p.major}.${p.minor + 1}.0`;
  if (part === 'patch') return p.pre.length ? `${p.major}.${p.minor}.${p.patch}` : `${p.major}.${p.minor}.${p.patch + 1}`;
  if (isVersion(part)) return part;
  throw new Error(`Unknown bump "${part}" (use patch, minor, major or an exact version)`);
}

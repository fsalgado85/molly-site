// Molly's self-updater (code side). Checks the release feed, downloads a newer code zip, checks its
// sha256, extracts it into <data>/code/<version> and marks it verified. The shell's bootstrap loads
// it on the next start. No Electron here, so it can be tested with plain Node.
//
// Feed (latest.json): { version, minShell, url, sha256, notes, reinstallUrl? }
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { EventEmitter } from 'node:events';
import { compareVersions, isVersion } from './version.mjs';
import { extractZip } from './zip.mjs';

export const FEED_URL = 'https://fsalgado85.github.io/molly-site/releases/latest.json';
export const SITE_URL = 'https://fsalgado85.github.io/molly-site/';
export const VERIFIED_FILE = '.molly-verified.json'; // same name as in src/shell/boot-core.mjs
export const MAX_ZIP_BYTES = 80 * 1024 * 1024;
export const DAY_MS = 24 * 60 * 60 * 1000;

export const sha256 = buf => crypto.createHash('sha256').update(buf).digest('hex');

export class UpdateError extends Error { constructor(code, message) { super(message); this.code = code; } }

/** Validate latest.json. Throws UpdateError('bad_feed'). Resolves a relative url against the feed. */
export function parseFeed(j, feedUrl = FEED_URL) {
  if (!j || typeof j !== 'object') throw new UpdateError('bad_feed', 'The update information is not valid.');
  const { version, minShell = '0.0.0', url, sha256: sum, notes = '', reinstallUrl } = j;
  if (!isVersion(version)) throw new UpdateError('bad_feed', 'The update has no valid version number.');
  if (!isVersion(minShell)) throw new UpdateError('bad_feed', 'The update has no valid minShell.');
  if (!/^[a-f0-9]{64}$/i.test(String(sum || ''))) throw new UpdateError('bad_feed', 'The update has no valid sha256.');
  let full;
  try { full = new URL(String(url || ''), feedUrl); } catch { throw new UpdateError('bad_feed', 'The update has no valid download link.'); }
  const local = full.protocol === 'http:' && /^(127\.0\.0\.1|localhost)$/.test(full.hostname);
  if (full.protocol !== 'https:' && !local) throw new UpdateError('bad_feed', 'Updates are only downloaded over https.');
  return { version, minShell, url: full.href, sha256: String(sum).toLowerCase(), notes: String(notes || '').slice(0, 2000), reinstallUrl: reinstallUrl || SITE_URL };
}

/**
 * What to do with a feed, given what we run and what's on disk.
 * → 'up-to-date' | 'skipped-bad' | 'reinstall-needed' | 'ready' (already downloaded) | 'download'
 */
export function planUpdate(feed, { currentVersion, shellVersion, codeRoot, badVersions = [] }) {
  if (compareVersions(feed.version, currentVersion) <= 0) return 'up-to-date';
  if (badVersions.includes(feed.version)) return 'skipped-bad';
  if (compareVersions(feed.minShell, shellVersion) > 0) return 'reinstall-needed';
  if (isVerifiedDir(path.join(codeRoot, feed.version), feed)) return 'ready';
  return 'download';
}

export function isVerifiedDir(dir, feed) {
  try {
    const v = JSON.parse(fs.readFileSync(path.join(dir, VERIFIED_FILE), 'utf8'));
    const m = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
    return v.sha256 === feed.sha256 && m.version === feed.version;
  } catch { return false; }
}

/**
 * Check a downloaded zip and install it: sha256 must match, the manifest inside must match the feed,
 * nothing may escape the folder. Installs atomically (temp folder, then rename).
 */
export function installZip(buf, feed, { codeRoot }) {
  const got = sha256(buf);
  if (got !== feed.sha256) throw new UpdateError('sha256_mismatch', `The download did not pass its safety check (sha256 ${got.slice(0, 12)}… instead of ${feed.sha256.slice(0, 12)}…). Nothing was installed.`);
  fs.mkdirSync(codeRoot, { recursive: true });
  const tmp = path.join(codeRoot, `.incoming-${feed.version}-${crypto.randomBytes(4).toString('hex')}`);
  const dest = path.join(codeRoot, feed.version);
  try {
    extractZip(buf, tmp, { refuse: [VERIFIED_FILE, /(^|\/)node_modules\//, /(^|\/)config\//, /google-(client|token)\.json$/] });
    let m;
    try { m = JSON.parse(fs.readFileSync(path.join(tmp, 'manifest.json'), 'utf8')); } catch { throw new UpdateError('bad_zip', 'The update has no manifest.json.'); }
    if (m.version !== feed.version) throw new UpdateError('bad_zip', `The update says it is ${m.version}, expected ${feed.version}.`);
    if ((m.minShell || '0.0.0') !== feed.minShell) throw new UpdateError('bad_zip', 'The update\'s minShell does not match the release information.');
    if (!fs.existsSync(path.join(tmp, m.main || 'src/main/main.mjs'))) throw new UpdateError('bad_zip', 'The update is missing its main file.');
    fs.writeFileSync(path.join(tmp, VERIFIED_FILE), JSON.stringify({ sha256: feed.sha256, version: feed.version, verifiedAt: new Date().toISOString(), from: feed.url }, null, 2));
    if (fs.existsSync(dest)) fs.rmSync(dest, { recursive: true, force: true }); // a half-installed copy without a valid record
    fs.renameSync(tmp, dest);
    return dest;
  } catch (e) {
    fs.rmSync(tmp, { recursive: true, force: true });
    if (e instanceof UpdateError) throw e;
    throw new UpdateError('bad_zip', 'The update could not be unpacked: ' + e.message);
  }
}

export class Updater extends EventEmitter {
  /**
   * opts: { currentVersion, shellVersion, codeRoot, feedUrl?, fetchImpl?, badVersions?: () => [], log?, stateFile? }
   */
  constructor(opts) {
    super();
    this.o = { feedUrl: FEED_URL, fetchImpl: globalThis.fetch, badVersions: () => [], log: () => {}, ...opts };
    this.status = { state: 'idle', currentVersion: opts.currentVersion, shellVersion: opts.shellVersion };
    this.checking = null;
    this.timer = null;
  }

  set(patch) { this.status = { ...this.status, ...patch, at: new Date().toISOString() }; this.emit('status', this.status); return this.status; }

  lastCheck() { try { return JSON.parse(fs.readFileSync(this.o.stateFile, 'utf8')).lastCheck || 0; } catch { return 0; } }
  saveLastCheck() { if (!this.o.stateFile) return; try { fs.writeFileSync(this.o.stateFile, JSON.stringify({ lastCheck: Date.now() })); } catch {} }

  /** Check now (one at a time). Resolves the new status. Never throws. */
  check({ manual = false } = {}) {
    if (this.checking) return this.checking;
    this.checking = this._check(manual).finally(() => { this.checking = null; });
    return this.checking;
  }

  async _check(manual) {
    const { fetchImpl, feedUrl, codeRoot, currentVersion, shellVersion, log } = this.o;
    const keep = this.status.state === 'ready' ? { ...this.status } : null;
    this.set({ state: 'checking', manual });
    try {
      const r = await fetchImpl(feedUrl + (feedUrl.includes('?') ? '&' : '?') + 't=' + Date.now(), { headers: { 'cache-control': 'no-cache' } });
      if (!r.ok) throw new UpdateError('feed_unavailable', `The update information could not be fetched (HTTP ${r.status}).`);
      const feed = parseFeed(await r.json(), feedUrl);
      this.saveLastCheck();
      const plan = planUpdate(feed, { currentVersion, shellVersion, codeRoot, badVersions: this.o.badVersions() });
      log(`update check: feed ${feed.version} (minShell ${feed.minShell}), running ${currentVersion} on shell ${shellVersion} → ${plan}`);
      if (plan === 'up-to-date') return this.set({ state: keep ? 'ready' : 'up-to-date', ...(keep ? { version: keep.version, notes: keep.notes } : { version: feed.version }), manual });
      if (plan === 'skipped-bad') return this.set({ state: 'up-to-date', version: currentVersion, manual, note: `${feed.version} did not start properly on this Mac and was skipped.` });
      if (plan === 'reinstall-needed') return this.set({ state: 'reinstall-needed', version: feed.version, notes: feed.notes, minShell: feed.minShell, reinstallUrl: feed.reinstallUrl, manual });
      if (plan === 'ready') return this.set({ state: 'ready', version: feed.version, notes: feed.notes, manual });
      this.set({ state: 'downloading', version: feed.version, manual });
      const z = await fetchImpl(feed.url);
      if (!z.ok) throw new UpdateError('download_failed', `The update could not be downloaded (HTTP ${z.status}).`);
      const len = Number(z.headers?.get?.('content-length') || 0);
      if (len > MAX_ZIP_BYTES) throw new UpdateError('too_large', 'The update is unexpectedly large; not downloaded.');
      const buf = Buffer.from(await z.arrayBuffer());
      if (buf.length > MAX_ZIP_BYTES) throw new UpdateError('too_large', 'The update is unexpectedly large; not installed.');
      const dir = installZip(buf, feed, { codeRoot });
      log(`update ${feed.version} downloaded, verified and unpacked into ${dir}`);
      return this.set({ state: 'ready', version: feed.version, notes: feed.notes, manual });
    } catch (e) {
      log(`update check failed: ${e.code || ''} ${e.message}`);
      if (keep) return this.set({ ...keep, manual });
      return this.set({ state: 'error', code: e.code || 'error', message: e.message, manual });
    }
  }

  /** Check shortly after start, then every 24 h (also catches up after the Mac was asleep). */
  start({ firstDelayMs = 20000, intervalMs = DAY_MS } = {}) {
    this.stop();
    this.first = setTimeout(() => this.check(), firstDelayMs);
    this.timer = setInterval(() => { if (Date.now() - this.lastCheck() >= intervalMs - 60000) this.check(); }, Math.min(intervalMs, 60 * 60 * 1000));
    this.first.unref?.(); this.timer.unref?.();
  }
  stop() { clearTimeout(this.first); clearInterval(this.timer); }
}

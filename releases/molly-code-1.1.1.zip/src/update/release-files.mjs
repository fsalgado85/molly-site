// What goes into a code update zip, and what must never go in.
// A code zip holds ONLY app code: src/ (minus the shell), artifact/, a trimmed package.json,
// manifest.json and the few images the app shows. Never settings, keys, tokens, user data,
// node_modules, native binaries or voice models.
import fs from 'node:fs';
import path from 'node:path';

export const INCLUDE_DIRS = ['src', 'artifact'];
export const INCLUDE_FILES = ['build/icon.png', 'build/trayTemplate.png', 'build/trayTemplate@2x.png'];

// Anything matching one of these is left out, and a zip containing one is rejected.
export const FORBIDDEN = [
  { re: /(^|\/)config\//, why: 'config folder' },
  { re: /google-client\.json$/i, why: 'Google key file' },
  { re: /google-token\.json$/i, why: 'Google token' },
  { re: /(^|\/)[^/]*token[^/]*\.json$/i, why: 'token file' },
  { re: /(^|\/)settings\.json$/i, why: 'settings (personal profile)' },
  { re: /(^|\/)(db|import|import-done[^/]*|assets-user|logs|run|tmp|models|code)\//, why: 'user data folder' },
  { re: /(^|\/)node_modules\//, why: 'node_modules' },
  { re: /\.(node|dylib|so|dll|exe)$/i, why: 'native binary' },
  { re: /\.(onnx|ort|bin|tar\.bz2)$/i, why: 'voice model' },
  { re: /(^|\/)\.env/, why: 'environment file' },
  { re: /\.(log|dmg|zip)$/i, why: 'log or archive' },
  { re: /(^|\/)\.DS_Store$/, why: 'Finder file' },
  { re: /(^|\/)\.molly-verified\.json$/, why: 'verification record' },
];
// The shell (bootstrap) lives in the app bundle and is never updated by a zip.
export const SHELL_ONLY = [/^src\/shell\//];

// Personal details are checked too: release.mjs passes the owner's markers (name, town, email, phone),
// read at build time from the original page, so they are never written into shipped code.

export function forbiddenReason(name) {
  const hit = FORBIDDEN.find(f => f.re.test(name));
  return hit ? hit.why : null;
}

function walk(dir, rel = '') {
  const out = [];
  for (const ent of fs.readdirSync(path.join(dir, rel), { withFileTypes: true })) {
    const r = rel ? `${rel}/${ent.name}` : ent.name;
    if (ent.isSymbolicLink()) continue;
    if (ent.isDirectory()) out.push(...walk(dir, r));
    else if (ent.isFile()) out.push(r);
  }
  return out;
}

/** List the files of appDir that belong in a code zip → { files: [rel], excluded: [{name, why}] } */
export function collectReleaseFiles(appDir) {
  const files = [], excluded = [];
  for (const d of INCLUDE_DIRS) {
    if (!fs.existsSync(path.join(appDir, d))) continue;
    for (const f of walk(appDir, d)) {
      const why = forbiddenReason(f) || (SHELL_ONLY.some(r => r.test(f)) ? 'shell (stays in the app)' : null);
      if (why) excluded.push({ name: f, why }); else files.push(f);
    }
  }
  for (const f of INCLUDE_FILES) if (fs.existsSync(path.join(appDir, f))) files.push(f);
  return { files: files.sort(), excluded };
}

/** The trimmed package.json that ships in a zip (no build config, no dependency lists). */
export function codePackageJson(pkg) {
  return { name: pkg.name, productName: pkg.productName, version: pkg.version, type: pkg.type, main: 'src/main/main.mjs', molly: pkg.molly || {} };
}

/** Throws if a list of zip entries contains anything forbidden or personal (markers: case-insensitive words). */
export function assertCleanEntries(entries, { personal = [] } = {}) {
  const markers = personal.map(m => String(m).toLowerCase()).filter(m => m.length >= 4);
  const bad = [];
  for (const e of entries) {
    const why = forbiddenReason(e.name) || (SHELL_ONLY.some(r => r.test(e.name)) ? 'shell file' : null);
    if (why) bad.push(`${e.name} (${why})`);
    if (e.data && /\.(html|js|mjs|cjs|json|md|css|txt)$/i.test(e.name)) {
      // the public site's own address (it contains the GitHub user name) is fine
      const t = e.data.toString('utf8').toLowerCase().split('.github.io/molly-site').map(x => x.replace(/[a-z0-9-]+$/, '')).join('');
      const hit = markers.find(m => t.includes(m));
      if (hit) bad.push(`${e.name} (contains a personal detail)`);
    }
  }
  if (!entries.some(e => e.name === 'manifest.json')) bad.push('manifest.json missing');
  if (bad.length) throw new Error('The release zip contains files it must not:\n  ' + bad.join('\n  '));
  return true;
}

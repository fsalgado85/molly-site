// Running the official Claude Code CLI on the person's own Claude plan.
// Rules (PLAN.md §1.4): never use an API key, never `--bare`, always strip key variables.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn, execFileSync, execFile } from 'node:child_process';
import { promisify } from 'node:util';
const execFileP = promisify(execFile);
import { richPath } from './paths.mjs';

export const BANNED_ENV = ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'CLAUDE_CODE_USE_BEDROCK', 'CLAUDE_CODE_USE_VERTEX', 'ELECTRON_RUN_AS_NODE', 'ELECTRON_NO_ATTACH_CONSOLE', 'NODE_OPTIONS'];

// If Molly was itself started from inside a Claude Code session, don't let its children join that session.
export const SESSION_ENV = ['CLAUDECODE', 'CLAUDE_CODE_SESSION_ID', 'CLAUDE_CODE_CHILD_SESSION', 'CLAUDE_CODE_REMOTE_SESSION_ID', 'CLAUDE_CODE_ENTRYPOINT', 'CLAUDE_PID', 'CLAUDE_CODE_SESSION_ATTENDED'];

export function claudeEnv(extra = {}) {
  const env = { ...process.env, PATH: richPath(), ...extra };
  for (const k of [...BANNED_ENV, ...SESSION_ENV]) delete env[k];
  return env;
}

export function findClaude() {
  const home = os.homedir();
  const cands = [process.env.MOLLY_CLAUDE, path.join(home, '.local/bin/claude'), path.join(home, '.claude/local/claude'), '/opt/homebrew/bin/claude', '/usr/local/bin/claude'].filter(Boolean);
  for (const c of cands) { try { if (fs.statSync(c).isFile() || fs.lstatSync(c).isSymbolicLink()) return c; } catch {} }
  try { return execFileSync('/bin/sh', ['-c', 'command -v claude'], { encoding: 'utf8', env: claudeEnv() }).trim() || null; } catch { return null; }
}

// Guard: refuse to build a command line that would bypass subscription login.
export function assertSafeArgs(args) {
  if (args.includes('--bare')) throw new Error('Molly never uses claude --bare');
  if (args.some(a => /api[-_]?key/i.test(a) && a.startsWith('--'))) throw new Error('Molly never uses an API key');
  return args;
}

/**
 * Run `claude -p` and stream its events.
 * onEvent receives: {type:'init', sessionId} | {type:'text', text, delta} (text = whole current message so far)
 *                   | {type:'tool', name} | {type:'result', text, isError, sessionId}
 */
export function runClaude({ args, cwd, env = {}, onEvent = () => {}, signal, claudePath } = {}) {
  return new Promise(resolve => {
    const bin = claudePath || findClaude();
    if (!bin) return resolve({ ok: false, code: -1, error: 'not_installed', message: 'Claude Code is not installed on this Mac yet.' });
    assertSafeArgs(args);
    const child = spawn(bin, args, { cwd, env: claudeEnv(env), stdio: ['ignore', 'pipe', 'pipe'] });
    let buf = '', msgText = '', allText = '', stderr = '', result = null, sessionId = null, done = false;
    const onAbort = () => { try { child.kill('SIGINT'); } catch {} setTimeout(() => { try { child.kill('SIGKILL'); } catch {} }, 4000).unref?.(); };
    if (signal) { if (signal.aborted) onAbort(); else signal.addEventListener('abort', onAbort, { once: true }); }
    child.stdout.on('data', chunk => {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1);
        if (!line.trim()) continue;
        let ev; try { ev = JSON.parse(line); } catch { continue; }
        if (ev.type === 'system' && ev.subtype === 'init') { sessionId = ev.session_id || sessionId; onEvent({ type: 'init', sessionId }); }
        else if (ev.type === 'stream_event') {
          const e = ev.event || {};
          if (e.type === 'message_start') msgText = '';
          else if (e.type === 'content_block_start' && e.content_block?.type === 'text' && msgText && !msgText.endsWith('\n')) msgText += '\n\n';
          else if (e.type === 'content_block_delta' && e.delta?.type === 'text_delta') {
            msgText += e.delta.text; allText += e.delta.text;
            onEvent({ type: 'text', text: msgText, delta: e.delta.text });
          } else if (e.type === 'content_block_start' && e.content_block?.type === 'tool_use') onEvent({ type: 'tool', name: e.content_block.name });
        } else if (ev.type === 'assistant' && ev.message && !allText) {
          // no partial messages (older CLI): use whole assistant messages
          const t = (ev.message.content || []).filter(c => c.type === 'text').map(c => c.text).join('');
          if (t) { msgText = t; onEvent({ type: 'text', text: t, delta: t }); }
        } else if (ev.type === 'result') {
          sessionId = ev.session_id || sessionId;
          result = { text: typeof ev.result === 'string' ? ev.result : msgText, isError: !!ev.is_error, subtype: ev.subtype, usage: ev.usage };
          onEvent({ type: 'result', ...result, sessionId });
        }
      }
    });
    child.stderr.on('data', c => { stderr += c; if (stderr.length > 20000) stderr = stderr.slice(-20000); });
    child.on('error', e => { stderr += '\nCould not start Claude Code: ' + e.message; });
    child.on('close', code => {
      if (done) return; done = true;
      signal?.removeEventListener?.('abort', onAbort);
      const text = result?.text ?? msgText;
      const aborted = !!signal?.aborted;
      let error = null, message = null;
      if (aborted) { error = 'aborted'; message = 'Stopped.'; }
      else if (result?.isError || (code !== 0 && !text)) {
        const all = (result?.text || '') + '\n' + stderr;
        if (/not logged in|log ?in|authenticat|\/login|invalid api key|oauth/i.test(all)) { error = 'not_signed_in'; message = 'Claude Code is not signed in. Open Molly\'s menu → Set up again… to sign in with your Claude account.'; }
        else if (/usage limit|rate limit|limit reached|429/i.test(all)) { error = 'rate_limited'; message = 'Your Claude plan\'s usage limit has been reached for now. Try again later.'; }
        else if (/unknown option|unrecognized|error: option/i.test(all)) { error = 'bad_option'; message = stderr.trim().split('\n').slice(-2).join(' '); }
        else { error = 'claude_error'; message = (result?.text || stderr.trim().split('\n').slice(-3).join(' ') || `Claude exited with code ${code}`).slice(0, 500); }
      }
      resolve({ ok: !error, code, text, sessionId, error, message, stderr });
    });
  });
}

// Small helpers for the setup wizard.
export function claudeVersion() {
  const bin = findClaude(); if (!bin) return null;
  try { return execFileSync(bin, ['--version'], { encoding: 'utf8', env: claudeEnv(), timeout: 15000 }).trim(); } catch { return null; }
}

export function parseAuthStatus(text) {
  let j = null;
  try { j = JSON.parse(text); } catch {
    const m = String(text).match(/\{[\s\S]*\}/); if (m) { try { j = JSON.parse(m[0]); } catch {} }
  }
  if (!j) return { loggedIn: /logged in|signed in/i.test(text) && !/not (logged|signed) in/i.test(text), raw: String(text).slice(0, 300) };
  const loggedIn = !!(j.loggedIn ?? j.logged_in ?? j.authenticated ?? j.isLoggedIn ?? (j.status === 'logged_in'));
  const method = j.authMethod || j.auth_method || j.method || j.apiProvider || '';
  return { loggedIn, method: String(method), email: j.email || j.account?.email || null, subscription: j.subscriptionType || j.subscription || j.plan || null, raw: j };
}

let versionCache = null;
export async function claudeVersionAsync() {
  const bin = findClaude(); if (!bin) return null;
  if (versionCache?.bin === bin) return versionCache.v;
  try { const { stdout } = await execFileP(bin, ['--version'], { env: claudeEnv(), timeout: 15000 }); versionCache = { bin, v: stdout.trim() }; return versionCache.v; } catch { return null; }
}
export async function authStatusAsync() {
  const bin = findClaude(); if (!bin) return { installed: false, loggedIn: false };
  try { const { stdout } = await execFileP(bin, ['auth', 'status', '--json'], { env: claudeEnv(), timeout: 20000 }); return { installed: true, ...parseAuthStatus(stdout) }; }
  catch (e) { return { installed: true, ...parseAuthStatus(String(e.stdout || '') + String(e.stderr || '')) }; }
}

export function authStatus() {
  const bin = findClaude(); if (!bin) return { installed: false, loggedIn: false };
  try {
    const out = execFileSync(bin, ['auth', 'status', '--json'], { encoding: 'utf8', env: claudeEnv(), timeout: 20000 });
    return { installed: true, ...parseAuthStatus(out) };
  } catch (e) {
    const out = String(e.stdout || '') + String(e.stderr || '');
    return { installed: true, ...parseAuthStatus(out) };
  }
}

// A tiny Firestore-like database stored as plain JSON files:
//   <data>/db/<collection>/<docId>.json            (top-level documents)
//   <data>/db/<collection>/<docId>/<sub>/<id>.json (sub-collections, if ever used)
// Plain files so background tasks (Claude Code) can read and edit them with normal file tools.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { EventEmitter } from 'node:events';

export const DELETE = '__delete__';
const isPlain = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const isDeleteSentinel = v => isPlain(v) && v[DELETE] === true && Object.keys(v).length === 1;

export class DbError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

function encSeg(s) {
  s = String(s);
  if (!s || s === '.' || s === '..') throw new DbError('invalid-argument', 'Bad path segment: ' + JSON.stringify(s));
  // keep names readable; escape only what is unsafe in file names
  return s.replace(/[%/\\:\0]/g, c => '%' + c.charCodeAt(0).toString(16).padStart(2, '0')).replace(/^\./, '%2e');
}
function decSeg(s) { return s.replace(/%([0-9a-f]{2})/gi, (_, h) => String.fromCharCode(parseInt(h, 16))); }

export function splitPath(p) {
  const segs = String(p || '').split('/').filter(Boolean);
  if (!segs.length) throw new DbError('invalid-argument', 'Empty path');
  return segs;
}

// strip delete sentinels from a value being written fresh
function clean(v) {
  if (Array.isArray(v)) return v.map(clean);
  if (!isPlain(v)) return v;
  const out = {};
  for (const [k, x] of Object.entries(v)) if (!isDeleteSentinel(x)) out[k] = clean(x);
  return out;
}
function deepMerge(base, patch) {
  const out = isPlain(base) ? { ...base } : {};
  for (const [k, v] of Object.entries(patch || {})) {
    if (isDeleteSentinel(v)) delete out[k];
    else if (isPlain(v) && isPlain(out[k])) out[k] = deepMerge(out[k], v);
    else out[k] = clean(v);
  }
  return out;
}
function shallowMerge(base, patch) {
  const out = isPlain(base) ? { ...base } : {};
  for (const [k, v] of Object.entries(patch || {})) {
    if (isDeleteSentinel(v)) delete out[k]; else out[k] = clean(v);
  }
  return out;
}

export function newId() {
  const abc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const b = crypto.randomBytes(20);
  let s = ''; for (const x of b) s += abc[x % abc.length];
  return s;
}

function cmp(a, b) {
  if (a === b) return 0;
  if (a === undefined || a === null) return -1;
  if (b === undefined || b === null) return 1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b));
}

export class Db extends EventEmitter {
  constructor(root) {
    super();
    this.root = root;
    fs.mkdirSync(root, { recursive: true });
    this.recent = new Map(); // file -> time of our own write (to ignore our own fs.watch echoes)
    this.setMaxListeners(0);
  }

  docFile(p) {
    const segs = splitPath(p);
    if (segs.length % 2) throw new DbError('invalid-argument', 'A document path needs an even number of segments: ' + p);
    return path.join(this.root, ...segs.map(encSeg)) + '.json';
  }
  colDir(p) {
    const segs = splitPath(p);
    if (!(segs.length % 2)) throw new DbError('invalid-argument', 'A collection path needs an odd number of segments: ' + p);
    return path.join(this.root, ...segs.map(encSeg));
  }

  readFile(file) {
    try {
      const v = JSON.parse(fs.readFileSync(file, 'utf8'));
      return isPlain(v) ? v : { value: v };
    } catch (e) {
      if (e.code === 'ENOENT') return undefined;
      // half-written or hand-edited badly: treat as missing rather than crash the page
      return undefined;
    }
  }

  writeFile(file, data) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = file + '.' + process.pid + '.' + crypto.randomBytes(4).toString('hex') + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
    fs.renameSync(tmp, file);
    this.recent.set(file, Date.now());
  }

  changed(p) {
    const segs = splitPath(p);
    this.emit('change', { path: segs.join('/'), collection: segs.slice(0, -1).join('/'), id: segs[segs.length - 1] });
  }

  get(p) {
    const data = this.readFile(this.docFile(p));
    const segs = splitPath(p);
    return { id: segs[segs.length - 1], path: segs.join('/'), exists: data !== undefined, data: data ?? null };
  }

  set(p, data, opts = {}) {
    if (!isPlain(data)) throw new DbError('invalid-argument', 'Document data must be an object');
    const file = this.docFile(p);
    const next = opts.merge ? deepMerge(this.readFile(file) || {}, data) : clean(data);
    this.writeFile(file, next);
    this.changed(p);
    return next;
  }

  // Firestore-style update: top-level fields are replaced, others kept. Creates the document if missing
  // (more forgiving than Firestore; background tasks sometimes "update or create").
  update(p, data) {
    if (!isPlain(data)) throw new DbError('invalid-argument', 'Update data must be an object');
    const file = this.docFile(p);
    const next = shallowMerge(this.readFile(file) || {}, data);
    this.writeFile(file, next);
    this.changed(p);
    return next;
  }

  delete(p) {
    const file = this.docFile(p);
    try { fs.unlinkSync(file); this.recent.set(file, Date.now()); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    this.changed(p);
  }

  add(colPath, data) {
    const id = newId();
    const p = splitPath(colPath).concat(id).join('/');
    this.set(p, data);
    return id;
  }

  list(colPath, { orderBy, dir = 'asc', limit } = {}) {
    const d = this.colDir(colPath);
    let names = [];
    try { names = fs.readdirSync(d).filter(n => n.endsWith('.json') && !n.startsWith('.')); } catch { return []; }
    let docs = [];
    for (const n of names) {
      const data = this.readFile(path.join(d, n));
      if (data !== undefined) docs.push({ id: decSeg(n.slice(0, -5)), data });
    }
    if (orderBy) {
      docs.sort((a, b) => cmp(a.data[orderBy], b.data[orderBy]) || cmp(a.id, b.id));
      if (String(dir).toLowerCase() === 'desc') docs.reverse();
    } else docs.sort((a, b) => cmp(a.id, b.id));
    if (limit > 0) docs = docs.slice(0, limit);
    return docs;
  }

  // Watch the folder so edits made by background tasks (plain file writes) refresh the page live.
  watch() {
    if (this.watcher) return;
    const pending = new Map();
    const fire = rel => {
      const segs = rel.split(path.sep).filter(Boolean);
      if (!segs.length || !segs[segs.length - 1].endsWith('.json') || segs[segs.length - 1].endsWith('.tmp')) return;
      segs[segs.length - 1] = segs[segs.length - 1].slice(0, -5);
      if (segs.length % 2) return;
      const file = path.join(this.root, rel);
      const mine = this.recent.get(file);
      if (mine && Date.now() - mine < 1500) return;
      this.changed(segs.map(decSeg).join('/'));
    };
    try {
      this.watcher = fs.watch(this.root, { recursive: true }, (_ev, rel) => {
        if (!rel) return;
        rel = String(rel);
        clearTimeout(pending.get(rel));
        pending.set(rel, setTimeout(() => { pending.delete(rel); fire(rel); }, 150));
      });
      this.watcher.on('error', () => {});
    } catch { /* recursive watch unsupported: the page still updates for its own writes */ }
    // tidy the "recent" map now and then
    this.tidy = setInterval(() => { const t = Date.now(); for (const [k, v] of this.recent) if (t - v > 5000) this.recent.delete(k); }, 10000);
    this.tidy.unref?.();
  }

  close() { try { this.watcher?.close(); } catch {} clearInterval(this.tidy); this.watcher = null; }

  // Import an ArtifactData export: files shaped {id, data, version} (or plain data), one folder per collection.
  importExport(dir) {
    let count = 0;
    const walk = (d, segs) => {
      for (const n of fs.readdirSync(d, { withFileTypes: true })) {
        if (n.name.startsWith('.')) continue;
        const full = path.join(d, n.name);
        if (n.isDirectory()) walk(full, segs.concat(n.name));
        else if (n.name.endsWith('.json') && segs.length % 2 === 1) {
          let v; try { v = JSON.parse(fs.readFileSync(full, 'utf8')); } catch { continue; }
          const id = (v && typeof v.id === 'string' && v.id) || n.name.slice(0, -5);
          const data = v && isPlain(v.data) && ('version' in v || 'id' in v) ? v.data : v;
          if (!isPlain(data)) continue;
          this.set(segs.concat(id).join('/'), data);
          count++;
        }
      }
    };
    walk(dir, []);
    return count;
  }
}

// Molly's chat "brain": the page's conversation runs through the official `claude` CLI on the
// person's own plan, as a real agent session:
//   • Claude Code's own system prompt is kept and Molly's persona is APPENDED (not replaced);
//   • one session per day (or until "New conversation"), resumed with --resume so context is kept;
//   • real abilities: Gmail/Calendar (read), Molly's database (read) and notes memory, OneDrive files
//     (read), web search and fetch, and the page's own tools for anything that changes things
//     (those show a Confirm card in the page first).
// Never an API key, never --bare (see claude.mjs).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { promptVars, fillTemplate, completeProfile } from './personalise.mjs';

export const CHAT_BUILTINS = ['Read', 'Glob', 'Grep', 'WebSearch', 'WebFetch'];
export const CHAT_DENIED = ['Bash', 'Edit', 'Write', 'MultiEdit', 'NotebookEdit', 'Task', 'Agent', 'TodoWrite', 'KillShell', 'BashOutput', 'SlashCommand', 'Skill'];
export const PERSONA_FILE = new URL('../brain/persona.md', import.meta.url);

/** The page's chat call is the only sample() with conversation turns AND page tools (artifact send()). */
export function isChatRequest(body = {}) {
  return Array.isArray(body.turns) && body.turns.length > 0 && Array.isArray(body.tools) && body.tools.length > 0 && !body.json;
}

const textOf = c => typeof c === 'string' ? c : Array.isArray(c) ? c.map(x => typeof x === 'string' ? x : x?.text || '').join('\n') : String(c ?? '');

/**
 * The page puts its live context (calendar, matters, renewals…) in front of the first user turn:
 *   "<context>\n\n---\n<Name>: <message>". Split it from the newest user message.
 */
export function splitTurns(turns) {
  const list = (turns || []).filter(t => t && t.content != null);
  const first = textOf(list[0]?.content);
  const cut = first.lastIndexOf('\n\n---\n');
  const context = cut >= 0 ? first.slice(0, cut) : '';
  const last = list[list.length - 1] || { content: '' };
  let message = list.length === 1 ? (cut >= 0 ? first.slice(cut + 6) : first) : textOf(last.content);
  return { context, message, count: list.length };
}

/** A fingerprint of the page context that ignores the clock line, so "same context" is recognised. */
export function contextHash(ctx) {
  const norm = String(ctx || '').replace(/It is [^\n]*?\d{1,2}:\d{2}[^\n.]*\.?/g, '').replace(/\s+/g, ' ').trim();
  return crypto.createHash('sha1').update(norm).digest('hex').slice(0, 16);
}

// Opus when the person asks for Molly's best or for deep work; Sonnet otherwise.
const DEEP = /\b(use (your|the) best|your best (answer|work|brain|model)|best (model|brain)|deep[- ]?(work|dive|think(ing)?|research|analysis)|think (hard|deeply|carefully)|in[- ]depth|thorough(ly)?|(use )?opus)\b/i;
export function chooseChatModel(message, tier) {
  if (tier === 'best' || DEEP.test(String(message || ''))) return 'opus';
  return 'sonnet';
}

export function localDay(tz, d = new Date()) {
  try { return new Intl.DateTimeFormat('en-CA', { timeZone: tz || undefined, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d); } catch { return d.toISOString().slice(0, 10); }
}

// ---------------------------------------------------------------- persona
const clip = (s, n) => { s = String(s ?? '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

export function memoryLines(db, max = 40) {
  let docs = [];
  try { docs = db.list('memory', { orderBy: 'at', dir: 'desc', limit: 200 }); } catch {}
  return docs.filter(d => d.data && d.data.text && !d.data.forgotten).slice(0, max)
    .map(d => `- ${clip(d.data.text, 240)}${d.data.kind && d.data.kind !== 'fact' ? ` (${d.data.kind})` : ''} [${d.id}]`);
}

export function openMatterLines(db, max = 25) {
  let docs = [];
  try { docs = db.list('matters'); } catch {}
  const open = docs.map(d => ({ id: d.id, ...(d.data || {}) })).filter(m => m.title && m.status !== 'closed' && !m.closedAt);
  open.sort((a, b) => String(a.due || '9999').localeCompare(String(b.due || '9999')));
  const lines = open.slice(0, max).map(m => `- ${clip(m.title, 80)} — ${m.status === 'you' ? 'their move' : m.status === 'them' ? 'waiting on them' : m.status || 'open'}${m.next ? `; next: ${clip(m.next, 90)}` : ''}${m.due ? `; due ${String(m.due).slice(0, 10)}` : ''}`);
  if (open.length > max) lines.push(`- …and ${open.length - max} more (use the database tools to see them)`);
  return lines;
}

export function preferenceLines(db) {
  const out = [];
  const get = p => { try { return db.get(p).data || null; } catch { return null; } };
  const prefs = get('meta/preferences');
  if (prefs) for (const [k, v] of Object.entries(prefs)) if (v != null && typeof v !== 'object') out.push(`- ${k}: ${clip(v, 200)}`); else if (Array.isArray(v)) out.push(`- ${k}: ${clip(v.join('; '), 300)}`);
  const voice = get('meta/voice');
  if (voice?.guide) out.push(`- How they write emails (use this for drafts): ${clip(voice.guide, 1200)}`);
  const cfg = get('meta/config');
  if (cfg?.style) out.push(`- Style notes: ${clip(cfg.style, 300)}`);
  return out;
}

export function buildPersona({ profile = {}, db, now = new Date(), oneDrive = '' } = {}) {
  const p = completeProfile(profile);
  const vars = promptVars(p, { NOW: now.toLocaleString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: p.timeZone || undefined }) });
  let text = fillTemplate(fs.readFileSync(PERSONA_FILE, 'utf8'), vars);
  const about = [
    p.fullName && `- Name: ${p.fullName}${p.pronouns ? ` (pronouns: ${p.pronouns})` : ''}`,
    p.email && `- Email: ${p.email}`,
    (p.area || p.town) && `- Lives in: ${[p.area || p.town, p.postcode].filter(Boolean).join(' ')}`,
    p.household && `- Household: ${p.household}`,
    p.about && `- About: ${clip(p.about, 400)}`,
    `- Time zone: ${p.timeZone || 'Europe/London'}`,
    oneDrive ? `- OneDrive folder on this Mac (read-only for you): ${oneDrive}` : '- No OneDrive folder is set up.',
  ].filter(Boolean);
  const mem = db ? memoryLines(db) : [];
  const prefs = db ? preferenceLines(db) : [];
  const matters = db ? openMatterLines(db) : [];
  text += `\n\n# About ${p.firstName}\n${about.join('\n')}`;
  text += `\n\n# Preferences\n${prefs.length ? prefs.join('\n') : '- (none saved yet)'}`;
  text += `\n\n# Notes you have saved (memory)\n${mem.length ? mem.join('\n') : '- (nothing saved yet)'}`;
  text += `\n\n# Open matters (summary; the page's message has the full detail)\n${matters.length ? matters.join('\n') : '- (none open)'}`;
  return text;
}

// ---------------------------------------------------------------- session store
export class ChatSessions {
  constructor(file) { this.file = file; }
  get() { try { return JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { return null; } }
  set(s) { try { fs.mkdirSync(path.dirname(this.file), { recursive: true }); fs.writeFileSync(this.file, JSON.stringify(s, null, 2)); } catch {} return s; }
  clear() { try { fs.rmSync(this.file, { force: true }); } catch {} }
}

/**
 * Decide how to send this chat turn: resume today's session or start a new one, and what prompt to send.
 * → { resume: sessionId|null, prompt, reason, ctxHash }
 */
export function planChatTurn({ turns, stored, day, now = Date.now(), turnsToPrompt, refreshMinutes = 60 }) {
  const { context, message, count } = splitTurns(turns);
  const hash = contextHash(context);
  const canResume = stored && stored.sessionId && stored.day === day && count > 1;
  if (!canResume) {
    const reason = !stored?.sessionId ? 'first conversation' : stored.day !== day ? 'new day' : count <= 1 ? 'new conversation' : 'new session';
    return { resume: null, prompt: turnsToPrompt(turns), reason, ctxHash: hash, ctxAt: now };
  }
  const stale = !stored.ctxAt || now - stored.ctxAt > refreshMinutes * 60000;
  const changed = context && (hash !== stored.ctxHash || stale);
  const prompt = (changed ? `Molly's page has updated its live information (this replaces the earlier version):\n<page_context>\n${context}\n</page_context>\n\n---\n` : '') + message;
  return { resume: stored.sessionId, prompt, reason: changed ? 'resume with fresh context' : 'resume', ctxHash: changed ? hash : stored.ctxHash, ctxAt: changed ? now : stored.ctxAt };
}

/** The `claude -p` arguments for a chat turn. */
export function chatArgs({ prompt, personaFile, mcpFile, model, pageTools = [], resume, readDirs = [], denyDirs = [] }) {
  const allowed = [
    'WebSearch', 'WebFetch', 'mcp__google', 'mcp__molly',
    ...pageTools.map(t => 'mcp__page__' + t),
    ...readDirs.map(d => `Read(/${path.resolve(d)}/**)`),
  ];
  const denied = [...CHAT_DENIED, ...denyDirs.map(d => `Read(/${path.resolve(d)}/**)`)];
  const args = ['-p', prompt, '--output-format', 'stream-json', '--verbose', '--include-partial-messages',
    '--append-system-prompt-file', personaFile,
    '--mcp-config', mcpFile, '--strict-mcp-config',
    '--permission-mode', 'dontAsk',
    '--model', model,
    '--tools', CHAT_BUILTINS.join(','),
    '--allowedTools', allowed.join(','),
    '--disallowedTools', denied.join(',')];
  for (const d of readDirs) args.push('--add-dir', d);
  if (resume) args.push('--resume', resume);
  return args;
}

/** Folders the chat must never read (Molly's data folder holds the Google token; Claude's own files; keys). */
export function sensitiveDirs(paths, home = os.homedir()) {
  return [paths.dataDir, path.join(home, '.claude'), path.join(home, '.ssh'), path.join(home, '.config'), path.join(home, 'Library', 'Keychains'), path.join(home, 'Library', 'Application Support', 'Google')];
}

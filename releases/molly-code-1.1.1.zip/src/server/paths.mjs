// Where Molly keeps things.
//   App folder (inside Molly.app, or an update in <data>/code/<version>; no personal data): code, templates, artifact.
//   Data folder (personal, never shared): ~/Library/Application Support/Molly  (override with MOLLY_DATA)
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

export const appDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
// The app bundle itself (the "shell": Electron, voice engine, bundled Google key). When an updated copy
// of the code runs from <data>/code/<version>, appDir is that folder and shellDir is still Molly.app.
export const shellDir = process.env.MOLLY_SHELL_DIR ? path.resolve(process.env.MOLLY_SHELL_DIR) : appDir;

export function makePaths(dataDir = process.env.MOLLY_DATA || path.join(os.homedir(), 'Library', 'Application Support', 'Molly')) {
  dataDir = path.resolve(dataDir);
  const p = {
    appDir,
    shellDir,
    dataDir,
    code: path.join(dataDir, 'code'),
    db: path.join(dataDir, 'db'),
    assets: path.join(dataDir, 'assets'),
    logs: path.join(dataDir, 'logs'),
    models: path.join(dataDir, 'models'),
    tmp: path.join(dataDir, 'tmp'),
    run: path.join(dataDir, 'run'),
    importDir: path.join(dataDir, 'import'),
    settings: path.join(dataDir, 'settings.json'),
    googleToken: path.join(dataDir, 'google-token.json'),
    // google-client.json: the user's own copy wins, otherwise one bundled into the app by build.sh
    googleClientUser: path.join(dataDir, 'google-client.json'),
    googleClientBundled: path.join(shellDir, 'config', 'google-client.json'),
    serverInfo: path.join(dataDir, 'run', 'server.json'),
    taskState: path.join(dataDir, 'run', 'tasks.json'),
    artifact: path.join(appDir, 'artifact', 'molly.html'),
  };
  for (const d of [p.db, p.assets, p.logs, p.models, p.tmp, p.run]) fs.mkdirSync(d, { recursive: true });
  return p;
}

export function oneDriveDirs(home = os.homedir()) {
  const cs = path.join(home, 'Library', 'CloudStorage');
  try { return fs.readdirSync(cs).filter(n => /^OneDrive/i.test(n)).map(n => path.join(cs, n)); } catch { return []; }
}

// A PATH that finds Claude Code and the usual tools even when the app is started from Finder.
export function richPath(home = os.homedir()) {
  const extra = [path.join(home, '.local', 'bin'), path.join(home, '.claude', 'local'), '/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin', '/usr/sbin', '/sbin'];
  const cur = (process.env.PATH || '').split(':').filter(Boolean);
  return [...new Set([...extra, ...cur])].join(':');
}

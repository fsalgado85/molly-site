// Gmail and Google Calendar tools in the claude.ai connector shapes (see PLAN.md §3).
// Used by the page (through /api/mcp/call), by the agent and by background tasks (through google-mcp).
import fs from 'node:fs';
import path from 'node:path';
import { McpError, mapMessage, buildRfc822, hdr, pmap, localDate, addDays, attachmentsOf } from './google.mjs';

const G = 'https://gmail.googleapis.com/gmail/v1/users/me';
const CAL = 'https://www.googleapis.com/calendar/v3';
const META = ['From', 'To', 'Cc', 'Subject', 'Date', 'Message-ID'].map(h => 'metadataHeaders=' + h).join('&');

// Which tools change things (blocked for background tasks, which only read).
export const WRITE_TOOLS = new Set(['label_thread', 'unlabel_thread', 'trash_thread', 'untrash_thread', 'create_draft', 'reply', 'send_message', 'create_event']);
export const SEND_TOOLS = new Set(['reply', 'send_message']);

export function createTools(google, { allowedSaveRoots = () => [] } = {}) {
  const api = google.api;
  const me = () => google.email();

  async function getThread(threadId, format = 'MINIMAL') {
    const f = format === 'MINIMAL' ? `format=metadata&${META}` : 'format=full';
    const t = await api(`${G}/threads/${encodeURIComponent(threadId)}?${f}`);
    return { id: t.id, messages: (t.messages || []).map(m => mapMessage(m, { email: me(), format })) };
  }

  const gmail = {
    async search_threads({ query = '', pageSize = 10, pageToken, view } = {}) {
      const n = Math.max(1, Math.min(+pageSize || 10, 50));
      const q = new URLSearchParams({ q: query, maxResults: String(n) });
      if (pageToken) q.set('pageToken', pageToken);
      const list = await api(`${G}/threads?${q}`);
      const threads = await pmap(list.threads || [], 5, async t => {
        try {
          const full = await api(`${G}/threads/${t.id}?format=metadata&${META}`);
          const messages = (full.messages || []).map(m => mapMessage(m, { email: me() }));
          return { id: t.id, messageCount: messages.length, messages };
        } catch (e) { return { id: t.id, messageCount: 0, messages: [], snippet: t.snippet || '' }; }
      });
      const out = { threads, resultCountEstimate: list.resultSizeEstimate ?? threads.length };
      if (list.nextPageToken) out.nextPageToken = list.nextPageToken;
      if (view === 'THREAD_VIEW_METADATA_ONLY') for (const t of threads) for (const m of t.messages) delete m.snippet_html;
      return out;
    },
    async get_thread({ threadId, messageFormat = 'MINIMAL' } = {}) {
      if (!threadId) throw new McpError('invalid_arguments', 'threadId is required');
      return getThread(threadId, messageFormat);
    },
    async get_message({ messageId, messageFormat = 'PLAIN_TEXT' } = {}) {
      if (!messageId) throw new McpError('invalid_arguments', 'messageId is required');
      if (messageFormat === 'RAW') {
        const m = await api(`${G}/messages/${encodeURIComponent(messageId)}?format=raw`);
        return { id: m.id, threadId: m.threadId, raw: m.raw };
      }
      const f = messageFormat === 'MINIMAL' ? `format=metadata&${META}` : 'format=full';
      const m = await api(`${G}/messages/${encodeURIComponent(messageId)}?${f}`);
      return mapMessage(m, { email: me(), format: messageFormat });
    },
    async label_thread({ threadId, labelIds = [] } = {}) {
      await api(`${G}/threads/${encodeURIComponent(threadId)}/modify`, { method: 'POST', body: JSON.stringify({ addLabelIds: labelIds }) }); return {};
    },
    async unlabel_thread({ threadId, labelIds = [] } = {}) {
      await api(`${G}/threads/${encodeURIComponent(threadId)}/modify`, { method: 'POST', body: JSON.stringify({ removeLabelIds: labelIds }) }); return {};
    },
    async trash_thread({ threadId } = {}) { await api(`${G}/threads/${encodeURIComponent(threadId)}/trash`, { method: 'POST' }); return {}; },
    async untrash_thread({ threadId } = {}) { await api(`${G}/threads/${encodeURIComponent(threadId)}/untrash`, { method: 'POST' }); return {}; },
    async list_labels() { const r = await api(`${G}/labels`); return { labels: (r.labels || []).map(l => ({ id: l.id, name: l.name, type: l.type })) }; },
    async create_draft({ to = [], cc = [], subject = '', body = '', replyToMessageId } = {}) {
      const ctx = replyToMessageId ? await replyContext(replyToMessageId) : {};
      const raw = buildRfc822({ to, cc, subject: subject || ctx.subject || '', body, inReplyTo: ctx.inReplyTo, references: ctx.references });
      const d = await api(`${G}/drafts`, { method: 'POST', body: JSON.stringify({ message: { raw, ...(ctx.threadId ? { threadId: ctx.threadId } : {}) } }) });
      return { id: d.id, messageId: d.message?.id, threadId: d.message?.threadId, viewUrl: `https://mail.google.com/mail/?authuser=${encodeURIComponent(me() || '')}#drafts?compose=${d.message?.id || ''}` };
    },
    async reply({ messageId, to = [], cc = [], body = '' } = {}) {
      if (!messageId) throw new McpError('invalid_arguments', 'messageId is required');
      const ctx = await replyContext(messageId);
      const raw = buildRfc822({ to: to.length ? to : [ctx.replyTo], cc, subject: ctx.subject, body, inReplyTo: ctx.inReplyTo, references: ctx.references });
      const r = await api(`${G}/messages/send`, { method: 'POST', body: JSON.stringify({ raw, threadId: ctx.threadId }) });
      return { id: r.id, threadId: r.threadId };
    },
    async send_message({ to = [], cc = [], subject = '', body = '' } = {}) {
      const raw = buildRfc822({ to, cc, subject, body });
      const r = await api(`${G}/messages/send`, { method: 'POST', body: JSON.stringify({ raw }) });
      return { id: r.id, threadId: r.threadId };
    },
    // Background-task helper (not a claude.ai connector tool): save one attachment to a local folder, never overwriting.
    async save_attachment({ messageId, filename, destPath } = {}) {
      if (!messageId || !filename || !destPath) throw new McpError('invalid_arguments', 'messageId, filename and destPath are required');
      const dest = path.resolve(String(destPath));
      const roots = allowedSaveRoots().map(r => path.resolve(r));
      if (!roots.some(r => dest === r || dest.startsWith(r + path.sep))) throw new McpError('not_allowed', 'destPath must be inside your OneDrive folder.');
      const m = await api(`${G}/messages/${encodeURIComponent(messageId)}?format=full`);
      const nf = s => String(s || '').normalize('NFC').trim().toLowerCase();
      const att = attachmentsOf(m.payload).find(a => nf(a.filename) === nf(filename));
      if (!att) throw new McpError('not_found', `No attachment called "${filename}" in that email.`);
      let data;
      if (att.id) data = (await api(`${G}/messages/${encodeURIComponent(messageId)}/attachments/${encodeURIComponent(att.id)}`)).data;
      else throw new McpError('not_found', 'That attachment has no downloadable data.');
      const bytes = Buffer.from(String(data).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      const final = uniquePath(dest);
      fs.writeFileSync(final, bytes, { flag: 'wx' });
      return { savedPath: final, bytes: bytes.length };
    },
  };

  async function replyContext(messageId) {
    const o = await api(`${G}/messages/${encodeURIComponent(messageId)}?format=metadata&metadataHeaders=Message-ID&metadataHeaders=References&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Reply-To`);
    const s = hdr(o, 'Subject'); const inReplyTo = hdr(o, 'Message-ID');
    return { threadId: o.threadId, inReplyTo, references: (hdr(o, 'References') + ' ' + inReplyTo).trim(), subject: /^re:/i.test(s) ? s : 'Re: ' + s, replyTo: hdr(o, 'Reply-To') || hdr(o, 'From') };
  }

  const calendar = {
    async list_calendars() {
      const r = await api(`${CAL}/users/me/calendarList?maxResults=250`);
      return { calendars: (r.items || []).map(c => ({ id: c.id, summary: c.summaryOverride || c.summary, backgroundColor: c.backgroundColor, primary: !!c.primary, accessRole: c.accessRole, timeZone: c.timeZone })) };
    },
    async list_events({ startTime, endTime, orderBy = 'startTime', pageSize = 50, timeZone, calendarId = 'primary', query } = {}) {
      const q = new URLSearchParams({ singleEvents: 'true', maxResults: String(Math.min(+pageSize || 50, 2500)) });
      if (orderBy === 'startTime' || orderBy === 'updated') q.set('orderBy', orderBy);
      if (startTime) q.set('timeMin', new Date(startTime).toISOString());
      if (endTime) q.set('timeMax', new Date(endTime).toISOString());
      if (timeZone) q.set('timeZone', timeZone);
      if (query) q.set('q', query);
      const r = await api(`${CAL}/calendars/${encodeURIComponent(calendarId)}/events?${q}`);
      return { events: r.items || [], timeZone: r.timeZone };
    },
    async get_event({ eventId, calendarId = 'primary' } = {}) {
      return api(`${CAL}/calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(eventId)}`);
    },
    async create_event({ summary, startTime, endTime, timeZone = 'Europe/London', allDay, description, location, overrideReminders, calendarId = 'primary', attendees } = {}) {
      if (!summary || !startTime) throw new McpError('invalid_arguments', 'summary and startTime are required');
      const ev = { summary };
      if (description) ev.description = description;
      if (location) ev.location = location;
      if (allDay) {
        const s = /^\d{4}-\d{2}-\d{2}$/.test(startTime) ? startTime : localDate(startTime, timeZone);
        let e = endTime ? (/^\d{4}-\d{2}-\d{2}$/.test(endTime) ? endTime : localDate(endTime, timeZone)) : s;
        if (e <= s) e = addDays(s, 1);
        ev.start = { date: s }; ev.end = { date: e };
      } else {
        ev.start = { dateTime: startTime, timeZone };
        ev.end = { dateTime: endTime || new Date(new Date(startTime).getTime() + 30 * 60000).toISOString(), timeZone };
      }
      if (Array.isArray(overrideReminders) && overrideReminders.length) ev.reminders = { useDefault: false, overrides: overrideReminders };
      if (Array.isArray(attendees) && attendees.length) ev.attendees = attendees.map(a => typeof a === 'string' ? { email: a } : a);
      return api(`${CAL}/calendars/${encodeURIComponent(calendarId)}/events`, { method: 'POST', body: JSON.stringify(ev) });
    },
  };

  return { Gmail: gmail, 'Google Calendar': calendar };
}

export function uniquePath(p) {
  if (!fs.existsSync(p)) return p;
  const ext = path.extname(p), base = p.slice(0, p.length - ext.length);
  for (let i = 2; i < 1000; i++) { const c = `${base} (${i})${ext}`; if (!fs.existsSync(c)) return c; }
  throw new Error('Too many files with that name');
}

// Map server names as the page calls them (and a few aliases).
export function serverKey(name) {
  const n = String(name || '').toLowerCase().replace(/[\s_-]+/g, '');
  if (n === 'gmail') return 'Gmail';
  if (n === 'googlecalendar' || n === 'calendar' || n === 'gcal') return 'Google Calendar';
  if (n === 'claudecoderemote') return 'Claude Code Remote';
  return name;
}

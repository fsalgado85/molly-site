// Local background tasks: replacements for the cloud "scheduled tasks" (PLAN.md §5).
// Each run is `claude -p` on the person's own plan with: preamble + the task's prompt + the run's extra text.
import fs from 'node:fs';
import path from 'node:path';
import { runClaude } from './claude.mjs';
import { promptVars, fillTemplate } from './personalise.mjs';
import { Scheduler } from './cron.mjs';

// trigger = the cloud task id the page still uses in fire_trigger(); cron in the person's time zone.
export const TASKS = [
  { id: 'email-checks', name: 'Email checks', trigger: 'trig_01NKU5W2JKV2QQfqTJ7v7MwD', cron: '55 6,12,17 * * *', model: 'sonnet', prompt: 'email-checks.md' },
  { id: 'evening', name: 'Evening wrap-up', trigger: 'trig_01Scm2cTmTH7bDo4Jx8CS5ao', cron: '25 20 * * *', model: 'haiku', prompt: 'evening.md' },
  { id: 'newspaper', name: 'Newspaper', trigger: 'trig_01QPJ9SouRnohqiwo4AjTMPH', cron: '37 6 * * *', model: 'sonnet', prompt: 'newspaper.md' },
  { id: 'markets', name: 'Markets', trigger: 'trig_01YM1pBSM7FS64Be5RnS87iv', cron: '40 7-21/2 * * 1-5', model: 'haiku', prompt: 'markets.md', catchUpMin: 90 },
  { id: 'onedrive-index', name: 'OneDrive index', trigger: 'trig_01CcWEpXww8uas3Gb1JyRXZ7', cron: '47 5 * * *', model: 'sonnet', prompt: 'onedrive-index.md', needsOneDrive: true },
  { id: 'watch-prices', name: 'Watchlist prices', trigger: 'trig_01Bp2jy3F9aVcrTfZVMVSmZy', cron: '27 6 * * *', model: 'sonnet', prompt: 'watch-prices.md' },
  { id: 'watch-research', name: 'Watchlist research', trigger: 'trig_018c4K2ajkPYdz2Ubiytm5ss', cron: '12 6 * * 1', model: 'sonnet', prompt: 'watch-research.md' },
  { id: 'renewals', name: 'Renewal check', trigger: 'trig_01AT7BiMk6obSXY9YAGdLBmU', cron: '23 7 * * 1', model: 'sonnet', prompt: 'renewals.md' },
  { id: 'research', name: 'Web research', trigger: 'trig_012BahuHoQQ1dgksHFhZ7uTY', cron: null, model: 'sonnet', prompt: 'research.md' },
  { id: 'filing', name: 'File attachment to OneDrive', trigger: 'trig_01QnqergRYpQ3UJzX7mTpqKd', cron: null, model: 'sonnet', prompt: 'filing.md', needsOneDrive: true },
  // Opening a OneDrive file needs no AI on the Mac itself: handled natively.
  { id: 'open-file', name: 'Open a OneDrive file', trigger: 'trig_01LSdML9n6iEUbwQG2okXiRF', cron: null, native: true },
];

export const byTrigger = t => TASKS.find(x => x.trigger === t || x.id === t);

const TOOLS = ['Read', 'Write', 'Edit', 'Glob', 'Grep', 'Bash', 'WebSearch', 'WebFetch', 'mcp__google', 'mcp__molly'];
const NO_TOOLS = ['Bash(rm:*)', 'Bash(rmdir:*)', 'Bash(mv:*)', 'Bash(sudo:*)', 'Bash(curl:*)', 'Bash(osascript:*)', 'Task', 'Agent', 'NotebookEdit'];

export function nowLine(tz) {
  return new Date().toLocaleString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: tz || undefined });
}

export function buildTaskPrompt(task, { appDir, dbDir, profile, text, tz }) {
  const dir = path.join(appDir, 'src', 'tasks', 'prompts');
  const vars = promptVars(profile, { NOW: nowLine(tz), DB_DIR: dbDir, TASK_NAME: task.name });
  const pre = fillTemplate(fs.readFileSync(path.join(dir, 'preamble.md'), 'utf8'), vars);
  const body = fillTemplate(fs.readFileSync(path.join(dir, task.prompt), 'utf8'), vars);
  const extra = text && String(text).trim() ? `\n\n---\nThe run's extra message (on-demand request from the page):\n${String(text).trim()}` : '\n\n---\nThis is a scheduled run: there is no extra message.';
  return pre + '\n' + body + extra;
}

export class TaskRunner {
  constructor({ paths, db, profile, settings, serverUrl, mcpToken, nodeBin, nodeEnv = {}, notify = () => {}, openPath = async () => '', log = () => {}, claudePath }) {
    Object.assign(this, { paths, db, profile, settings, serverUrl, mcpToken, nodeBin, nodeEnv, notify, openPath, log, claudePath });
    this.running = new Map(); // id -> { started, controller }
    this.queue = [];
    this.logFile = path.join(paths.logs, 'tasks.log');
  }

  writeLog(line) {
    const l = `[${new Date().toISOString()}] ${line}\n`;
    try { fs.appendFileSync(this.logFile, l); } catch {}
    this.log(l.trim());
  }

  state() {
    let s = {}; try { s = JSON.parse(fs.readFileSync(this.paths.taskState, 'utf8')); } catch {}
    return s;
  }
  saveState(patch) {
    const s = { ...this.state(), ...patch };
    try { fs.writeFileSync(this.paths.taskState, JSON.stringify(s, null, 2)); } catch {}
    return s;
  }

  mcpConfigFile(taskId) {
    const f = path.join(this.paths.run, `mcp-task-${taskId}.json`);
    const env = { ...this.nodeEnv, MOLLY_URL: this.serverUrl, MOLLY_TOKEN: this.mcpToken, MOLLY_TASK_ID: taskId };
    const srv = n => ({ type: 'stdio', command: this.nodeBin, args: [path.join(this.paths.appDir, 'src', 'mcp', n)], env });
    fs.writeFileSync(f, JSON.stringify({ mcpServers: { google: { ...srv('google-mcp.mjs'), env: { ...env, MOLLY_MCP_MODE: 'task' } }, molly: srv('molly-mcp.mjs') } }, null, 2));
    return f;
  }

  /** Fire a task (from cron or from the page). Returns immediately. */
  fire(idOrTrigger, text = '', { source = 'page' } = {}) {
    const task = byTrigger(idOrTrigger);
    if (!task) { this.writeLog(`unknown task ${idOrTrigger}`); return { ok: false, error: 'unknown_task' }; }
    if (task.native) { this.runNative(task, text).catch(e => this.writeLog(`${task.id} failed: ${e.message}`)); return { ok: true, task: task.id }; }
    if (this.running.has(task.id)) {
      // one run at a time per task; queue on-demand requests that carry their own payload
      if (text) this.queue.push({ id: task.id, text, source });
      this.writeLog(`${task.id} already running (${text ? 'queued' : 'skipped'})`);
      return { ok: true, task: task.id, queued: !!text };
    }
    this.run(task, text, source).catch(e => this.writeLog(`${task.id} crashed: ${e.stack || e}`));
    return { ok: true, task: task.id };
  }

  async run(task, text, source) {
    const controller = new AbortController();
    this.running.set(task.id, { started: Date.now(), controller });
    const tz = this.profile().timeZone;
    this.writeLog(`${task.id} start (${source})${text ? ' extra=' + JSON.stringify(String(text).slice(0, 120)) : ''}`);
    let result;
    try {
      const prompt = buildTaskPrompt(task, { appDir: this.paths.appDir, dbDir: this.paths.db, profile: this.profile(), text, tz });
      const args = ['-p', prompt, '--output-format', 'stream-json', '--verbose',
        '--mcp-config', this.mcpConfigFile(task.id), '--strict-mcp-config',
        '--allowedTools', TOOLS.join(','), '--disallowedTools', NO_TOOLS.join(','),
        '--permission-mode', 'auto', '--permission-prompts', 'none',
        '--model', task.model || 'sonnet', '--add-dir', this.paths.db];
      const od = this.profile().oneDriveRoot;
      if (od && fs.existsSync(od)) args.push('--add-dir', od);
      const cwd = path.join(this.paths.tmp, 'task-' + task.id);
      fs.mkdirSync(cwd, { recursive: true });
      const timeout = setTimeout(() => controller.abort(), 40 * 60 * 1000);
      result = await runClaude({ args, cwd, signal: controller.signal, claudePath: this.claudePath });
      clearTimeout(timeout);
      if (!result.ok && result.error === 'bad_option') {
        // older CLI without --permission-prompts: fall back to dontAsk with an explicit allow-list
        const i = args.indexOf('--permission-mode'); args.splice(i, 4, '--permission-mode', 'dontAsk');
        result = await runClaude({ args, cwd, signal: controller.signal, claudePath: this.claudePath });
      }
      this.writeLog(`${task.id} ${result.ok ? 'done' : 'failed: ' + result.message} :: ${String(result.text || '').split('\n').filter(Boolean).slice(-1)[0] || ''}`.slice(0, 1000));
      if (!result.ok && result.error === 'not_signed_in') this.notify({ title: 'Molly', text: 'Background tasks need you to sign in to Claude again. Open Molly\'s menu → Set up again…' });
    } finally {
      this.running.delete(task.id);
      const st = this.state();
      this.saveState({ runs: { ...(st.runs || {}), [task.id]: { at: new Date().toISOString(), ok: !!result?.ok, error: result?.message || null, source } } });
      const next = this.queue.findIndex(q => q.id === task.id);
      if (next >= 0) { const q = this.queue.splice(next, 1)[0]; this.fire(q.id, q.text, { source: q.source }); }
    }
    return result;
  }

  // OPEN_TASK: {requestId, path} → open the OneDrive file in its normal app.
  async runNative(task, text) {
    if (task.id !== 'open-file') return;
    let req = {}; try { req = JSON.parse(text || '{}'); } catch {}
    const id = String(req.requestId || '');
    if (!id) return;
    const docPath = 'fileopen/' + id;
    const fail = error => this.db.update(docPath, { status: 'failed', error, finishedAt: new Date().toISOString() });
    const root = this.profile().oneDriveRoot;
    const rel = String(req.path || this.db.get(docPath).data?.path || '');
    if (!root || !fs.existsSync(root)) return fail('Your OneDrive folder was not found on this Mac.');
    const full = path.resolve(root, rel);
    if (!(full === root || full.startsWith(path.resolve(root) + path.sep))) return fail('That path is outside your OneDrive folder.');
    if (!fs.existsSync(full)) return fail('That file is no longer there.');
    this.db.update(docPath, { status: 'working', startedAt: new Date().toISOString() });
    const err = await this.openPath(full);
    if (err) return fail(String(err));
    this.db.update(docPath, { status: 'done', finishedAt: new Date().toISOString(), name: path.basename(full), openedOnMac: true });
    this.writeLog(`open-file opened ${rel}`);
  }

  startCron() {
    const st = this.state();
    this.scheduler = new Scheduler({
      jobs: TASKS.filter(t => t.cron && !this.isDisabled(t.id)).map(t => ({ id: t.id, cron: t.cron, catchUpMin: t.catchUpMin ?? 180 })),
      tz: this.profile().timeZone || undefined,
      state: st.cron || {},
      onState: s => this.saveState({ cron: s }),
      onDue: d => {
        const t = TASKS.find(x => x.id === d.id);
        if (t.needsOneDrive && !this.profile().oneDriveRoot) return;
        this.fire(d.id, '', { source: d.late ? 'catch-up' : 'schedule' });
      },
    });
    this.scheduler.start(30000);
    return this.scheduler;
  }
  stopCron() { this.scheduler?.stop(); }
  isDisabled(id) { return (this.settings().disabledTasks || []).includes(id); }

  summary() {
    const st = this.state();
    return TASKS.map(t => ({ id: t.id, name: t.name, cron: t.cron, running: this.running.has(t.id), last: st.runs?.[t.id] || null, next: t.cron && this.scheduler ? this.scheduler.next(t.id)?.toISOString() : null, disabled: this.isDisabled(t.id) }));
  }
}

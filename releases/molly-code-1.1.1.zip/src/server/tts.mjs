// ElevenLabs voice for Molly (optional). The user's own ElevenLabs account and API key; the key is
// kept in <data>/elevenlabs.json (owner-only file), never logged, never sent anywhere but ElevenLabs.
// When the month's credits are nearly used up, or anything fails, the page falls back to the Mac's
// own voice by itself (see src/renderer/tts.js).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const API = 'https://api.elevenlabs.io';
export const DEFAULT_MODEL = 'eleven_flash_v2_5'; // half a credit per character: about twice the minutes of the multilingual model
export const RESERVE = 200;                      // stop a little before the limit so a sentence never cuts off
const STATUS_TTL = 10 * 60 * 1000;
const CACHE_MAX = 300;

export class TtsError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

export function createTts({ dataDir, fetchImpl = globalThis.fetch, log = () => {}, now = () => Date.now() } = {}) {
  const file = path.join(dataDir, 'elevenlabs.json');
  const cacheDir = path.join(dataDir, 'tts-cache');
  let sub = null, subAt = 0, exhaustedUntil = 0;

  const read = () => { try { return JSON.parse(fs.readFileSync(file, 'utf8')) || {}; } catch { return {}; } };
  function write(patch) {
    const next = { ...read(), ...patch };
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, file);
    try { fs.chmodSync(file, 0o600); } catch {}
    return next;
  }

  async function call(p, { method = 'GET', body, key, accept = 'application/json' } = {}) {
    const k = key || read().apiKey;
    if (!k) throw new TtsError('not_configured', 'No ElevenLabs key yet.');
    const r = await fetchImpl(API + p, {
      method,
      headers: { 'xi-api-key': k, accept, ...(body ? { 'content-type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!r.ok) {
      let detail = ''; try { const j = await r.json(); detail = j?.detail?.status || j?.detail?.message || JSON.stringify(j?.detail || j); } catch {}
      if (/quota/i.test(detail)) throw new TtsError('quota', 'ElevenLabs credits are used up for this month.');
      if (r.status === 401) throw new TtsError('bad_key', 'ElevenLabs didn\'t accept the key.');
      if (r.status === 429) throw new TtsError('busy', 'ElevenLabs is busy (too many requests).');
      throw new TtsError('failed', `ElevenLabs error ${r.status}${detail ? ': ' + String(detail).slice(0, 160) : ''}`);
    }
    return r;
  }

  async function subscription(force = false) {
    if (!force && sub && now() - subAt < STATUS_TTL) return sub;
    const j = await (await call('/v1/user/subscription')).json();
    sub = {
      used: Number(j.character_count) || 0,
      limit: Number(j.character_limit) || 0,
      resetAt: j.next_character_count_reset_unix ? new Date(j.next_character_count_reset_unix * 1000).toISOString() : null,
      tier: j.tier || '',
    };
    subAt = now();
    if (sub.limit && sub.limit - sub.used > RESERVE) exhaustedUntil = 0;
    return sub;
  }

  async function status({ refresh = false } = {}) {
    const c = read();
    const out = { configured: !!c.apiKey, enabled: c.enabled !== false, voiceId: c.voiceId || '', voiceName: c.voiceName || '', model: c.model || DEFAULT_MODEL };
    if (!out.configured) return { ...out, active: false };
    try {
      const s = await subscription(refresh);
      const left = s.limit ? s.limit - s.used : null;
      const exhausted = (left != null && left <= RESERVE) || exhaustedUntil > now();
      return { ...out, ...s, left, exhausted, active: out.enabled && !!out.voiceId && !exhausted };
    } catch (e) {
      return { ...out, error: e.code, message: e.message, active: false };
    }
  }

  /** Save settings. A new key is checked with ElevenLabs first; the key itself is never returned. */
  async function configure({ apiKey, voiceId, voiceName, enabled, model } = {}) {
    const patch = {};
    if (apiKey !== undefined) {
      const k = String(apiKey).trim();
      if (!k) patch.apiKey = '';
      else {
        if (!/^[A-Za-z0-9_\-]{20,200}$/.test(k)) throw new TtsError('bad_key', 'That doesn\'t look like an ElevenLabs API key.');
        await call('/v1/user/subscription', { key: k });
        patch.apiKey = k; sub = null;
      }
    }
    if (voiceId !== undefined) { if (voiceId && !/^[A-Za-z0-9]{8,64}$/.test(voiceId)) throw new TtsError('bad_voice', 'Unknown voice.'); patch.voiceId = voiceId || ''; patch.voiceName = String(voiceName || '').slice(0, 80); }
    if (enabled !== undefined) patch.enabled = !!enabled;
    if (model !== undefined && /^[a-z0-9_]{3,60}$/.test(model)) patch.model = model;
    write(patch);
    return status({ refresh: true });
  }

  async function voices() {
    const j = await (await call('/v1/voices')).json();
    return (j.voices || []).map(v => ({
      id: v.voice_id, name: v.name, category: v.category || '',
      accent: v.labels?.accent || '', gender: v.labels?.gender || '', age: v.labels?.age || '',
      description: v.labels?.description || v.description || '', preview: v.preview_url || '',
    })).sort((a, b) => (score(b) - score(a)) || a.name.localeCompare(b.name));
  }
  const score = v => (/british|english/i.test(v.accent) ? 2 : 0) + (/female/i.test(v.gender) ? 1 : 0);

  function cacheKey(text, voiceId, model, speed) {
    return crypto.createHash('sha256').update([voiceId, model, speed, text].join('\u0000')).digest('hex').slice(0, 40);
  }
  function trimCache() {
    try {
      const files = fs.readdirSync(cacheDir).map(n => ({ n, t: fs.statSync(path.join(cacheDir, n)).mtimeMs })).sort((a, b) => b.t - a.t);
      for (const f of files.slice(CACHE_MAX)) fs.rmSync(path.join(cacheDir, f.n), { force: true }); // Molly's own cache, not user files
    } catch {}
  }

  /** Text → MP3 bytes. Throws TtsError (not_configured, no_voice, quota, bad_key, busy, failed). */
  async function speak(text, { rate = 1, voiceId } = {}) {
    const c = read();
    text = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 1200);
    if (!text) throw new TtsError('empty', 'Nothing to say.');
    if (!c.apiKey) throw new TtsError('not_configured', 'No ElevenLabs key yet.');
    if (c.enabled === false) throw new TtsError('disabled', 'ElevenLabs voice is switched off.');
    const vid = voiceId || c.voiceId;
    if (!vid) throw new TtsError('no_voice', 'Choose an ElevenLabs voice first.');
    const model = c.model || DEFAULT_MODEL;
    const speed = Math.max(0.7, Math.min(1.2, Number(rate) || 1)).toFixed(2);
    const key = cacheKey(text, vid, model, speed);
    const cached = path.join(cacheDir, key + '.mp3');
    if (fs.existsSync(cached)) { try { fs.utimesSync(cached, new Date(), new Date()); } catch {} return fs.readFileSync(cached); }
    if (exhaustedUntil > now()) throw new TtsError('quota', 'ElevenLabs credits are used up for this month.');
    if (sub && sub.limit && sub.limit - sub.used <= RESERVE) throw new TtsError('quota', 'ElevenLabs credits are used up for this month.');
    let r;
    try {
      r = await call(`/v1/text-to-speech/${encodeURIComponent(vid)}?output_format=mp3_44100_64`, {
        method: 'POST', accept: 'audio/mpeg',
        body: { text, model_id: model, voice_settings: { stability: 0.5, similarity_boost: 0.75, speed: Number(speed) } },
      });
    } catch (e) {
      if (e.code === 'quota') exhaustedUntil = sub?.resetAt ? Date.parse(sub.resetAt) : now() + 6 * 3600e3;
      log(`tts: ${e.code}`);
      throw e;
    }
    const buf = Buffer.from(await r.arrayBuffer());
    if (sub) sub.used += Math.ceil(text.length * (/flash|turbo/.test(model) ? 0.5 : 1));
    try { fs.mkdirSync(cacheDir, { recursive: true }); fs.writeFileSync(cached, buf); trimCache(); } catch {}
    return buf;
  }

  return { status, configure, voices, speak, file, cacheDir };
}

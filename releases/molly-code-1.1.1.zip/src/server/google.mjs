// Google sign-in (loopback OAuth with PKCE) and Gmail / Google Calendar tools that return the
// same payload shapes as the claude.ai Gmail and Google Calendar connectors, so the Molly page
// works unchanged. No external dependencies.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const SCOPES = [
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/calendar',
  'openid', 'email',
];

export class McpError extends Error {
  constructor(code, message) { super(message); this.code = code; this.server = true; }
}

const readJson = p => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } };
function writeSecret(p, obj) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  const tmp = p + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, p);
}

export function createGoogle(paths, { fetchImpl = globalThis.fetch } = {}) {
  const fetch = (...a) => fetchImpl(...a);

  function clientFile() {
    for (const f of [paths.googleClientUser, paths.googleClientBundled]) if (f && fs.existsSync(f)) return f;
    return null;
  }
  function getClient() {
    const f = clientFile(); if (!f) return null;
    const j = readJson(f); if (!j) return null;
    const c = j.installed || j.web || j;
    return c.client_id ? { id: c.client_id, secret: c.client_secret } : null;
  }
  function saveClient(obj) {
    if (typeof obj === 'string') obj = JSON.parse(obj);
    const c = obj && (obj.installed || obj.web || obj);
    if (!c || !c.client_id || !c.client_secret) throw new Error('That file does not look like a Google OAuth client (no client_id / client_secret).');
    writeSecret(paths.googleClientUser, obj);
  }
  function status() {
    const tok = readJson(paths.googleToken);
    return { clientConfigured: !!getClient(), connected: !!(tok && tok.refresh_token), email: tok?.email || null, scopes: tok?.scope || null };
  }

  const pending = new Map(); // state -> { verifier, redirectUri, at }
  function authUrl(redirectUri, { loginHint } = {}) {
    const c = getClient();
    if (!c) throw new Error('Google client not configured');
    const verifier = crypto.randomBytes(48).toString('base64url');
    const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
    const state = crypto.randomBytes(16).toString('hex');
    pending.set(state, { verifier, redirectUri, at: Date.now() });
    const q = new URLSearchParams({
      client_id: c.id, redirect_uri: redirectUri, response_type: 'code',
      scope: SCOPES.join(' '), access_type: 'offline', prompt: 'consent', include_granted_scopes: 'true',
      code_challenge: challenge, code_challenge_method: 'S256', state,
    });
    if (loginHint) q.set('login_hint', loginHint);
    return 'https://accounts.google.com/o/oauth2/v2/auth?' + q;
  }

  async function handleCallback(params) {
    const p = pending.get(params.get('state'));
    if (!p) throw new Error('This sign-in link has expired. Please click "Connect Google" again.');
    pending.delete(params.get('state'));
    if (params.get('error')) throw new Error('Google said: ' + params.get('error'));
    const c = getClient();
    const r = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ code: params.get('code'), client_id: c.id, client_secret: c.secret, redirect_uri: p.redirectUri, grant_type: 'authorization_code', code_verifier: p.verifier }),
    });
    const t = await r.json();
    if (!r.ok) throw new Error('Google sign-in failed: ' + (t.error_description || t.error));
    let email = null;
    if (t.id_token) { try { email = JSON.parse(Buffer.from(t.id_token.split('.')[1], 'base64url').toString()).email; } catch {} }
    writeSecret(paths.googleToken, { refresh_token: t.refresh_token, access_token: t.access_token, expires_at: Date.now() + (t.expires_in - 60) * 1000, email, scope: t.scope });
    return email;
  }

  function disconnect() { try { fs.renameSync(paths.googleToken, paths.googleToken + '.old'); } catch {} }

  let refreshing = null;
  async function accessToken() {
    const tok = readJson(paths.googleToken);
    if (!tok?.refresh_token) throw new McpError('server_not_connected', 'Google is not connected. Open Molly\'s menu and choose "Connect Google".');
    if (tok.access_token && tok.expires_at > Date.now()) return tok.access_token;
    if (refreshing) return refreshing;
    refreshing = (async () => {
      const c = getClient();
      if (!c) throw new McpError('server_not_connected', 'The Google client file is missing.');
      const r = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ client_id: c.id, client_secret: c.secret, refresh_token: tok.refresh_token, grant_type: 'refresh_token' }),
      });
      const t = await r.json();
      if (!r.ok) throw new McpError('needs_reauth', 'Google sign-in has expired (' + (t.error || r.status) + '). Choose "Connect Google" in Molly\'s menu.');
      tok.access_token = t.access_token; tok.expires_at = Date.now() + (t.expires_in - 60) * 1000;
      writeSecret(paths.googleToken, tok);
      return tok.access_token;
    })();
    try { return await refreshing; } finally { refreshing = null; }
  }

  async function api(url, opts = {}) {
    const at = await accessToken();
    const r = await fetch(url, { ...opts, headers: { authorization: 'Bearer ' + at, 'content-type': 'application/json', ...(opts.headers || {}) } });
    const text = await r.text();
    let body = {}; try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
    if (!r.ok) {
      const msg = body.error?.message || text.slice(0, 200);
      if (r.status === 401) throw new McpError('needs_reauth', 'Google needs you to sign in again: ' + msg);
      if (r.status === 403 && /insufficient|scope/i.test(msg)) throw new McpError('not_granted', 'Google access was not granted for this: ' + msg);
      if (r.status === 429) throw new McpError('rate_limited', 'Google is busy. Try again in a minute.');
      if (r.status === 404) throw new McpError('not_found', 'Not found: ' + msg);
      throw new McpError('google_error', `Google API error ${r.status}: ${msg}`);
    }
    return body;
  }

  return { getClient, saveClient, status, authUrl, handleCallback, disconnect, api, accessToken, email: () => readJson(paths.googleToken)?.email || null };
}

// ---------------- Gmail message helpers (pure; unit-tested with fixtures) ----------------
export const hdr = (m, n) => (m.payload?.headers || []).find(h => h.name.toLowerCase() === n.toLowerCase())?.value || '';
export function decodeB64(s) { return Buffer.from(String(s || '').replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'); }

export function splitAddresses(s) {
  const out = []; let cur = '', q = false, depth = 0;
  for (const ch of String(s || '')) {
    if (ch === '"') q = !q;
    if (!q && ch === '<') depth++;
    if (!q && ch === '>') depth = Math.max(0, depth - 1);
    if (ch === ',' && !q && !depth) { if (cur.trim()) out.push(cur.trim()); cur = ''; continue; }
    cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function findPart(part, mime) {
  if (!part) return null;
  if (part.mimeType === mime && part.body?.data && !part.filename) return part;
  for (const p of part.parts || []) { const f = findPart(p, mime); if (f) return f; }
  return null;
}
export function htmlToText(h) {
  return String(h || '')
    .replace(/<(style|script|head)[\s\S]*?<\/\1>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|tr|li|h\d)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
export function plainBody(payload) {
  const t = findPart(payload, 'text/plain'); if (t) return decodeB64(t.body.data);
  const h = findPart(payload, 'text/html'); if (h) return htmlToText(decodeB64(h.body.data));
  return '';
}
export function htmlBody(payload) {
  const h = findPart(payload, 'text/html'); if (h) return decodeB64(h.body.data);
  return '';
}
export function attachmentsOf(part, out = []) {
  if (!part) return out;
  if (part.filename && (part.body?.attachmentId || part.body?.size)) out.push({ filename: part.filename, id: part.body?.attachmentId || '', mimeType: part.mimeType, partId: part.partId || '', size: part.body?.size || 0 });
  for (const p of part.parts || []) attachmentsOf(p, out);
  return out;
}
export function viewUrl(email, threadId) {
  return `https://mail.google.com/mail/?authuser=${encodeURIComponent(email || '')}#all/${threadId}`;
}
export function mapMessage(m, { email, format = 'MINIMAL' } = {}) {
  const out = {
    id: m.id, threadId: m.threadId,
    date: m.internalDate ? new Date(+m.internalDate).toISOString() : (hdr(m, 'Date') ? new Date(hdr(m, 'Date')).toISOString() : ''),
    sender: hdr(m, 'From'),
    toRecipients: splitAddresses(hdr(m, 'To')),
    ccRecipients: splitAddresses(hdr(m, 'Cc')),
    subject: hdr(m, 'Subject'),
    snippet: decodeEntities(m.snippet || ''),
    labelIds: m.labelIds || [],
    viewUrl: viewUrl(email, m.threadId),
  };
  if (format === 'PLAIN_TEXT' || format === 'FULL_CONTENT') {
    out.plaintextBody = plainBody(m.payload);
    out.attachments = attachmentsOf(m.payload);
  }
  if (format === 'FULL_CONTENT') out.htmlBody = htmlBody(m.payload);
  return out;
}
function decodeEntities(s) { return s.replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'); }

function encodeHeader(s) { return /^[\x20-\x7e]*$/.test(s) ? s : '=?UTF-8?B?' + Buffer.from(s).toString('base64') + '?='; }
export function buildRfc822({ from, to, cc, subject, body, inReplyTo, references }) {
  const list = v => (Array.isArray(v) ? v : String(v || '').split(/[,;]\s*/)).map(s => String(s).trim()).filter(Boolean).join(', ');
  const lines = [
    from ? `From: ${from}` : null,
    `To: ${list(to)}`, list(cc) ? `Cc: ${list(cc)}` : null, `Subject: ${encodeHeader(subject || '')}`,
    inReplyTo ? `In-Reply-To: ${inReplyTo}` : null, references ? `References: ${references}` : null,
    'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '',
    Buffer.from(String(body || '')).toString('base64').replace(/.{76}/g, '$&\r\n'),
  ].filter(l => l !== null);
  return Buffer.from(lines.join('\r\n')).toString('base64url');
}

// Small helper: run async fns with limited concurrency, keeping order.
export async function pmap(items, n, fn) {
  const out = new Array(items.length); let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); } }));
  return out;
}

// Calendar helpers
export function localDate(iso, timeZone) {
  const d = new Date(iso);
  if (isNaN(d)) return String(iso).slice(0, 10);
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: timeZone || undefined, year: 'numeric', month: '2-digit', day: '2-digit' });
  return f.format(d);
}
export function addDays(ymd, n) {
  const d = new Date(ymd + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10);
}

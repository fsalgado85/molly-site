// A small cron: standard 5-field expressions (minute hour day-of-month month day-of-week),
// evaluated in a given IANA time zone, checked once a minute, with catch-up after sleep.

const RANGES = [[0, 59], [0, 23], [1, 31], [1, 12], [0, 7]];

function parseField(f, [lo, hi]) {
  const set = new Set();
  for (const part of String(f).split(',')) {
    let [range, step] = part.split('/');
    step = step === undefined ? 1 : parseInt(step, 10);
    if (!(step >= 1)) throw new Error('Bad cron step: ' + part);
    let a, b;
    if (range === '*') { a = lo; b = hi; }
    else if (range.includes('-')) { [a, b] = range.split('-').map(n => parseInt(n, 10)); }
    else { a = parseInt(range, 10); b = step > 1 && part.includes('/') ? hi : a; }
    if (isNaN(a) || isNaN(b) || a < lo || b > hi || a > b) throw new Error('Bad cron field: ' + part);
    for (let v = a; v <= b; v += step) set.add(v);
  }
  return set;
}

export function parseCron(expr) {
  let tz = null;
  let s = String(expr).trim();
  const m = s.match(/^CRON_TZ=(\S+)\s+(.*)$/);
  if (m) { tz = m[1]; s = m[2]; }
  const f = s.split(/\s+/);
  if (f.length !== 5) throw new Error('A cron expression needs 5 fields: ' + expr);
  const [min, hour, dom, mon, dow] = f.map((x, i) => parseField(x, RANGES[i]));
  if (dow.has(7)) dow.add(0);
  return { tz, min, hour, dom, mon, dow, domStar: f[2] === '*', dowStar: f[4] === '*' };
}

const fmtCache = new Map();
export function zonedParts(date, tz) {
  const key = tz || 'local';
  let f = fmtCache.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat('en-GB', { timeZone: tz || undefined, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', weekday: 'short' });
    fmtCache.set(key, f);
  }
  const o = {};
  for (const p of f.formatToParts(date)) o[p.type] = p.value;
  const wd = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[o.weekday];
  return { year: +o.year, month: +o.month, day: +o.day, hour: +o.hour % 24, minute: +o.minute, dow: wd };
}

export function matches(cron, date, tz) {
  const p = zonedParts(date, cron.tz || tz);
  if (!cron.min.has(p.minute) || !cron.hour.has(p.hour) || !cron.mon.has(p.month)) return false;
  const d1 = cron.dom.has(p.day), d2 = cron.dow.has(p.dow);
  // classic cron: if both day fields are restricted, either may match
  if (!cron.domStar && !cron.dowStar) return d1 || d2;
  return d1 && d2;
}

const MIN = 60000;
/** The most recent scheduled minute in (after, now]; null if none. Scans minute by minute (bounded). */
export function lastDue(cron, now, after, tz, maxLookbackMin = 24 * 60) {
  const end = Math.floor(now.getTime() / MIN) * MIN;
  const start = Math.max(after ? Math.floor(after.getTime() / MIN) * MIN + MIN : end - maxLookbackMin * MIN, end - maxLookbackMin * MIN);
  for (let t = end; t >= start; t -= MIN) if (matches(cron, new Date(t), tz)) return new Date(t);
  return null;
}

export function nextDue(cron, from, tz, maxMin = 8 * 24 * 60) {
  let t = Math.floor(from.getTime() / MIN) * MIN + MIN;
  for (let i = 0; i < maxMin; i++, t += MIN) if (matches(cron, new Date(t), tz)) return new Date(t);
  return null;
}

/**
 * Scheduler: jobs = [{id, cron, catchUpMin}]; state = {lastRun: {id: iso}}.
 * tick(now) returns ids due now (including runs missed while the Mac slept, within catchUpMin).
 */
export class Scheduler {
  constructor({ jobs, tz, state = {}, onDue, onState }) {
    this.tz = tz; this.onDue = onDue; this.onState = onState;
    this.state = { lastCheck: state.lastCheck || null, lastRun: { ...(state.lastRun || {}) } };
    this.jobs = jobs.filter(j => j.cron).map(j => ({ ...j, parsed: parseCron(j.cron) }));
  }
  tick(now = new Date()) {
    const due = [];
    const lastCheck = this.state.lastCheck ? new Date(this.state.lastCheck) : new Date(now.getTime() - MIN);
    for (const j of this.jobs) {
      const lookback = j.catchUpMin ?? 180;
      const since = new Date(Math.max(lastCheck.getTime(), now.getTime() - lookback * MIN) - 1);
      const last = j.id in this.state.lastRun ? new Date(this.state.lastRun[j.id]) : null;
      const when = lastDue(j.parsed, now, last && last > since ? last : since, this.tz, lookback);
      if (when) { this.state.lastRun[j.id] = when.toISOString(); due.push({ id: j.id, scheduledFor: when, late: now - when > 2 * MIN }); }
    }
    this.state.lastCheck = now.toISOString();
    this.onState?.(this.state);
    for (const d of due) this.onDue?.(d);
    return due;
  }
  start(intervalMs = 30000) {
    this.stop();
    this.timer = setInterval(() => { try { this.tick(); } catch {} }, intervalMs);
    this.timer.unref?.();
    try { this.tick(); } catch {}
  }
  stop() { clearInterval(this.timer); this.timer = null; }
  next(id, from = new Date()) { const j = this.jobs.find(x => x.id === id); return j ? nextDue(j.parsed, from, this.tz) : null; }
}

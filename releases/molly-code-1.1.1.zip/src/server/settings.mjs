// settings.json in the data folder: the profile from the setup wizard and app preferences.
import fs from 'node:fs';
import { completeProfile } from './personalise.mjs';

export function createSettings(paths) {
  let cache = null;
  function read() {
    if (cache) return cache;
    try { cache = JSON.parse(fs.readFileSync(paths.settings, 'utf8')); } catch { cache = {}; }
    cache.profile = cache.profile || {};
    return cache;
  }
  function write(patch) {
    const cur = read();
    const next = { ...cur, ...patch, profile: { ...cur.profile, ...(patch.profile || {}) } };
    const tmp = paths.settings + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, paths.settings);
    cache = next;
    return next;
  }
  return {
    get: read,
    set: write,
    profile: () => completeProfile(read().profile),
    reload: () => { cache = null; return read(); },
  };
}

// The wizard's answers also go into the page's own documents (meta/config, meta/marketsWatch, meta/news).
export function applyProfileToDb(db, profile) {
  const p = completeProfile(profile);
  const cfg = db.get('meta/config').data || {};
  const nextCfg = { ...cfg, name: p.assistantName || cfg.name || 'Molly' };
  if (p.voiceName) nextCfg.voiceName = p.voiceName;
  if (Array.isArray(p.clocks) && p.clocks.length) nextCfg.clocks = p.clocks.slice(0, 3).map(c => ({ tz: c.tz || c }));
  if (p.familyCalendar) nextCfg.familyCalendar = p.familyCalendar;
  db.set('meta/config', nextCfg);
  if (Array.isArray(p.markets)) db.set('meta/marketsWatch', { ...(db.get('meta/marketsWatch').data || {}), list: p.markets.slice(0, 8), at: new Date().toISOString() });
  if (Array.isArray(p.newsTopics)) db.update('meta/news', { topics: p.newsTopics.slice(0, 8) });
}

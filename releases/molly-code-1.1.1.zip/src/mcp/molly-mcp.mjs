#!/usr/bin/env node
// "molly" MCP server: the local database (same operations as the claude.ai ArtifactData tool) and
// push notifications for background tasks (MOLLY_MCP_MODE=task, the default); read-only database
// access plus the notes memory for the chat (MOLLY_MCP_MODE=chat).
import { serveStdio, molly } from './stdio.mjs';

const mode = process.env.MOLLY_MCP_MODE || 'task';
const S = { type: 'string' };
const doc = (extra = {}, req = []) => ({ type: 'object', properties: { collection: S, doc_id: S, ...extra }, required: ['collection', 'doc_id', ...req] });
const READ = [
  { name: 'db_get', description: 'Get one document from Molly\'s database. Returns {exists, id, data}.', inputSchema: doc() },
  { name: 'db_list', description: 'List the documents of a collection (matters, renewals, watchlist, research, packs, filings, files, log, memory, meta). Returns {docs:[{id, data}]}.', inputSchema: { type: 'object', properties: { collection: S, orderBy: S, direction: S, limit: { type: 'number' } }, required: ['collection'] } },
];
const TASK = [
  ...READ,
  { name: 'db_set', description: 'Create or replace a whole document with data (an object).', inputSchema: doc({ data: { type: 'object' } }, ['data']) },
  { name: 'db_update', description: 'Merge top-level fields into a document (created if missing). A field whose value is {"__delete__": true} is removed.', inputSchema: doc({ data: { type: 'object' } }, ['data']) },
  { name: 'db_delete', description: 'Delete one document from the database (only when the task says so).', inputSchema: doc() },
  { name: 'notify', description: 'Send a push notification to the person (a macOS notification from Molly). Use where the task says "send a push notification". Plain text, keep it short.', inputSchema: { type: 'object', properties: { text: S, title: S }, required: ['text'] } },
];
const CHAT = [
  ...READ,
  { name: 'memory_save', description: 'Remember a lasting fact or preference the person told you (one short sentence in their terms, e.g. "Prefers morning appointments" or "Car: 2019 VW Golf, reg on the V5"). Never passwords, card or bank numbers. Returns the note id.', inputSchema: { type: 'object', properties: { text: S, kind: { type: 'string', enum: ['fact', 'preference', 'person', 'routine'] } }, required: ['text'] } },
  { name: 'memory_list', description: 'List the notes you have saved about the person.', inputSchema: { type: 'object', properties: {} } },
  { name: 'memory_forget', description: 'Forget a saved note (by its id) when the person asks you to.', inputSchema: { type: 'object', properties: { id: S }, required: ['id'] } },
];
const TOOLS = mode === 'chat' ? CHAT : TASK;

// Never store secrets in the notes (passwords, long card/account numbers, sort codes).
export function looksSecret(text) {
  const t = String(text || '');
  return /\b(password|passcode|pin\b|cvv|cvc)\b/i.test(t) || /\b(?:\d[ -]?){12,19}\b/.test(t) || /\b\d{2}-\d{2}-\d{2}\b/.test(t);
}

if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split('/').pop())) {
  serveStdio({
    name: 'molly',
    listTools: () => TOOLS,
    callTool: async (name, a) => {
      if (!TOOLS.some(t => t.name === name)) throw new Error('Unknown or not allowed tool ' + name);
      const p = () => `${a.collection}/${a.doc_id}`;
      const parse = d => (typeof d === 'string' ? JSON.parse(d) : d);
      switch (name) {
        case 'db_get': { const r = await molly('/api/db', { op: 'get', path: p() }); return { exists: r.exists, id: r.id, data: r.data }; }
        case 'db_list': { const r = await molly('/api/db', { op: 'list', path: a.collection, opts: { orderBy: a.orderBy, dir: a.direction, limit: a.limit } }); return { docs: r.docs }; }
        case 'db_set': await molly('/api/db', { op: 'set', path: p(), data: parse(a.data) }); return 'Saved.';
        case 'db_update': await molly('/api/db', { op: 'update', path: p(), data: parse(a.data) }); return 'Updated.';
        case 'db_delete': await molly('/api/db', { op: 'delete', path: p() }); return 'Deleted.';
        case 'notify': await molly('/api/notify', { text: String(a.text || ''), title: a.title || '', task: process.env.MOLLY_TASK_ID || '' }); return 'Notification sent.';
        case 'memory_save': {
          const text = String(a.text || '').trim().slice(0, 500);
          if (!text) throw new Error('Nothing to remember.');
          if (looksSecret(text)) throw new Error('Not saved: notes never hold passwords, PINs, card or bank numbers.');
          const cur = await molly('/api/db', { op: 'list', path: 'memory' });
          const same = (cur.docs || []).find(d => !d.data?.forgotten && String(d.data?.text || '').toLowerCase() === text.toLowerCase());
          if (same) return { id: same.id, saved: false, note: 'Already remembered.' };
          const r = await molly('/api/db', { op: 'add', path: 'memory', data: { text, kind: a.kind || 'fact', at: new Date().toISOString(), source: 'chat' } });
          return { id: r.id, saved: true };
        }
        case 'memory_list': {
          const r = await molly('/api/db', { op: 'list', path: 'memory', opts: { orderBy: 'at', dir: 'desc' } });
          return { notes: (r.docs || []).filter(d => !d.data?.forgotten).map(d => ({ id: d.id, text: d.data?.text, kind: d.data?.kind, at: d.data?.at })) };
        }
        case 'memory_forget': {
          // the note's text is removed and the record marked forgotten (no file is deleted)
          const id = String(a.id || '').replace(/[^a-zA-Z0-9_-]/g, '');
          const cur = await molly('/api/db', { op: 'get', path: `memory/${id}` });
          if (!id || !cur.exists) throw new Error('No saved note with that id.');
          await molly('/api/db', { op: 'update', path: `memory/${id}`, data: { forgotten: true, forgottenAt: new Date().toISOString(), text: { __delete__: true } } });
          return 'Forgotten.';
        }
      }
      throw new Error('Unknown tool ' + name);
    },
  });
}

#!/usr/bin/env node
// "google" MCP server: Gmail and Google Calendar with the same tool names and payloads as the
// claude.ai connectors. It relays every call to Molly's local server, which holds the Google token
// and enforces the safety rules for the caller (MOLLY_MCP_MODE = task | agent | chat).
import { serveStdio, molly } from './stdio.mjs';

const mode = process.env.MOLLY_MCP_MODE || 'task';
const S = { type: 'string' }, N = { type: 'number' }, A = { type: 'array', items: { type: 'string' } };
const obj = (properties, required = []) => ({ type: 'object', properties, required });
const FORMAT = { type: 'string', enum: ['MINIMAL', 'PLAIN_TEXT', 'FULL_CONTENT', 'RAW'] };

const ALL = [
  ['Gmail', 'search_threads', 'Search Gmail threads with Gmail search syntax (e.g. "from:eon newer_than:7d"). Returns threads with all their messages (id, threadId, date, sender, toRecipients, subject, snippet, labelIds, viewUrl) and resultCountEstimate.', obj({ query: S, pageSize: N, pageToken: S }, ['query'])],
  ['Gmail', 'get_thread', 'Read a Gmail thread. messageFormat MINIMAL (headers), PLAIN_TEXT (adds plaintextBody and attachments) or FULL_CONTENT (adds htmlBody).', obj({ threadId: S, messageFormat: FORMAT }, ['threadId'])],
  ['Gmail', 'get_message', 'Read one Gmail message. PLAIN_TEXT gives plaintextBody and attachments; RAW gives {raw}: the base64url RFC 822 message.', obj({ messageId: S, messageFormat: FORMAT }, ['messageId'])],
  ['Gmail', 'list_labels', 'List Gmail labels.', obj({})],
  ['Gmail', 'save_attachment', 'Save one email attachment into a folder on this Mac (inside OneDrive). Never overwrites: adds " (2)", " (3)"… if the name exists. Returns {savedPath, bytes}.', obj({ messageId: S, filename: S, destPath: { type: 'string', description: 'Absolute path of the file to create' } }, ['messageId', 'filename', 'destPath'])],
  ['Gmail', 'create_draft', 'Create a Gmail draft (never sends). Agent only.', obj({ to: A, cc: A, subject: S, body: S, replyToMessageId: S }, ['to', 'body']), 'agent'],
  ['Google Calendar', 'list_calendars', 'List the calendars this person can see.', obj({})],
  ['Google Calendar', 'list_events', 'List calendar events between startTime and endTime (ISO 8601). Returns raw Google event objects.', obj({ startTime: S, endTime: S, timeZone: S, calendarId: S, pageSize: N, orderBy: S, query: S }, ['startTime', 'endTime'])],
  ['Google Calendar', 'create_event', 'Create a calendar event. Agent only, and only after the person has confirmed it.', obj({ summary: S, startTime: S, endTime: S, timeZone: S, allDay: { type: 'boolean' }, description: S, location: S }, ['summary', 'startTime', 'endTime']), 'agent'],
];
// chat: read-only (changes go through the page's own tools, which show a Confirm card)
const tools = ALL.filter(t => (!t[4] || t[4] === mode) && !(mode === 'chat' && t[1] === 'save_attachment'));

serveStdio({
  name: 'molly-google',
  listTools: () => tools.map(([, name, description, inputSchema]) => ({ name, description, inputSchema })),
  callTool: async (name, args) => {
    const t = tools.find(x => x[1] === name);
    if (!t) throw new Error('Unknown or not allowed tool ' + name);
    const r = await molly('/api/mcp/call', { server: t[0], tool: name, args, caller: mode });
    return r.structuredContent;
  },
});

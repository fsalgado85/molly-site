#!/usr/bin/env node
// "page" MCP server: exposes the Molly page's own tools (create_calendar_event, search_email, ...)
// to `claude -p`. Each call is relayed to the page, which runs the tool (showing its confirm
// dialogs) and posts the result back. See PLAN.md §3 "sample".
import fs from 'node:fs';
import { serveStdio, molly } from './stdio.mjs';

const tools = JSON.parse(fs.readFileSync(process.env.MOLLY_TOOLS_FILE, 'utf8'));
serveStdio({
  name: 'molly-page',
  listTools: () => tools.map(t => ({ name: t.name, description: t.description || '', inputSchema: t.inputSchema || { type: 'object', properties: {} } })),
  callTool: async (name, args) => {
    if (!tools.some(t => t.name === name)) throw new Error('Unknown tool ' + name);
    const r = await molly('/api/bridge/call', { sampleId: process.env.MOLLY_SAMPLE_ID, name, args });
    if (r.isError) throw new Error(r.text || 'The tool failed');
    return r.text;
  },
});

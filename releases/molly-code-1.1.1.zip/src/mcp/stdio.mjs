// Minimal MCP server over stdio (JSON-RPC, one message per line). No dependencies.
import readline from 'node:readline';

export function serveStdio({ name, version = '1.0.0', listTools, callTool, instructions }) {
  const send = msg => process.stdout.write(JSON.stringify(msg) + '\n');
  const rl = readline.createInterface({ input: process.stdin });
  rl.on('line', async line => {
    let msg; try { msg = JSON.parse(line); } catch { return; }
    const { id, method, params } = msg;
    if (id === undefined || id === null) return; // notifications
    try {
      if (method === 'initialize') return send({ jsonrpc: '2.0', id, result: { protocolVersion: params?.protocolVersion || '2025-06-18', capabilities: { tools: {} }, serverInfo: { name, version }, ...(instructions ? { instructions } : {}) } });
      if (method === 'ping') return send({ jsonrpc: '2.0', id, result: {} });
      if (method === 'tools/list') return send({ jsonrpc: '2.0', id, result: { tools: await listTools() } });
      if (method === 'tools/call') {
        try {
          const out = await callTool(params?.name, params?.arguments || {});
          const text = typeof out === 'string' ? out : JSON.stringify(out ?? null, null, 1);
          return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text }] } });
        } catch (e) {
          return send({ jsonrpc: '2.0', id, result: { isError: true, content: [{ type: 'text', text: String(e?.message || e) }] } });
        }
      }
      if (method === 'resources/list') return send({ jsonrpc: '2.0', id, result: { resources: [] } });
      if (method === 'prompts/list') return send({ jsonrpc: '2.0', id, result: { prompts: [] } });
      send({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Method not found' } });
    } catch (e) { send({ jsonrpc: '2.0', id, error: { code: -32603, message: String(e?.message || e) } }); }
  });
  rl.on('close', () => process.exit(0));
}

// Call Molly's local server (address and secret come from the environment).
export async function molly(pathname, body) {
  const r = await fetch(process.env.MOLLY_URL + pathname, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-molly-token': process.env.MOLLY_TOKEN || '' },
    body: JSON.stringify(body || {}),
  });
  const text = await r.text();
  let j; try { j = JSON.parse(text); } catch { j = { error: text }; }
  if (!r.ok || j.error) throw new Error(j.message || j.error || ('HTTP ' + r.status));
  return j;
}

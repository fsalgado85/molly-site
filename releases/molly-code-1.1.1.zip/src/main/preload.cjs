// Bridge between the Molly page / setup wizard and the app (contextIsolation on, sandboxed).
const { contextBridge, ipcRenderer } = require('electron');

const listeners = new Set();
ipcRenderer.on('stt:event', (_e, ev) => { for (const fn of listeners) { try { fn(ev); } catch {} } });

contextBridge.exposeInMainWorld('mollyNative', {
  isApp: true,
  platform: process.platform,
  stt: {
    audio: samples => ipcRenderer.send('stt:audio', samples),
    sessionStart: opts => ipcRenderer.invoke('stt:start', opts || {}),
    sessionStop: opts => ipcRenderer.invoke('stt:stop', opts || {}),
    onEvent: fn => { listeners.add(fn); return () => listeners.delete(fn); },
  },
  setup: {
    done: () => ipcRenderer.invoke('setup:done'),
    voices: () => ipcRenderer.invoke('setup:voices'),
  },
  log: (level, msg) => ipcRenderer.send('renderer:log', level, String(msg).slice(0, 2000)),
});

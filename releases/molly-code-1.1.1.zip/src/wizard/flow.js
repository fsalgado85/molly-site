/* Setup wizard flow: which screen comes next and what each screen still needs.
   Pure logic, shared by the wizard page and the unit tests. */
(function (root) {
  'use strict';
  const STEPS = [
    { id: 'welcome', title: 'Welcome' },
    { id: 'brain', title: "Molly's brain" },
    { id: 'claude', title: 'Sign in to Claude' },
    { id: 'google', title: 'Connect Google' },
    { id: 'settings', title: 'Your settings' },
    { id: 'mic', title: 'Microphone' },
    { id: 'voice', title: 'Voice' },
    { id: 'launch', title: 'Ready' },
  ];

  function stepDone(id, s, local) {
    s = s || {}; local = local || {};
    switch (id) {
      case 'welcome': return !!local.started;
      case 'brain': return !!(s.claude && s.claude.installed);
      case 'claude': return !!(s.claude && s.claude.loggedIn);
      case 'google': return !!(s.google && s.google.connected) || !!local.skipGoogle;
      case 'settings': return !!(s.profile && s.profile.firstName && local.settingsSaved !== false && (local.settingsSaved || s.setupDone));
      case 'mic': return s.mic === 'granted' || !!local.skipMic;
      case 'voice': return !!s.models || !!local.skipVoice;
      case 'launch': return !!s.setupDone;
    }
    return false;
  }

  // Can the person move on from this screen? (Some screens are required, others can be skipped.)
  function canContinue(id, s, local) {
    if (id === 'brain' || id === 'claude') return stepDone(id, s, local);
    if (id === 'settings') return !!(local && local.settingsSaved);
    return true;
  }

  function firstIncomplete(s, local) {
    for (let i = 0; i < STEPS.length; i++) if (!stepDone(STEPS[i].id, s, local)) return i;
    return STEPS.length - 1;
  }

  function progress(s, local) {
    const done = STEPS.filter(x => x.id !== 'launch' && stepDone(x.id, s, local)).length;
    return done / (STEPS.length - 1);
  }

  function fmtBytes(n) {
    if (!(n > 0)) return '0 MB';
    return n > 1e9 ? (n / 1e9).toFixed(1) + ' GB' : (n / 1e6).toFixed(n > 1e7 ? 0 : 1) + ' MB';
  }

  // Default answers for the settings screen from what we know already.
  function defaults(s) {
    s = s || {}; const p = Object.assign({}, s.profile || {});
    if (!p.email && s.google && s.google.email) p.email = s.google.email;
    if (!p.assistantName) p.assistantName = 'Molly';
    if (!p.timeZone) p.timeZone = s.systemTimeZone || 'Europe/London';
    if (!p.clocks || !p.clocks.length) p.clocks = [{ tz: 'America/New_York' }, { tz: 'Europe/London' }, { tz: 'Asia/Singapore' }];
    if (!p.markets) p.markets = [{ name: 'S&P 500', sym: 'SPX', query: 'S&P 500 index' }, { name: 'GBP–EUR', sym: 'GBPEUR', query: 'GBP to EUR' }, { name: 'GBP–USD', sym: 'GBPUSD', query: 'GBP to USD' }];
    if (!p.newsTopics) p.newsTopics = [];
    if (!p.oneDriveRoot && s.onedrive && s.onedrive.root) p.oneDriveRoot = s.onedrive.root;
    if ((!p.folders || !p.folders.length) && s.onedrive && s.onedrive.folders) p.folders = s.onedrive.folders;
    if (p.wakeWord === undefined) p.wakeWord = true;
    return p;
  }

  // British voices first (Daniel, Kate, Serena, Arthur, Martha…), novelty voices out.
  const NOVELTY = /\b(Albert|Bad News|Bahh|Bells|Boing|Bubbles|Cellos|Good News|Jester|Organ|Superstar|Trinoids|Whisper|Wobble|Zarvox|Fred|Junior|Kathy|Ralph|Grandma|Grandpa|Eddy|Flo|Reed|Rocko|Sandy|Shelley)\b/;
  function sortVoices(voices) {
    return (voices || []).filter(v => /^en/i.test(v.lang) && !NOVELTY.test(v.name))
      .sort((a, b) => (b.lang === 'en-GB') - (a.lang === 'en-GB') || (/premium|enhanced/i.test(b.name)) - (/premium|enhanced/i.test(a.name)) || a.name.localeCompare(b.name));
  }

  const api = { STEPS, stepDone, canContinue, firstIncomplete, progress, fmtBytes, defaults, sortVoices };
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.WizardFlow = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);

/* Molly setup wizard (runs inside Molly.app). */
(function () {
  'use strict';
  const F = window.WizardFlow;
  const $ = id => document.getElementById(id);
  const TOKEN = new URLSearchParams(location.search).get('t') || '';
  const H = { 'content-type': 'application/json', 'x-molly-token': TOKEN };
  const api = {
    get: p => fetch('/api/setup/' + p, { headers: H }).then(r => r.json()),
    post: (p, b) => fetch('/api/setup/' + p, { method: 'POST', headers: H, body: JSON.stringify(b || {}) }).then(async r => { const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.message || 'Something went wrong'), j); return j; }),
  };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let S = {};                 // server state
  const L = { started: false }; // local answers
  let cur = 0;

  function show(el, on) { el.hidden = !on; }
  function err(id, msg) { const e = $(id); e.textContent = msg || ''; show(e, !!msg); }
  function setStatus(id, cls, text) { const el = $(id); el.className = 'status ' + (cls || ''); el.lastElementChild.textContent = text; }
  function names() { const n = (S.profile && S.profile.assistantName) || 'Molly'; document.querySelectorAll('.aname').forEach(x => (x.textContent = n)); $('brandName').textContent = n; }

  async function refresh() { S = await api.get('state'); names(); paintSteps(); return S; }

  function paintSteps() {
    $('steps').innerHTML = F.STEPS.map((s, i) => `<li class="${i === cur ? 'cur' : F.stepDone(s.id, S, L) ? 'done' : ''}">${s.title}</li>`).join('');
    $('barFill').style.width = Math.round(F.progress(S, L) * 100) + '%';
  }

  function go(i) {
    cur = Math.max(0, Math.min(F.STEPS.length - 1, i));
    document.querySelectorAll('.screen').forEach(s => s.classList.toggle('on', s.dataset.step === F.STEPS[cur].id));
    paintSteps();
    const enter = ENTER[F.STEPS[cur].id]; if (enter) enter();
    document.querySelector('main').scrollTop = 0;
  }
  function next() { go(cur + 1); }
  document.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b && !b.disabled) { if (b.dataset.go === 'next') { if (F.STEPS[cur].id === 'welcome') L.started = true; next(); } } });

  async function pollJob(id, onTick) {
    for (;;) {
      const j = await fetch('/api/setup/job/' + id, { headers: H }).then(r => r.json());
      onTick(j);
      if (j.state !== 'running') return j;
      await sleep(600);
    }
  }

  /* ---------- screens ---------- */
  const ENTER = {
    brain() {
      const ok = S.claude && S.claude.installed;
      $('brainFill').style.width = ok ? '100%' : '0'; $('brainPct').textContent = ok ? '100%' : '0%';
      $('brainStep').textContent = ok ? `Claude Code is installed${S.claude.version ? ' (' + S.claude.version + ')' : ''}.` : 'Ready to install.';
      $('brainBtn').hidden = ok; $('brainNext').disabled = !ok;
      if (!ok && !L.autoInstall) { L.autoInstall = true; installClaude(); }
    },
    claude() {
      const ok = S.claude && S.claude.loggedIn;
      setStatus('claudeStatus', ok ? 'ok' : '', ok ? `Signed in${S.claude.email ? ' as ' + S.claude.email : ''}${S.claude.subscription ? ' (' + S.claude.subscription + ')' : ''}` : (S.claude && S.claude.viaApiKey ? 'Signed in with an API key: please sign in with your Claude account instead' : 'Not signed in yet'));
      $('claudeNext').disabled = !ok; $('claudeBtn').hidden = ok;
    },
    google() {
      const g = S.google || {};
      $('gClientCard').hidden = !!g.clientConfigured && !L.showClient;
      setStatus('gStatus', g.connected ? 'ok' : '', g.connected ? `Connected${g.email ? ' as ' + g.email : ''}` : 'Not connected');
      $('gBtn').disabled = !g.clientConfigured; $('gBtn').textContent = g.connected ? 'Connect a different account' : 'Connect Google';
      $('gSkip').hidden = !!g.connected;
    },
    settings: fillSettings,
    mic() {
      const ok = S.mic === 'granted';
      setStatus('micStatus', ok ? 'ok' : '', ok ? 'Microphone allowed' : S.mic === 'denied' ? 'Microphone was not allowed' : 'Not allowed yet');
      show($('micHelp'), S.mic === 'denied'); $('micBtn').hidden = ok;
    },
    voice() {
      const ok = !!S.models;
      $('vFill').style.width = ok ? '100%' : '0'; $('vPct').textContent = ok ? '100%' : '0%';
      $('vStep').textContent = ok ? 'Voice files are ready.' : 'Ready to download.';
      $('vBtn').hidden = ok; $('vNext').disabled = !ok; $('vSkip').hidden = ok;
      if (!ok && !L.autoVoice) { L.autoVoice = true; downloadVoice(); }
    },
    launch() {
      const p = S.profile || {};
      $('hiName').textContent = p.firstName || 'there';
      const items = [
        [S.claude && S.claude.loggedIn, 'Claude: signed in with your own plan'],
        [S.google && S.google.connected, S.google && S.google.connected ? 'Google: ' + (S.google.email || 'connected') : 'Google: not connected yet (menu bar → Connect Google…)'],
        [!!p.firstName, `Settings saved for ${p.fullName || p.firstName || 'you'}`],
        [S.mic === 'granted', S.mic === 'granted' ? 'Microphone allowed' : 'Microphone: not allowed (you can still type)'],
        [!!S.models, S.models ? `Voice: say “Hey ${p.assistantName || 'Molly'}”` : 'Voice files: not downloaded yet'],
      ];
      $('summary').innerHTML = items.map(([ok, t]) => `<li class="${ok ? '' : 'skip'}">${esc(t)}</li>`).join('');
    },
  };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---------- 2. install ---------- */
  async function installClaude() {
    err('brainErr'); $('brainBtn').disabled = true;
    try {
      const r = await api.post('install-claude');
      if (r.already) { await refresh(); return ENTER.brain(); }
      const j = await pollJob(r.job, j => {
        const pct = Math.round((j.progress || 0) * 100);
        $('brainFill').style.width = pct + '%'; $('brainPct').textContent = pct + '%';
        $('brainStep').textContent = j.step || 'Installing…';
        $('brainLog').textContent = (j.lines || []).join('\n');
      });
      if (j.state === 'failed') throw new Error(j.error);
      await refresh(); ENTER.brain();
      setTimeout(() => { if (F.STEPS[cur].id === 'brain') next(); }, 900);
    } catch (e) { err('brainErr', e.message + ' You can try again.'); $('brainBtn').textContent = 'Try again'; }
    $('brainBtn').disabled = false;
  }
  $('brainBtn').onclick = installClaude;

  /* ---------- 3. Claude sign-in ---------- */
  let loginJob = null;
  $('claudeBtn').onclick = async () => {
    err('claudeErr'); $('claudeBtn').disabled = true;
    setStatus('claudeStatus', 'wait', 'Waiting for you to sign in on the Claude page…');
    try {
      const r = await api.post('login'); loginJob = r.job;
      let opened = false;
      const watch = pollJob(loginJob, j => {
        if (j.url && !opened) { opened = true; L.loginUrl = j.url; show($('claudeLink'), true); }
        show($('codeBox'), !!j.needsCode || !!j.url);
      });
      // also poll the sign-in status directly (the CLI may keep running for a moment)
      for (let i = 0; i < 400; i++) {
        await sleep(3000);
        await refresh();
        if (S.claude && S.claude.loggedIn) break;
        const j = await fetch('/api/setup/job/' + loginJob, { headers: H }).then(x => x.json());
        if (j.state === 'failed') throw new Error(j.error);
      }
      await watch.catch(() => {});
      ENTER.claude();
      if (S.claude.loggedIn) setTimeout(() => { if (F.STEPS[cur].id === 'claude') next(); }, 900);
    } catch (e) { err('claudeErr', e.message); setStatus('claudeStatus', '', 'Not signed in yet'); }
    $('claudeBtn').disabled = false;
  };
  $('claudeOpen').onclick = e => { e.preventDefault(); if (L.loginUrl) api.post('open-url', { url: L.loginUrl }); };
  $('codeBtn').onclick = async () => { const c = $('codeIn').value.trim(); if (!c || !loginJob) return; await api.post('login-code', { job: loginJob, code: c }); $('codeIn').value = ''; setStatus('claudeStatus', 'wait', 'Checking the code…'); };

  /* ---------- 4. Google ---------- */
  const drop = $('drop');
  async function useClientFile(file) {
    err('gErr');
    try {
      const text = await file.text();
      const st = await api.post('google-client', { json: JSON.parse(text) });
      S.google = st; drop.classList.add('ok'); drop.querySelector('span').textContent = '✓ Google key file added';
      ENTER.google(); $('gClientCard').hidden = false;
    } catch (e) { err('gErr', 'That file did not work: ' + (e.message || e)); }
  }
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) useClientFile(f); });
  $('gFile').onchange = e => { const f = e.target.files[0]; if (f) useClientFile(f); };
  $('gBtn').onclick = async () => {
    err('gErr');
    try {
      await api.post('google-connect');
      setStatus('gStatus', 'wait', 'Finish signing in on the Google page in your browser…');
      for (let i = 0; i < 200; i++) { await sleep(2500); await refresh(); if (S.google.connected) break; }
      ENTER.google();
    } catch (e) { err('gErr', e.message); }
  };
  $('gSkip').onclick = () => { L.skipGoogle = true; next(); };
  if (window.mollyNative) window.mollyNative.stt.onEvent(ev => { if (ev.type === 'google-connected') refresh().then(() => F.STEPS[cur].id === 'google' && ENTER.google()); });

  /* ---------- 5. Settings ---------- */
  const form = $('sForm');
  let P = null;
  function fillSettings() {
    P = F.defaults(S);
    for (const el of form.elements) {
      if (!el.name) continue;
      if (el.type === 'checkbox') el.checked = P[el.name] !== false;
      else if (P[el.name] != null && typeof P[el.name] !== 'object') el.value = P[el.name];
    }
    // clocks
    const zones = (S.presets && S.presets.clocks) || [];
    $('clockSel').innerHTML = [0, 1, 2].map(i => `<select data-clock="${i}">${zones.map(([tz, n]) => `<option value="${tz}"${(P.clocks[i] || {}).tz === tz ? ' selected' : ''}>${esc(n)}</option>`).join('')}</select>`).join('');
    paintMarkets(); paintNews(); paintOneDrive(S.onedrive); fillVoices(); fillCalendars();
  }
  function paintMarkets() {
    const presets = (S.presets && S.presets.markets) || [];
    const all = [...presets, ...P.markets.filter(m => !presets.some(p => p.sym === m.sym))];
    $('mkChips').innerHTML = all.map(m => `<span class="chip${P.markets.some(x => x.sym === m.sym) ? ' on' : ''}" data-sym="${esc(m.sym)}">${esc(m.name)}</span>`).join('');
  }
  $('mkChips').onclick = e => {
    const c = e.target.closest('.chip'); if (!c) return;
    const sym = c.dataset.sym; const i = P.markets.findIndex(m => m.sym === sym);
    if (i >= 0) P.markets.splice(i, 1);
    else { if (P.markets.length >= 8) return err('sErr', 'Up to 8 markets.'); const m = [...(S.presets.markets || []), ...P.markets].find(x => x.sym === sym); if (m) P.markets.push(m); }
    err('sErr'); paintMarkets();
  };
  $('mkAdd').onclick = () => {
    const name = $('mkName').value.trim(), sym = $('mkSym').value.trim().toUpperCase();
    if (!name || !sym) return;
    if (P.markets.length >= 8) return err('sErr', 'Up to 8 markets.');
    if (!P.markets.some(m => m.sym === sym)) P.markets.push({ name, sym, query: `${name} ${sym}` });
    $('mkName').value = $('mkSym').value = ''; paintMarkets();
  };
  function paintNews() { $('nwChips').innerHTML = P.newsTopics.map((t, i) => `<span class="chip on" data-i="${i}">${esc(t)} <span class="x">✕</span></span>`).join('') || '<span class="muted small">No topics yet.</span>'; }
  $('nwChips').onclick = e => { const c = e.target.closest('.chip'); if (!c) return; P.newsTopics.splice(+c.dataset.i, 1); paintNews(); };
  function addNews() {
    const parts = $('nwIn').value.split(',').map(s => s.trim()).filter(Boolean);
    for (const t of parts) { if (P.newsTopics.length >= 8) { err('sErr', 'Up to 8 news topics.'); break; } if (!P.newsTopics.includes(t)) P.newsTopics.push(t); }
    $('nwIn').value = ''; paintNews();
  }
  $('nwAdd').onclick = addNews;
  $('nwIn').onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); addNews(); } };
  function paintOneDrive(od) {
    od = od || {};
    $('odRoot').value = P.oneDriveRoot || od.root || '';
    P.oneDriveRoot = $('odRoot').value;
    if (od.folders) P.folders = od.folders;
    $('odInfo').textContent = P.oneDriveRoot ? (P.folders && P.folders.length ? `Top-level folders: ${P.folders.slice(0, 12).join(', ')}${P.folders.length > 12 ? '…' : ''}` : 'No folders found inside.') : 'OneDrive was not found on this Mac. You can choose a folder, or skip this.';
  }
  $('odBtn').onclick = async () => { const r = await api.post('choose-folder', { defaultPath: P.oneDriveRoot }); if (!r.cancelled) { P.oneDriveRoot = r.root; P.folders = r.folders; paintOneDrive(r); } };
  $('pcBtn').onclick = async () => {
    const pc = form.elements.postcode.value; $('pcInfo').textContent = 'Looking up…';
    try {
      const r = await api.post('postcode', { postcode: pc });
      form.elements.postcode.value = r.postcode;
      if (!form.elements.town.value) form.elements.town.value = r.town || r.district || '';
      P.lat = r.lat; P.lon = r.lon; P.weatherUrl = r.weatherUrl; P.area = [r.town, r.district].filter((v, i, a) => v && a.indexOf(v) === i).join(', ');
      $('pcInfo').textContent = `Found ${r.town || r.district}. Weather will come from the Met Office for this spot.`;
    } catch (e) { $('pcInfo').textContent = 'Postcode not found. Check it and try again (weather can be set later).'; }
  };
  function fillVoices() {
    const sel = $('voiceSel');
    const paint = () => {
      const vs = F.sortVoices(speechSynthesis.getVoices());
      if (!vs.length) { sel.innerHTML = '<option value="">System default</option>'; return; }
      sel.innerHTML = vs.map(v => `<option value="${esc(v.name)}">${esc(v.name)} (${v.lang})</option>`).join('');
      sel.value = P.voiceName && vs.some(v => v.name === P.voiceName) ? P.voiceName : (vs.find(v => /Daniel|Serena|Kate|Arthur|Martha/.test(v.name)) || vs[0]).name;
    };
    paint(); speechSynthesis.onvoiceschanged = paint;
  }
  $('voiceTest').onclick = () => {
    const v = speechSynthesis.getVoices().find(x => x.name === $('voiceSel').value);
    const u = new SpeechSynthesisUtterance(`Hello${form.elements.firstName.value ? ' ' + form.elements.firstName.value : ''}, I'm ${form.elements.assistantName.value || 'Molly'}. Nice to meet you.`);
    if (v) u.voice = v; u.lang = (v && v.lang) || 'en-GB'; speechSynthesis.cancel(); speechSynthesis.speak(u);
  };
  async function fillCalendars() {
    if (!(S.google && S.google.connected)) return;
    try {
      const r = await fetch('/api/mcp/call', { method: 'POST', headers: H, body: JSON.stringify({ server: 'Google Calendar', tool: 'list_calendars', args: {} }) }).then(x => x.json());
      const cals = (r.structuredContent && r.structuredContent.calendars || []).filter(c => !c.primary);
      $('famCal').innerHTML = '<option value="">None</option>' + cals.map(c => `<option value="${esc(c.id)}">${esc(c.summary)}</option>`).join('');
      const fam = cals.find(c => /family/i.test(c.summary));
      $('famCal').value = P.familyCalendar || (fam ? fam.id : '');
    } catch {}
  }
  form.elements.assistantName.oninput = () => { document.querySelectorAll('.aname').forEach(x => (x.textContent = form.elements.assistantName.value || 'Molly')); };
  $('sSave').onclick = async () => {
    err('sErr');
    const fd = {};
    for (const el of form.elements) if (el.name) fd[el.name] = el.type === 'checkbox' ? el.checked : el.value;
    const body = { ...P, ...fd, clocks: [...document.querySelectorAll('[data-clock]')].map(s => ({ tz: s.value })), markets: P.markets, newsTopics: P.newsTopics, folders: P.folders || [], oneDriveRoot: P.oneDriveRoot || '' };
    form.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
    try {
      await api.post('profile', body);
      L.settingsSaved = true; await refresh(); next();
    } catch (e) {
      const errs = e.errors || {};
      for (const k of Object.keys(errs)) if (form.elements[k]) form.elements[k].classList.add('bad');
      err('sErr', Object.values(errs).join('. ') || e.message);
    }
  };

  /* ---------- 6. Mic ---------- */
  $('micBtn').onclick = async () => {
    const r = await api.post('mic');
    if (r.granted) { try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach(t => t.stop()); } catch {} }
    await refresh(); ENTER.mic();
    if (S.mic === 'granted') setTimeout(() => { if (F.STEPS[cur].id === 'mic') next(); }, 700);
  };
  $('micNext').onclick = () => { if (S.mic !== 'granted') L.skipMic = true; };

  /* ---------- 7. Voice download ---------- */
  async function downloadVoice() {
    err('vErr'); $('vBtn').disabled = true;
    try {
      const r = await api.post('models');
      if (!r.already) {
        const j = await pollJob(r.job, j => {
          const pct = Math.round((j.progress || 0) * 100);
          $('vFill').style.width = pct + '%'; $('vPct').textContent = pct + '%';
          $('vStep').textContent = (j.step || 'Downloading…') + (j.total ? ` ${F.fmtBytes(j.bytes)} of ${F.fmtBytes(j.total)}` : '');
        });
        if (j.state === 'failed') throw new Error(j.error);
      }
      await refresh(); ENTER.voice();
      setTimeout(() => { if (F.STEPS[cur].id === 'voice') next(); }, 900);
    } catch (e) { err('vErr', (e.message || 'Download failed') + ' Check your internet connection and try again.'); $('vBtn').textContent = 'Try again'; }
    $('vBtn').disabled = false;
  }
  $('vBtn').onclick = downloadVoice;
  $('vSkip').onclick = () => { L.skipVoice = true; next(); };

  /* ---------- 8. Launch ---------- */
  $('launchBtn').onclick = async () => { $('launchBtn').disabled = true; await api.post('finish'); };

  /* ---------- start ---------- */
  refresh().then(() => {
    if (S.setupDone) { L.started = true; L.settingsSaved = true; }
    go(S.setupDone ? 0 : 0);
  }).catch(e => { document.body.insertAdjacentHTML('beforeend', `<p class="err" style="position:fixed;bottom:20px;left:20px">Could not reach Molly: ${esc(e.message)}</p>`); });
})();

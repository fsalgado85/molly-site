/* Molly.app: SpeechRecognition polyfill backed by on-device speech recognition
   (Silero VAD + Moonshine in Molly's main process), plus "Hey Molly" wake mode.
   Electron's built-in webkitSpeechRecognition does not work, so this replaces it. */
(function () {
  'use strict';
  const N = window.mollyNative && window.mollyNative.stt;
  if (!N) return; // not inside Molly.app: leave the page's normal fallbacks alone

  /* ---------- microphone capture (shared by recognition sessions and wake mode) ---------- */
  const cap = { ctx: null, stream: null, node: null, users: new Set(), starting: null, denied: false };
  async function acquire(who) {
    cap.users.add(who);
    if (cap.ctx) return;
    if (cap.starting) return cap.starting;
    cap.starting = (async () => {
      try {
        cap.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      } catch (e) { cap.users.delete(who); cap.denied = true; throw e; }
      cap.ctx = new AudioContext({ latencyHint: 'interactive' });
      await cap.ctx.audioWorklet.addModule('/molly/audio-worklet.js');
      const src = cap.ctx.createMediaStreamSource(cap.stream);
      cap.node = new AudioWorkletNode(cap.ctx, 'molly-capture');
      cap.node.port.onmessage = ev => {
        // don't transcribe Molly's own voice
        if (window.speechSynthesis && speechSynthesis.speaking) return;
        N.audio(ev.data);
      };
      src.connect(cap.node);
      // keep the graph running without playing the mic back
      const mute = cap.ctx.createGain(); mute.gain.value = 0; cap.node.connect(mute).connect(cap.ctx.destination);
    })();
    try { await cap.starting; } finally { cap.starting = null; }
  }
  function release(who) {
    cap.users.delete(who);
    if (cap.users.size || !cap.ctx) return;
    try { cap.stream.getTracks().forEach(t => t.stop()); } catch {}
    try { cap.ctx.close(); } catch {}
    cap.ctx = cap.stream = cap.node = null;
  }

  /* ---------- SpeechRecognition ---------- */
  let current = null;       // the active recognition object
  let wakeText = null;      // words said after "Hey Molly", delivered to the next session

  function mkResult(transcript, isFinal) {
    const alt = { transcript, confidence: isFinal ? 0.9 : 0.1 };
    const r = [alt]; r.isFinal = isFinal; r.item = i => r[i];
    return r;
  }
  function mkList(arr) { const l = arr.slice(); l.item = i => l[i]; return l; }

  class MollySpeechRecognition extends EventTarget {
    constructor() {
      super();
      this.continuous = false; this.interimResults = false; this.lang = 'en-GB'; this.maxAlternatives = 1; this.grammars = null;
      this.onresult = this.onend = this.onerror = this.onstart = this.onspeechstart = this.onspeechend = this.onaudiostart = this.onaudioend = this.onsoundstart = this.onsoundend = this.onnomatch = null;
      this._active = false; this._results = []; this._interim = false; this._timer = null;
    }
    _fire(type, props) {
      const ev = new Event(type); if (props) Object.assign(ev, props);
      try { this.dispatchEvent(ev); } catch {}
      const h = this['on' + type]; if (typeof h === 'function') { try { h.call(this, ev); } catch (e) { console.error(e); } }
    }
    async start() {
      if (this._active) { const e = new Error('recognition has already started'); e.name = 'InvalidStateError'; throw e; }
      this._active = true; this._results = []; this._interim = false;
      if (current && current !== this) current.abort();
      current = this;
      try { await acquire(this); }
      catch (e) { this._active = false; current = null; this._fire('error', { error: 'not-allowed', message: 'Microphone access was not allowed.' }); this._fire('end'); return; }
      if (!this._active) return; // aborted while starting
      const ok = await N.sessionStart({ continuous: this.continuous });
      if (!ok || !ok.ready) {
        this._active = false; current = null; release(this);
        this._fire('error', { error: 'service-not-allowed', message: (ok && ok.message) || 'Molly\'s voice files are not installed yet.' });
        this._fire('end'); return;
      }
      this._fire('start'); this._fire('audiostart');
      this._armNoSpeech();
      if (wakeText && Date.now() - wakeText.at < 8000) { const t = wakeText.text; wakeText = null; setTimeout(() => this._final(t), 50); }
    }
    _armNoSpeech() {
      clearTimeout(this._timer);
      if (this.continuous) return;
      this._timer = setTimeout(() => { if (this._active && !this._results.length) { this._fire('error', { error: 'no-speech' }); this._end(); } }, 8000);
    }
    _speech() {
      if (!this._active) return;
      clearTimeout(this._timer);
      this._fire('soundstart'); this._fire('speechstart');
      if (this.interimResults) {
        if (!this._interim) { this._results.push(mkResult('…', false)); this._interim = true; }
        this._fire('result', { resultIndex: this._results.length - 1, results: mkList(this._results) });
      }
    }
    _final(text) {
      if (!this._active) return;
      text = String(text || '').trim();
      if (this._interim) { this._results.pop(); this._interim = false; }
      if (!text) { if (this.interimResults) this._fire('result', { resultIndex: this._results.length, results: mkList(this._results) }); return; }
      this._results.push(mkResult((this._results.length ? ' ' : '') + text, true));
      this._fire('speechend'); this._fire('soundend');
      this._fire('result', { resultIndex: this._results.length - 1, results: mkList(this._results) });
      if (!this.continuous) this._end(); else this._armNoSpeech();
    }
    stop() {
      if (!this._active) return;
      // finish the current utterance, then end
      N.sessionStop({ flush: true }).then(() => this._end());
    }
    abort() {
      if (!this._active) return;
      N.sessionStop({ flush: false });
      this._end();
    }
    _end() {
      if (!this._active) return;
      this._active = false; clearTimeout(this._timer);
      if (current === this) current = null;
      N.sessionStop({ flush: false });
      release(this);
      this._fire('audioend');
      this._fire('end');
    }
  }

  N.onEvent(ev => {
    if (ev.type === 'speech' && current) current._speech();
    else if (ev.type === 'final' && current) current._final(ev.text);
    else if (ev.type === 'silence' && current && current._interim) current._final('');
    else if (ev.type === 'wake') onWake(ev.rest || '');
    else if (ev.type === 'wake-mode') setWake(!!ev.on);
  });

  window.SpeechRecognition = MollySpeechRecognition;
  window.webkitSpeechRecognition = MollySpeechRecognition;

  /* ---------- "Hey Molly" ---------- */
  function chime() {
    try {
      const c = new AudioContext(); const t = c.currentTime;
      [[880, 0], [1320, 0.12]].forEach(([f, d]) => {
        const o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.25, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.25);
        o.connect(g).connect(c.destination); o.start(t + d); o.stop(t + d + 0.3);
      });
      setTimeout(() => c.close(), 800);
    } catch {}
  }
  function visible(el) { return el && !el.hidden && el.offsetParent !== null; }
  function onWake(rest) {
    chime();
    if (current) { if (rest) current._final(rest); return; }
    wakeText = rest ? { text: rest, at: Date.now() } : null;
    // start the page's own microphone flow (it handles "say end to send" and hands-free mode)
    const btn = ['hMic', 'vmTalk', 'micBtn'].map(id => document.getElementById(id)).find(visible) || document.getElementById('micBtn');
    if (btn) btn.click();
  }
  let wakeOn = false;
  async function setWake(on) {
    if (on === wakeOn) return;
    wakeOn = on;
    if (on) { try { await acquire('wake'); } catch { wakeOn = false; } }
    else release('wake');
  }
  window.__mollySpeech = { setWake, onWake, get capturing() { return !!cap.ctx; } };
})();

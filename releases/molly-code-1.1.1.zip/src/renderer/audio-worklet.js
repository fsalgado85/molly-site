// Captures microphone audio, downsamples to 16 kHz mono and posts 100 ms Float32 chunks.
class MollyCapture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ratio = sampleRate / 16000;
    this.pos = 0;           // fractional read position into the incoming stream
    this.out = new Float32Array(1600);
    this.n = 0;
    this.prev = 0;
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;
    if (this.ratio === 1) { for (let i = 0; i < ch.length; i++) this.push(ch[i]); return true; }
    // box-filter decimation: average the input samples that fall into each 1/16000 s output slot
    for (let i = 0; i < ch.length; i++) {
      this.sum = (this.sum || 0) + ch[i]; this.cnt = (this.cnt || 0) + 1;
      this.pos += 1;
      if (this.pos >= this.ratio) { this.push(this.sum / this.cnt); this.sum = 0; this.cnt = 0; this.pos -= this.ratio; }
    }
    return true;
  }
  push(v) {
    this.out[this.n++] = v;
    if (this.n === this.out.length) { this.port.postMessage(this.out.slice(0)); this.n = 0; }
  }
}
registerProcessor('molly-capture', MollyCapture);

/* Molly.app shim: provides window.claude.use("db" | "mcp" | "sample" | "assets" | "downloads")
   backed by Molly's local server, so the original Molly page runs unchanged. See PLAN.md §3. */
(function () {
  'use strict';
  const BOOT = window.__MOLLY_BOOT || {};
  const TOKEN = BOOT.token || new URLSearchParams(location.search).get('t') || '';
  const H = { 'content-type': 'application/json', 'x-molly-token': TOKEN };

  async function post(path, body) {
    const r = await fetch(path, { method: 'POST', headers: H, body: JSON.stringify(body || {}) });
    let j = null; try { j = await r.json(); } catch {}
    if (!r.ok || (j && j.error)) throw mkErr(j, r.status);
    return j;
  }
  function mkErr(j, status) {
    const e = new Error((j && j.message) || ('HTTP ' + status));
    e.code = (j && (j.code || j.error)) || 'error';
    if (j && j.server) e.server = true;
    return e;
  }

  /* ------------------------------ db ------------------------------ */
  const subs = new Set(); // {kind:'doc'|'col', path, refresh}
  let es = null, esRetry = 1000;
  function ensureEvents() {
    if (es) return;
    es = new EventSource('/api/db/events?t=' + encodeURIComponent(TOKEN));
    es.onmessage = ev => {
      let c; try { c = JSON.parse(ev.data); } catch { return; }
      for (const s of subs) {
        if ((s.kind === 'doc' && s.path === c.path) || (s.kind === 'col' && s.path === c.collection)) s.refresh();
      }
    };
    es.onopen = () => { esRetry = 1000; };
    es.onerror = () => {
      // reconnect and refresh everything (we may have missed changes)
      try { es.close(); } catch {}
      es = null;
      setTimeout(() => { ensureEvents(); for (const s of subs) s.refresh(); }, esRetry);
      esRetry = Math.min(esRetry * 2, 15000);
    };
  }
  const clean = p => String(p || '').split('/').filter(Boolean).join('/');
  function docSnap(path, r) {
    const id = path.split('/').pop();
    const data = r && r.exists ? r.data : undefined;
    return { id, exists: !!(r && r.exists), ref: docRef(path), data: () => (data === undefined ? undefined : structuredClone(data)), get: f => (data ? data[f] : undefined) };
  }
  function querySnap(colPath, docs) {
    const list = docs.map(d => docSnap(colPath + '/' + d.id, { exists: true, data: d.data }));
    return { docs: list, empty: !list.length, size: list.length, forEach: fn => list.forEach(fn) };
  }
  function debounceAsync(fn) {
    let running = false, again = false;
    return async function run() {
      if (running) { again = true; return; }
      running = true;
      try { await fn(); } finally { running = false; if (again) { again = false; run(); } }
    };
  }
  function docRef(path) {
    path = clean(path);
    const ref = {
      id: path.split('/').pop(), path,
      get parent() { return collectionRef(path.split('/').slice(0, -1).join('/')); },
      async get() { return docSnap(path, await post('/api/db', { op: 'get', path })); },
      async set(data, opts) { await post('/api/db', { op: 'set', path, data, opts: opts || {} }); },
      async update(data) { await post('/api/db', { op: 'update', path, data }); },
      async delete() { await post('/api/db', { op: 'delete', path }); },
      collection(sub) { return collectionRef(path + '/' + sub); },
      onSnapshot(cb, errCb) {
        if (typeof cb === 'object' && cb && cb.next) { errCb = cb.error; cb = cb.next; }
        let alive = true, last = null;
        const refresh = debounceAsync(async () => {
          if (!alive) return;
          try {
            const r = await post('/api/db', { op: 'get', path });
            const sig = JSON.stringify(r);
            if (!alive || sig === last) return;
            last = sig; cb(docSnap(path, r));
          } catch (e) { if (alive && errCb) errCb(e); }
        });
        const s = { kind: 'doc', path, refresh };
        subs.add(s); ensureEvents(); refresh();
        return () => { alive = false; subs.delete(s); };
      },
    };
    return ref;
  }
  function queryRef(colPath, opts) {
    const q = {
      path: colPath,
      orderBy(field, dir) { return queryRef(colPath, { ...opts, orderBy: field, dir: dir || 'asc' }); },
      limit(n) { return queryRef(colPath, { ...opts, limit: n }); },
      where() { throw Object.assign(new Error('where() is not supported'), { code: 'unimplemented' }); },
      async get() { const r = await post('/api/db', { op: 'list', path: colPath, opts }); return querySnap(colPath, r.docs || []); },
      onSnapshot(cb, errCb) {
        if (typeof cb === 'object' && cb && cb.next) { errCb = cb.error; cb = cb.next; }
        let alive = true, last = null;
        const refresh = debounceAsync(async () => {
          if (!alive) return;
          try {
            const r = await post('/api/db', { op: 'list', path: colPath, opts });
            const sig = JSON.stringify(r.docs);
            if (!alive || sig === last) return;
            last = sig; cb(querySnap(colPath, r.docs || []));
          } catch (e) { if (alive && errCb) errCb(e); }
        });
        const s = { kind: 'col', path: colPath, refresh };
        subs.add(s); ensureEvents(); refresh();
        return () => { alive = false; subs.delete(s); };
      },
    };
    return q;
  }
  function autoId() { const a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; let s = ''; const b = crypto.getRandomValues(new Uint8Array(20)); for (const x of b) s += a[x % a.length]; return s; }
  function collectionRef(path) {
    path = clean(path);
    const base = queryRef(path, {});
    return Object.assign(base, {
      id: path.split('/').pop(),
      doc(id) { return docRef(path + '/' + (id || autoId())); },
      async add(data) { const r = await post('/api/db', { op: 'add', path, data }); return docRef(path + '/' + r.id); },
    });
  }
  const db = { doc: docRef, collection: collectionRef };

  /* ------------------------------ mcp ------------------------------ */
  const mcp = {
    async callTool(server, tool, args, opts) {
      const r = await fetch('/api/mcp/call', { method: 'POST', headers: H, body: JSON.stringify({ server, tool, args: args || {} }) });
      let j = null; try { j = await r.json(); } catch {}
      if (!r.ok || !j || j.error) { const e = mkErr(j, r.status); e.server = true; throw e; }
      return j; // {structuredContent}
    },
  };

  /* ------------------------------ sample ------------------------------ */
  async function blobToB64(b) {
    if (typeof b === 'string') { const m = b.match(/^data:([^;]+);base64,(.*)$/); return m ? { mime: m[1], b64: m[2] } : { mime: 'image/png', b64: b }; }
    if (b && b.data && b.mediaType) return { mime: b.mediaType, b64: b.data };
    const buf = new Uint8Array(await b.arrayBuffer());
    let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
    return { mime: b.type || 'image/png', b64: btoa(s) };
  }
  async function runSample(turnsOrPrompt, opts) {
    opts = opts || {};
    const tools = Array.isArray(opts.tools) ? opts.tools : [];
    const byName = Object.fromEntries(tools.map(t => [t.name, t]));
    const images = opts.images && opts.images.length ? await Promise.all([...opts.images].slice(0, 5).map(blobToB64)) : [];
    const body = {
      turns: typeof turnsOrPrompt === 'string' ? undefined : turnsOrPrompt,
      prompt: typeof turnsOrPrompt === 'string' ? turnsOrPrompt : undefined,
      tools: tools.map(t => ({ name: t.name, description: t.description || '', inputSchema: t.inputSchema || t.input_schema || { type: 'object', properties: {} } })),
      modelTier: opts.modelTier || 'default', images, json: !!opts.json,
    };
    const ctrl = new AbortController();
    if (opts.signal) { if (opts.signal.aborted) ctrl.abort(); else opts.signal.addEventListener('abort', () => ctrl.abort(), { once: true }); }
    let r;
    try { r = await fetch('/api/sample', { method: 'POST', headers: H, body: JSON.stringify(body), signal: ctrl.signal }); }
    catch (e) { if (ctrl.signal.aborted) throw abortErr(); throw Object.assign(new Error('Molly could not reach Claude: ' + e.message), { code: 'network' }); }
    if (!r.ok) { let j = null; try { j = await r.json(); } catch {} throw mkErr(j, r.status); }
    const reader = r.body.getReader(); const dec = new TextDecoder();
    let buf = '', text = '', final = null, failure = null;
    const handle = async ev => {
      if (ev.type === 'text') { text = ev.text; if (opts.onText) { try { opts.onText({ text, delta: ev.delta }); } catch {} } }
      else if (ev.type === 'tool_call') {
        const t = byName[ev.name]; let result, error;
        try { if (!t || typeof t.execute !== 'function') throw new Error('Unknown tool ' + ev.name); result = await t.execute(ev.args || {}); }
        catch (e) { error = (e && (e.message || e.code)) || String(e); }
        try { await post('/api/bridge/result', { callId: ev.callId, sampleId: ev.sid, result: result === undefined ? 'done' : result, error }); } catch {}
      } else if (ev.type === 'done') final = ev.text;
      else if (ev.type === 'error') failure = ev;
    };
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i); buf = buf.slice(i + 1);
          if (!line.trim()) continue;
          let ev; try { ev = JSON.parse(line); } catch { continue; }
          handle(ev); // tool calls run in the background so the stream keeps flowing
        }
      }
    } catch (e) { if (ctrl.signal.aborted) throw abortErr(); throw e; }
    if (ctrl.signal.aborted) throw abortErr();
    if (failure) throw Object.assign(new Error(failure.message || 'Claude failed'), { code: failure.code || 'error' });
    return { text: final != null ? final : text };
  }
  function abortErr() { const e = new Error('Aborted'); e.name = 'AbortError'; e.code = 'aborted'; return e; }
  function parseJsonLoose(t) {
    t = String(t || '').trim();
    const f = t.match(/```(?:json)?\s*([\s\S]*?)```/i); if (f) t = f[1].trim();
    try { return JSON.parse(t); } catch {}
    const s = t.search(/[[{]/);
    if (s >= 0) { const close = t[s] === '{' ? '}' : ']'; const e = t.lastIndexOf(close); if (e > s) { try { return JSON.parse(t.slice(s, e + 1)); } catch {} } }
    throw Object.assign(new Error('Claude did not return valid JSON'), { code: 'bad_json' });
  }
  const sample = Object.assign((turns, opts) => runSample(turns, opts), {
    async json(prompt, opts) { const r = await runSample(prompt, { ...(opts || {}), json: true }); return parseJsonLoose(r.text); },
    limits() { return { images: { maxCount: 5 } }; },
  });

  /* ------------------------------ assets / downloads ------------------------------ */
  const assets = {
    async upload(blob, opts) {
      const type = (opts && opts.type) || blob.type || 'application/octet-stream';
      const r = await fetch('/api/assets', { method: 'POST', headers: { 'content-type': type, 'x-molly-token': TOKEN }, body: blob });
      const j = await r.json().catch(() => null);
      if (!r.ok || !j || j.error) throw mkErr(j, r.status);
      return j;
    },
  };
  const downloads = {
    async save({ filename, data }) {
      let body;
      if (typeof data === 'string') body = { filename, data };
      else { const x = await blobToB64(data instanceof Blob ? data : new Blob([data])); body = { filename, b64: x.b64 }; }
      return post('/api/downloads', body);
    },
  };


  /* ------------------------------ update banner ------------------------------ */
  // A small banner when a new version of Molly has been downloaded (or a reinstall is needed).
  // Molly never restarts by herself while she is speaking or busy; the app waits for a quiet moment.
  const upd = { shown: null, dismissed: {}, el: null };
  const pageBusy = () => { try { return !!(window.speechSynthesis && (speechSynthesis.speaking || speechSynthesis.pending)); } catch { return false; } };
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function updEl() {
    if (upd.el) return upd.el;
    const st = document.createElement('style');
    st.textContent = '#mollyUpdate{position:fixed;right:16px;bottom:16px;z-index:2147483000;max-width:360px;background:#0D2C53;color:#fff;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.35);padding:14px 16px;font:14px/1.4 -apple-system,system-ui,sans-serif}'
      + '#mollyUpdate b{display:block;font-size:15px;margin-bottom:4px}#mollyUpdate .n{opacity:.85;white-space:pre-line;max-height:120px;overflow:auto;margin:4px 0 10px}'
      + '#mollyUpdate button,#mollyUpdate a.b{font:inherit;border:0;border-radius:9px;padding:7px 12px;margin-right:6px;cursor:pointer;text-decoration:none;display:inline-block}'
      + '#mollyUpdate .p{background:#F47C5D;color:#fff;font-weight:600}#mollyUpdate .s{background:rgba(255,255,255,.14);color:#fff}#mollyUpdate .w{opacity:.85;margin-top:8px;font-size:13px}'
      + '@media (max-width:520px){#mollyUpdate{left:12px;right:12px;max-width:none}}';
    document.head.appendChild(st);
    upd.el = document.createElement('div'); upd.el.id = 'mollyUpdate'; upd.el.setAttribute('role', 'status'); upd.el.hidden = true;
    document.body.appendChild(upd.el);
    upd.el.addEventListener('click', async ev => {
      const b = ev.target.closest('button'); if (!b) return;
      if (b.dataset.a === 'later') { upd.dismissed[upd.shown] = Date.now(); upd.el.hidden = true; }
      if (b.dataset.a === 'restart') {
        b.disabled = true; b.textContent = 'Restarting…';
        try {
          const r = await post('/api/update/restart', { busy: pageBusy() });
          if (r && r.waiting) { const w = upd.el.querySelector('.w'); if (w) w.textContent = 'Molly will restart as soon as she has finished ' + r.waiting + '.'; }
        } catch (e) { b.disabled = false; b.textContent = 'Restart Molly'; }
      }
    });
    return upd.el;
  }
  function showUpdate(s) {
    if (!document.body) return;
    const key = s.state + ':' + s.version;
    const later = upd.dismissed[key];
    if (s.state !== 'ready' && s.state !== 'reinstall-needed') { if (upd.el) upd.el.hidden = true; upd.shown = null; return; }
    if (later && Date.now() - later < 6 * 3600e3) return;
    const el = updEl();
    if (upd.shown !== key) {
      const name = (BOOT.profile && BOOT.profile.assistantName) || 'Molly';
      el.innerHTML = s.state === 'ready'
        ? `<b>${esc(name)} ${esc(s.version)} is ready</b>${s.notes ? `<div class="n">${esc(s.notes)}</div>` : ''}<button class="p" data-a="restart">Restart ${esc(name)}</button><button class="s" data-a="later">Later</button><div class="w"></div>`
        : `<b>A one-time reinstall is needed</b><div class="n">${esc(name)} ${esc(s.version)} needs a newer app than the one on this Mac, so it can't update by itself this time.${s.notes ? '\n\n' + esc(s.notes) : ''}</div><a class="b p" href="${esc(s.reinstallUrl || '#')}" target="_blank" rel="noopener">How to reinstall</a><button class="s" data-a="later">Later</button>`;
      upd.shown = key;
    }
    el.hidden = false;
  }
  async function pollUpdate() {
    try { const s = await post('/api/update', { busy: pageBusy() }); if (s) showUpdate(s); } catch {}
  }
  if (window.addEventListener) window.addEventListener('load', () => { setTimeout(pollUpdate, 4000); setInterval(pollUpdate, 60000); });
  window.__mollyUpdate = { poll: pollUpdate, show: showUpdate };

  const apis = { db, mcp, sample, assets, downloads };
  window.claude = Object.assign(window.claude || {}, {
    molly: true,
    async use(name) { return apis[name] || null; },
  });
  window.__mollyShim = { post, parseJsonLoose, TOKEN };
})();

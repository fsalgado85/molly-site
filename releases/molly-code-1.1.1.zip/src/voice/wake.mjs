// "Hey Molly" detection on a finished transcript. Pure functions (unit-tested).
const GREET = ['hey', 'hi', 'ok', 'okay', 'hello', 'oi', 'a', 'hay', 'heh'];

export function wakeNames(assistantName = 'Molly') {
  const n = String(assistantName || 'Molly').trim().toLowerCase();
  const set = new Set([n]);
  if (n === 'molly') ['mollie', 'molley', 'molli', 'holly', 'polly', 'mali', 'mollys', 'moly', 'ollie', 'dolly'].forEach(x => set.add(x));
  return [...set];
}

const norm = s => String(s || '').toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

/** Returns null if this isn't a wake phrase, otherwise { rest } with the words said after the name (original casing). */
export function matchWake(text, assistantName = 'Molly') {
  const t = norm(text);
  if (!t) return null;
  const names = wakeNames(assistantName).map(norm);
  const words = t.split(' ');
  // "hey molly …", "ok molly …", or just "molly, …" at the very start
  let at = -1;
  if (words.length >= 2 && GREET.includes(words[0]) && names.includes(words[1])) at = 2;
  else if (words.length >= 3 && GREET.includes(words[0]) && GREET.includes(words[1]) && names.includes(words[2])) at = 3;
  else if (names.includes(words[0]) && names[0] === words[0]) at = 1; // the exact name alone, no sound-alikes
  if (at < 0) return null;
  // map back to the original text: drop the same number of words
  const orig = String(text).trim().split(/\s+/);
  const rest = orig.slice(at).join(' ').replace(/^[\s,.!?;:-]+/, '').trim();
  return { rest };
}

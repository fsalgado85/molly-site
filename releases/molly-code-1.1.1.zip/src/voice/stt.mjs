// Voice in the main process: owns the speech worker, routes recognised speech to the page's
// recognition session, and listens for "Hey Molly" when no session is open.
import { EventEmitter } from 'node:events';
import { matchWake } from './wake.mjs';

export class SpeechService extends EventEmitter {
  /** spawnWorker(): returns {postMessage(m), on('message', fn(m)), kill()} */
  constructor({ spawnWorker, modelsReady, modelsDir, assistantName = () => 'Molly', wakeEnabled = () => true, log = () => {} }) {
    super();
    Object.assign(this, { spawnWorker, modelsReady, modelsDir, assistantName, wakeEnabled, log });
    this.worker = null; this.ready = false; this.session = null; this.flushWaiters = new Map(); this.seq = 0;
  }
  start() {
    if (this.worker || !this.modelsReady()) return false;
    this.worker = this.spawnWorker();
    this.worker.on('message', m => this.onWorker(m));
    this.worker.on('exit', () => { this.worker = null; this.ready = false; });
    this.worker.postMessage({ type: 'init', modelsDir: this.modelsDir });
    return true;
  }
  stop() { try { this.worker?.kill(); } catch {} this.worker = null; this.ready = false; }
  status() { return { models: this.modelsReady(), running: !!this.worker, ready: this.ready }; }

  onWorker(m) {
    if (m.type === 'ready') { this.ready = true; this.log('voice ready'); this.emit('ready'); }
    else if (m.type === 'error') { this.log('voice error: ' + m.message); }
    else if (m.type === 'speech') { if (this.session) this.emit('event', { type: 'speech' }); }
    else if (m.type === 'silence') { if (this.session) this.emit('event', { type: 'silence' }); }
    else if (m.type === 'flushed') { const w = this.flushWaiters.get(m.id); if (w) { this.flushWaiters.delete(m.id); w(); } }
    else if (m.type === 'segment') this.onSegment(m.text);
  }
  onSegment(text) {
    if (!text) return;
    if (this.session) { this.emit('event', { type: 'final', text }); return; }
    if (!this.wakeEnabled()) return;
    const w = matchWake(text, this.assistantName());
    if (w) { this.log('wake word heard'); this.emit('wake', w); }
  }

  audio(samples) { if (this.worker && this.ready) this.worker.postMessage({ type: 'audio', samples }); }
  sessionStart(opts = {}) {
    if (!this.modelsReady()) return { ready: false, message: 'Molly\'s voice files are not installed yet. Open the menu-bar icon → Set up again… to download them.' };
    if (!this.worker) this.start();
    this.session = { at: Date.now(), continuous: !!opts.continuous };
    this.worker?.postMessage({ type: 'reset' });
    return { ready: true };
  }
  async sessionStop({ flush = false } = {}) {
    if (!this.session) return true;
    if (flush && this.worker && this.ready) {
      const id = ++this.seq;
      await new Promise(res => { this.flushWaiters.set(id, res); this.worker.postMessage({ type: 'flush', id }); setTimeout(res, 4000); });
    }
    this.session = null;
    return true;
  }
}

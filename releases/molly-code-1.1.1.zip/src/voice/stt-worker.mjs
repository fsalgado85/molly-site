// Speech-to-text worker: Silero VAD + Moonshine (sherpa-onnx-node 1.13.8), proven in
// reference/voice-test/. Runs in an Electron utility process (or a Node child process in tests)
// so decoding never blocks the app. Messages in: {type:'init', modelsDir} | {type:'audio', samples}
// | {type:'flush'} | {type:'reset'}. Messages out: {type:'ready'|'error'|'speech'|'silence'|'segment', ...}.
import path from 'node:path';
import { createRequire } from 'node:module';
// The voice engine (a native module) lives in the app bundle; updated code runs from elsewhere.
const requireHere = createRequire(import.meta.url);
const requireShell = process.env.MOLLY_SHELL_DIR ? createRequire(path.join(process.env.MOLLY_SHELL_DIR, 'package.json')) : null;
function loadSherpa() {
  if (requireShell) { try { return requireShell('sherpa-onnx-node'); } catch {} }
  return requireHere('sherpa-onnx-node');
}

const port = process.parentPort || { postMessage: m => process.send(m), on: (ev, fn) => process.on('message', m => fn({ data: m })) };
const send = m => port.postMessage(m);

let s = null, vad = null, rec = null, speaking = false, buf = null;

function init(modelsDir) {
  s = loadSherpa();
  const d = path.join(modelsDir, 'sherpa-onnx-moonshine-base-en-int8');
  rec = new s.OfflineRecognizer({
    featConfig: { sampleRate: 16000, featureDim: 80 },
    modelConfig: { moonshine: { preprocessor: path.join(d, 'preprocess.onnx'), encoder: path.join(d, 'encode.int8.onnx'), uncachedDecoder: path.join(d, 'uncached_decode.int8.onnx'), cachedDecoder: path.join(d, 'cached_decode.int8.onnx') }, tokens: path.join(d, 'tokens.txt'), numThreads: 2, provider: 'cpu', debug: 0 },
  });
  vad = new s.Vad({ sileroVad: { model: path.join(modelsDir, 'silero_vad.onnx'), threshold: 0.5, minSpeechDuration: 0.25, minSilenceDuration: 0.5, maxSpeechDuration: 20, windowSize: 512 }, sampleRate: 16000, numThreads: 1, debug: 0 }, 60);
  buf = new Float32Array(0);
}

function decode(samples) {
  const st = rec.createStream();
  st.acceptWaveform({ sampleRate: 16000, samples });
  rec.decode(st);
  return String(rec.getResult(st).text || '').trim();
}

function drain() {
  while (!vad.isEmpty()) {
    const seg = vad.front(false); vad.pop(); // false: copy the samples (Electron forbids external buffers)
    if (!seg.samples || seg.samples.length < 1600) continue; // under 0.1 s: nothing to decode
    const t0 = Date.now();
    const text = decode(seg.samples);
    send({ type: 'segment', text, ms: Date.now() - t0, seconds: seg.samples.length / 16000 });
  }
}

function audio(samples) {
  // feed in 512-sample windows
  const all = new Float32Array(buf.length + samples.length); all.set(buf); all.set(samples, buf.length);
  let i = 0;
  for (; i + 512 <= all.length; i += 512) vad.acceptWaveform(all.subarray(i, i + 512));
  buf = all.slice(i);
  const now = vad.isDetected();
  if (now && !speaking) { speaking = true; send({ type: 'speech' }); }
  else if (!now && speaking) { speaking = false; send({ type: 'silence' }); }
  drain();
}

port.on('message', ({ data: m }) => {
  try {
    if (m.type === 'init') { init(m.modelsDir); send({ type: 'ready' }); }
    else if (m.type === 'audio') { if (vad) audio(m.samples instanceof Float32Array ? m.samples : Float32Array.from(m.samples)); }
    else if (m.type === 'flush') { if (vad) { vad.flush(); drain(); vad.reset?.(); speaking = false; buf = new Float32Array(0); } send({ type: 'flushed', id: m.id }); }
    else if (m.type === 'reset') { if (vad) { vad.reset?.(); speaking = false; buf = new Float32Array(0); } }
    else if (m.type === 'file') { // test helper: transcribe a wav file through the same VAD path
      let w; try { w = s.readWave(m.file, false); } catch { w = s.readWave(m.file); }
      for (let i = 0; i < w.samples.length; i += 1600) audio(w.samples.subarray(i, i + 1600));
      vad.flush(); drain(); vad.reset?.(); speaking = false; buf = new Float32Array(0); send({ type: 'file-done' });
    }
  } catch (e) { send({ type: 'error', message: String(e && e.message || e) }); }
});

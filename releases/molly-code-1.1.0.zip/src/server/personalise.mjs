// Personalisation: the Molly page and the background-task prompts were written for one person.
// This step swaps his details for the profile chosen in the setup wizard, so each person gets
// their own Molly. Nothing personal is stored in the app; the profile lives in the data folder.
import fs from 'node:fs';

export const DEFAULT_PROFILE = {
  firstName: '', fullName: '', email: '', phone: '', town: '', area: '', postcode: '', address: '',
  pronouns: '', household: '', about: '', timeZone: 'Europe/London',
  assistantName: 'Molly', voiceName: '',
  weatherUrl: '', weatherPlace: '', lat: null, lon: null,
  oneDriveRoot: '', folders: [], inboxFolder: '',
  clocks: [{ tz: 'America/New_York' }, { tz: 'Europe/London' }, { tz: 'Asia/Singapore' }],
  markets: [
    { name: 'S&P 500', sym: 'SPX', query: 'S&P 500 index' },
    { name: 'GBP–EUR', sym: 'GBPEUR', query: 'GBP to EUR' },
    { name: 'GBP–USD', sym: 'GBPUSD', query: 'GBP to USD' },
  ],
  newsTopics: [],
  familyCalendar: '',
  wakeWord: true,
};

export function completeProfile(p = {}) {
  const out = { ...DEFAULT_PROFILE, ...Object.fromEntries(Object.entries(p).filter(([, v]) => v !== undefined && v !== null)) };
  out.fullName = String(out.fullName || '').trim();
  out.firstName = String(out.firstName || out.fullName.split(/\s+/)[0] || 'there').trim();
  const parts = out.fullName.split(/\s+/).filter(Boolean);
  out.lastName = out.lastName || (parts.length > 1 ? parts[parts.length - 1] : '');
  out.area = out.area || [out.town, out.county].filter(Boolean).join(', ');
  out.weatherPlace = out.weatherPlace || out.town || '';
  out.inboxFolder = out.inboxFolder || (out.folders || []).find(f => /inbox/i.test(f)) || (out.folders || [])[0] || 'Inbox';
  return out;
}

const reEsc = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const jsStr = s => JSON.stringify(String(s)).slice(1, -1); // safe inside a "..." JS string literal

export function signOff(p) {
  return ['Kind regards,', p.fullName || p.firstName, p.phone].filter(Boolean).join('\n');
}

// Build a RegExp source that accepts the person's own top-level OneDrive folders.
export function folderRegexSource(folders = []) {
  const list = (folders || []).map(f => String(f).split('/')[0]).filter(Boolean);
  if (!list.length) return '^(?!\\.)[^/]';
  return '^(' + [...new Set(list)].map(reEsc).join('|') + ')(\\/|$)';
}

// Step 1 (at build time, scripts/prepare-artifact.mjs + scripts/templatise.mjs): the original
// owner's details → neutral tokens, so neither the app nor a code update contains anything personal.
// Step 2 (at run time, below): tokens → the person's own profile.

export function tokenValues(profile) {
  const p = completeProfile(profile);
  const name = p.fullName || p.firstName;
  const place = p.area || p.town || 'the UK';
  return {
    __MOLLY_EMAIL_RE__: p.email ? reEsc(p.email) : 'no-email-set\\.invalid',
    __MOLLY_EMAIL__: p.email || 'no-email-set.invalid',
    __MOLLY_SIGN_OFF__: jsStr(signOff(p)),
    __MOLLY_PHONE__: jsStr(p.phone || ''),
    __MOLLY_PLACE_POSTCODE__: jsStr([place, p.postcode].filter(Boolean).join(' ') + ', UK'),
    __MOLLY_PLACE__: jsStr(place),
    __MOLLY_WEATHER_PLACE__: jsStr(p.weatherPlace || p.town || 'home'),
    __MOLLY_TOWN__: (p.town || 'local').replace(/[<>"&]/g, ''),
    __MOLLY_EDITION__: jsStr(`${(p.town || 'home').toUpperCase()} EDITION`),
    __MOLLY_HOUSEHOLD__: jsStr(p.household || 'family details not given'),
    __MOLLY_INITIAL_NAME__: jsStr(p.lastName ? `${p.firstName[0]}. ${p.lastName}` : p.firstName),
    __MOLLY_FULL_NAME__: jsStr(name),
    __MOLLY_FIRST_NAME__: jsStr(p.firstName),
    __MOLLY_INBOX_FOLDER__: jsStr(p.inboxFolder),
  };
}

/** Swap the build-time tokens for this person's profile. Returns { html, count }. */
export function personaliseArtifact(html, profile) {
  let count = 0;
  const vals = tokenValues(profile);
  html = html.replace(/__MOLLY_[A-Z_]+?__/g, m => { if (m in vals) { count++; return vals[m]; } return m; });
  return { html, count };
}

/** Values for {{PLACEHOLDERS}} in task prompts. */
export function promptVars(profile, extra = {}) {
  const p = completeProfile(profile);
  return {
    FULL_NAME: p.fullName || p.firstName, FIRST_NAME: p.firstName, EMAIL: p.email || '(email not set)',
    PHONE: p.phone || '', SIGN_OFF: signOff(p),
    TOWN: p.town || 'their home town', AREA: p.area || p.town || 'the UK', POSTCODE: p.postcode || '',
    ADDRESS: p.address || [p.area, p.postcode].filter(Boolean).join(', '),
    PRONOUNS: p.pronouns || 'they/them', HOUSEHOLD: p.household || '',
    ABOUT: p.about || `someone living in ${p.area || p.town || 'the UK'}`,
    ASSISTANT: p.assistantName || 'Molly',
    WEATHER_URL: p.weatherUrl || '', WEATHER_PLACE: p.weatherPlace || p.town || '',
    ONEDRIVE_ROOT: p.oneDriveRoot || '(no OneDrive folder chosen)',
    FOLDERS: (p.folders || []).length ? p.folders.map(f => `"${f}"`).join(', ') : '(any top-level folder)',
    INBOX_FOLDER: p.inboxFolder,
    TIME_ZONE: p.timeZone || 'Europe/London',
    ...extra,
  };
}

export function fillTemplate(text, vars) {
  return String(text).replace(/\{\{([A-Z_]+)\}\}/g, (m, k) => (k in vars ? String(vars[k]) : m));
}

/** Script tags injected at the very top of the page: settings for the shim, then the shim itself. */
export function injectShim(html, { token, profile, port, version }) {
  const p = completeProfile(profile);
  const boot = {
    token, port, version,
    profile: { firstName: p.firstName, fullName: p.fullName, assistantName: p.assistantName, timeZone: p.timeZone, wakeWord: p.wakeWord !== false },
    folderRe: folderRegexSource(p.folders),
  };
  const head = `<meta charset="utf-8"><script>window.__MOLLY_BOOT=${JSON.stringify(boot).replace(/</g, '\\u003c')};window.__MOLLY_FOLDER_RE=new RegExp(window.__MOLLY_BOOT.folderRe);</script>`
    + `<script src="/molly/shim.js"></script><script src="/molly/speech.js"></script>\n`;
  return head + html;
}

export function loadArtifact(paths) {
  try { return fs.readFileSync(paths.artifact, 'utf8'); } catch {}
  throw new Error('The Molly page is missing from the app (developers: run node scripts/prepare-artifact.mjs).');
}
